-- AXON DIGITAL NFTs V6.6 additive patch
-- Adds the $20 Lite paid plan compatibility and user-side withdrawals.
-- No admin portal is included in this release.

create table if not exists public.withdrawal_requests (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  payout_wallet text not null,
  requested_amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  user_note text,
  admin_note text,
  created_at timestamptz not null default now(),
  processed_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table if exists public.withdrawal_requests add column if not exists wallet_address text;
alter table if exists public.withdrawal_requests add column if not exists payout_wallet text;
alter table if exists public.withdrawal_requests add column if not exists requested_amount numeric(12,2) not null default 0;
alter table if exists public.withdrawal_requests add column if not exists status text not null default 'pending';
alter table if exists public.withdrawal_requests add column if not exists user_note text;
alter table if exists public.withdrawal_requests add column if not exists admin_note text;
alter table if exists public.withdrawal_requests add column if not exists created_at timestamptz not null default now();
alter table if exists public.withdrawal_requests add column if not exists processed_at timestamptz;
alter table if exists public.withdrawal_requests add column if not exists updated_at timestamptz not null default now();

create index if not exists withdrawal_requests_wallet_idx on public.withdrawal_requests (wallet_address, created_at desc);
create index if not exists withdrawal_requests_status_idx on public.withdrawal_requests (status, created_at desc);

alter table public.withdrawal_requests enable row level security;
revoke all on table public.withdrawal_requests from anon, authenticated;

do $cleanup$
begin
  execute 'drop policy if exists public_withdrawal_requests_select on public.withdrawal_requests';
  execute 'drop policy if exists public_withdrawal_requests_insert on public.withdrawal_requests';
exception
  when undefined_object then null;
end
$cleanup$;

drop trigger if exists trg_withdrawal_requests_touch on public.withdrawal_requests;
create trigger trg_withdrawal_requests_touch
before update on public.withdrawal_requests
for each row execute function public.axon_touch_updated_at();

create or replace function public.axon_total_claim_earnings(p_wallet text)
returns numeric
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(sum(amount), 0)::numeric
  from (
    select coalesce(fm.claim_amount, 0)::numeric as amount
    from public.free_miner_claims fm
    where lower(trim(fm.wallet_address)) = public.axon_normalize_wallet(p_wallet)

    union all

    select coalesce(pch.claim_amount, 0)::numeric as amount
    from public.plan_claim_history pch
    where lower(trim(pch.wallet_address)) = public.axon_normalize_wallet(p_wallet)
  ) q
$$;

create or replace function public.axon_reserved_withdrawal_total(p_wallet text)
returns numeric
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(sum(coalesce(wr.requested_amount, 0)), 0)::numeric
  from public.withdrawal_requests wr
  where lower(trim(wr.wallet_address)) = public.axon_normalize_wallet(p_wallet)
    and lower(trim(coalesce(wr.status, 'pending'))) in ('pending', 'processing', 'completed')
$$;

create or replace function public.axon_sync_withdrawal_transaction()
returns trigger
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_notes text;
begin
  v_notes := concat_ws(' • ',
    nullif(trim(coalesce(new.user_note, '')), ''),
    case when nullif(trim(coalesce(new.admin_note, '')), '') is not null then 'Admin: ' || trim(new.admin_note) else null end,
    'Payout: ' || new.payout_wallet
  );

  update public.transactions
  set amount = -1 * coalesce(new.requested_amount, 0),
      status = coalesce(new.status, 'pending'),
      notes = nullif(v_notes, ''),
      created_at = coalesce(transactions.created_at, new.created_at)
  where source = 'withdrawal_request'
    and reference_id = new.id;

  if not found then
    insert into public.transactions (
      wallet_address,
      type,
      plan_name,
      amount,
      status,
      source,
      reference_id,
      notes,
      created_at
    ) values (
      public.axon_normalize_wallet(new.wallet_address),
      'Withdrawal Request',
      'Withdrawals',
      -1 * coalesce(new.requested_amount, 0),
      coalesce(new.status, 'pending'),
      'withdrawal_request',
      new.id,
      nullif(v_notes, ''),
      coalesce(new.created_at, now())
    );
  end if;

  return new;
end;
$$;

drop trigger if exists trg_withdrawal_requests_sync_transaction on public.withdrawal_requests;
create trigger trg_withdrawal_requests_sync_transaction
after insert or update of requested_amount, status, payout_wallet, user_note, admin_note on public.withdrawal_requests
for each row execute function public.axon_sync_withdrawal_transaction();

create or replace function public.axon_get_withdrawal_summary(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_minimum numeric := 10;
  v_total_earnings numeric := 0;
  v_reserved numeric := 0;
  v_available numeric := 0;
  v_history jsonb := '[]'::jsonb;
  v_latest_status text := 'minimum not reached';
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  v_total_earnings := public.axon_total_claim_earnings(v_wallet);
  v_reserved := public.axon_reserved_withdrawal_total(v_wallet);
  v_available := greatest(0, v_total_earnings - v_reserved);

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb)
  into v_history
  from (
    select id, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at
    from public.withdrawal_requests
    where lower(trim(wallet_address)) = v_wallet
    order by created_at desc
    limit 20
  ) t;

  select coalesce(status, 'minimum not reached')
  into v_latest_status
  from public.withdrawal_requests
  where lower(trim(wallet_address)) = v_wallet
  order by created_at desc
  limit 1;

  if v_available >= v_minimum then
    v_latest_status := case when v_latest_status is null or v_latest_status = '' then 'available' else v_latest_status end;
  end if;

  return jsonb_build_object(
    'wallet_address', v_wallet,
    'minimum_withdrawal', v_minimum,
    'total_earnings', v_total_earnings,
    'reserved_amount', v_reserved,
    'available_balance', v_available,
    'can_request', (v_available >= v_minimum),
    'latest_status', v_latest_status,
    'recent_requests', v_history
  );
end;
$$;

create or replace function public.axon_request_withdrawal(
  p_wallet text,
  p_session_token text,
  p_amount numeric,
  p_payout_wallet text,
  p_user_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_payout_wallet text := public.axon_normalize_wallet(p_payout_wallet);
  v_amount numeric := round(coalesce(p_amount, 0), 2);
  v_minimum numeric := 10;
  v_available numeric := 0;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid wallet address.';
  end if;

  if v_payout_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Enter a valid BEP20 receiving wallet.';
  end if;

  if v_amount < v_minimum then
    raise exception 'Minimum withdrawal is $10.00.';
  end if;

  v_available := greatest(0, public.axon_total_claim_earnings(v_wallet) - public.axon_reserved_withdrawal_total(v_wallet));

  if v_amount > v_available then
    raise exception 'Requested amount is above the available withdrawal balance.';
  end if;

  insert into public.withdrawal_requests (
    wallet_address,
    payout_wallet,
    requested_amount,
    status,
    user_note,
    created_at,
    updated_at
  ) values (
    v_wallet,
    v_payout_wallet,
    v_amount,
    'pending',
    nullif(trim(coalesce(p_user_note, '')), ''),
    now(),
    now()
  );

  return public.axon_get_withdrawal_summary(v_wallet, p_session_token);
end;
$$;

grant execute on function public.axon_total_claim_earnings(text) to anon, authenticated;
grant execute on function public.axon_reserved_withdrawal_total(text) to anon, authenticated;
grant execute on function public.axon_get_withdrawal_summary(text, text) to anon, authenticated;
grant execute on function public.axon_request_withdrawal(text, text, numeric, text, text) to anon, authenticated;

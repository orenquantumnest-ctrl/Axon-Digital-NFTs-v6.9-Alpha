# AXON DIGITAL NFTs V6.8.11 — Admin RPC Session/Data Fix

## Purpose
- Fix persistent admin dashboard empty/zero records by replacing the admin RPC chain with versioned V6.8.11 RPCs.
- Keep the user side unchanged.
- Keep uploaded admin-login/admin-dashboard UI structure.

## Deploy
1. Upload the contents of this folder to both axondigitalnfts.com and axonprime-vault.netlify.app.
2. Run `supabase_v6_8_11_admin_rpc_session_data_fix.sql` in Supabase SQL Editor.
3. Run:
   - `select public.axon_admin_schema_bridge_health_v6811();`
   - `select public.axon_admin_live_data_probe_v6811();`
4. Open `/admin.html?fresh=6811` and log in.
5. Open `/admin-dashboard.html?fresh=6811`.

## Important
Do not put the admin password into frontend files. The SQL stores it as a hash in Supabase.

-- AXON DIGITAL NFTs V6.8.5 ADMIN PRO LIVE DATA PATCH
-- Additive/idempotent. Run after V6.8.4.2/V6.8.4 SQL files.
-- Purpose:
-- 1) Upgrade admin console RPC so existing live data appears on admin standalone pages.
-- 2) Add plan catalog status controls: active/suspended/deleted.
-- 3) Preserve existing user data; no destructive table reset.

create extension if not exists pgcrypto with schema extensions;

alter table if exists public.axon_plan_catalog add column if not exists deleted_at timestamptz;
create index if not exists axon_plan_catalog_status_idx on public.axon_plan_catalog (status, is_visible, sort_order);

-- Ensure suspended/deleted plans do not show on public user marketplace.
create or replace function public.axon_get_plan_catalog()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(jsonb_agg(to_jsonb(p) order by p.sort_order, p.plan_price), '[]'::jsonb)
  from public.axon_plan_catalog p
  where p.is_visible = true
    and coalesce(p.status,'active') = 'active'
    and p.deleted_at is null;
$$;

-- Admin can still see all plans, including suspended/deleted, for governance history.
create or replace function public.axon_admin_get_plan_catalog(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plans jsonb;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  select coalesce(jsonb_agg(to_jsonb(p) order by p.sort_order, p.plan_price), '[]'::jsonb)
  into v_plans
  from public.axon_plan_catalog p;
  return v_plans;
end;
$$;

-- Upsert accepts active/suspended/draft/hidden/deleted.
create or replace function public.axon_admin_upsert_plan_catalog(
  p_admin_session_token text,
  p_plan_code text,
  p_payment_key text,
  p_plan_name text,
  p_plan_price numeric,
  p_daily_rate numeric,
  p_daily_claim_amount numeric,
  p_max_claims integer,
  p_max_unlocks integer,
  p_sort_order integer,
  p_badge text,
  p_category text,
  p_description text,
  p_is_visible boolean,
  p_is_featured boolean,
  p_status text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plan public.axon_plan_catalog%rowtype;
  v_code text := lower(regexp_replace(trim(coalesce(p_plan_code,'')), '[^a-zA-Z0-9]+', '-', 'g'));
  v_status text := lower(trim(coalesce(p_status,'active')));
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  v_code := regexp_replace(v_code, '(^-+|-+$)', '', 'g');
  if v_code = '' then raise exception 'Plan code is required.'; end if;
  if coalesce(trim(p_plan_name),'') = '' then raise exception 'Plan name is required.'; end if;
  if coalesce(p_plan_price,0) < 0 then raise exception 'Plan price cannot be negative.'; end if;
  if v_status not in ('active','suspended','draft','hidden','deleted') then raise exception 'Invalid plan status.'; end if;

  insert into public.axon_plan_catalog (
    plan_code,payment_key,plan_name,plan_price,daily_rate,daily_claim_amount,max_claims,max_unlocks,sort_order,badge,category,description,is_visible,is_featured,status,deleted_at,updated_at
  ) values (
    v_code, nullif(trim(coalesce(p_payment_key,'')),''), trim(p_plan_name), coalesce(p_plan_price,0), coalesce(p_daily_rate,0),
    coalesce(p_daily_claim_amount, round(coalesce(p_plan_price,0) * coalesce(p_daily_rate,0) / 100, 2)), greatest(coalesce(p_max_claims,40),1), greatest(coalesce(p_max_unlocks,1),1), coalesce(p_sort_order,0),
    nullif(trim(coalesce(p_badge,'')),''), coalesce(nullif(trim(p_category),''),'starter'), nullif(trim(coalesce(p_description,'')),''),
    case when v_status in ('suspended','deleted','hidden') then false else coalesce(p_is_visible,true) end,
    coalesce(p_is_featured,false), v_status, case when v_status='deleted' then now() else null end, now()
  )
  on conflict (plan_code) do update set
    payment_key = excluded.payment_key,
    plan_name = excluded.plan_name,
    plan_price = excluded.plan_price,
    daily_rate = excluded.daily_rate,
    daily_claim_amount = excluded.daily_claim_amount,
    max_claims = excluded.max_claims,
    max_unlocks = excluded.max_unlocks,
    sort_order = excluded.sort_order,
    badge = excluded.badge,
    category = excluded.category,
    description = excluded.description,
    is_visible = excluded.is_visible,
    is_featured = excluded.is_featured,
    status = excluded.status,
    deleted_at = excluded.deleted_at,
    updated_at = now()
  returning * into v_plan;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'upsert_plan_catalog', 'axon_plan_catalog', v_plan.id, 'completed', 'Plan saved: ' || v_plan.plan_code || ' status=' || v_plan.status);

  return to_jsonb(v_plan);
end;
$$;

create or replace function public.axon_admin_set_plan_catalog_status(
  p_admin_session_token text,
  p_plan_code text,
  p_status text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status,'')));
  v_plan public.axon_plan_catalog%rowtype;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  if v_status not in ('active','suspended','draft','hidden','deleted') then
    raise exception 'Invalid plan status.';
  end if;

  update public.axon_plan_catalog
  set status = v_status,
      is_visible = case when v_status = 'active' then is_visible else false end,
      deleted_at = case when v_status = 'deleted' then now() else null end,
      updated_at = now()
  where plan_code = p_plan_code
  returning * into v_plan;

  if v_plan.id is null then raise exception 'Plan not found.'; end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'set_plan_status', 'axon_plan_catalog', v_plan.id, v_status, 'Plan status updated: ' || v_plan.plan_code);

  return to_jsonb(v_plan);
end;
$$;

create or replace function public.axon_admin_delete_plan_catalog(
  p_admin_session_token text,
  p_plan_code text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plan public.axon_plan_catalog%rowtype;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  update public.axon_plan_catalog
  set status = 'deleted', is_visible = false, is_featured = false, deleted_at = now(), updated_at = now()
  where plan_code = p_plan_code
  returning * into v_plan;

  if v_plan.id is null then raise exception 'Plan not found.'; end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'delete_plan_catalog', 'axon_plan_catalog', v_plan.id, 'deleted', 'Plan soft-deleted from user marketplace: ' || v_plan.plan_code);

  return jsonb_build_object('ok', true, 'plan_code', v_plan.plan_code, 'status', v_plan.status, 'deleted_at', v_plan.deleted_at);
end;
$$;

-- Live admin data console: broad enough for dashboard, users, deposits, withdrawals, transactions, plans, notifications, logs.
create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_plan_accounts jsonb := '[]'::jsonb;
  v_free_miner_accounts jsonb := '[]'::jsonb;
  v_audit_logs jsonb := '[]'::jsonb;
  v_system_events jsonb := '[]'::jsonb;
  v_plan_catalog jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires
  from public.axon_admin_sessions
  where id = v_session_id;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing');

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.users),
    'active_plans_count', (select count(*) from public.user_plans where lower(trim(coalesce(status, 'pending'))) = 'active'),
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'transactions_count', (select count(*) from public.transactions),
    'catalog_count', (select count(*) from public.axon_plan_catalog where coalesce(status,'active') <> 'deleted'),
    'claim_accounts_count', (select count(*) from public.plan_claim_accounts),
    'free_miner_count', (select count(*) from public.free_miner_accounts),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select u.id, u.wallet_address, u.referral_code, u.referred_by, u.created_at,
      (select count(*) from public.user_plans up where lower(trim(up.wallet_address)) = lower(trim(u.wallet_address)) and lower(trim(coalesce(up.status,''))) = 'active') as active_plans_count,
      (select coalesce(sum(amount),0) from public.transactions tx where lower(trim(tx.wallet_address)) = lower(trim(u.wallet_address)) and lower(trim(coalesce(tx.status,'completed'))) in ('completed','approved','active')) as available_balance
    from public.users u
    order by u.created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_transactions
  from (
    select id, wallet_address, type, plan_name, amount, status, source, reference_id, notes, created_at
    from public.transactions
    order by created_at desc
    limit 150
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_accounts
  from (
    select pca.id, pca.wallet_address, pca.user_plan_id, pca.plan_name, pca.plan_price, pca.daily_rate, pca.daily_claim_amount, pca.max_claims, pca.claims_completed, pca.total_claimed, pca.last_claim_at, pca.next_claim_at, pca.status, pca.created_at, pca.updated_at
    from public.plan_claim_accounts pca
    order by case when lower(trim(coalesce(pca.status,'')))='active' then 0 else 1 end, pca.created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_free_miner_accounts
  from (
    select id, wallet_address, status, claims_completed, claimed_amount, last_claim_at, next_claim_at, activated_at, created_at, updated_at
    from public.free_miner_accounts
    order by created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_audit_logs
  from (
    select id, admin_session_id, action, target_table, target_id, status, note, created_at
    from public.axon_admin_audit_log
    order by created_at desc
    limit 120
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_system_events
  from (
    select id, wallet_address, event_type as action, severity as status, payload::text as note, created_at
    from public.axon_system_events
    order by created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_catalog
  from (
    select id, plan_code, payment_key, plan_name, plan_price, daily_rate, daily_claim_amount, max_claims, max_unlocks, sort_order, badge, category, description, is_visible, is_featured, status, created_at, updated_at, deleted_at
    from public.axon_plan_catalog
    order by sort_order asc, plan_price asc
  ) t;

  return jsonb_build_object(
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'free_miner_accounts', v_free_miner_accounts,
    'audit_logs', v_audit_logs,
    'system_events', v_system_events,
    'plan_catalog', v_plan_catalog,
    'session_expires_at', v_expires
  );
end;
$$;

revoke all on function public.axon_get_plan_catalog() from public;
revoke all on function public.axon_admin_get_plan_catalog(text) from public;
revoke all on function public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text) from public;
revoke all on function public.axon_admin_set_plan_catalog_status(text,text,text) from public;
revoke all on function public.axon_admin_delete_plan_catalog(text,text) from public;
revoke all on function public.axon_admin_get_console(text) from public;

grant execute on function public.axon_get_plan_catalog() to anon, authenticated;
grant execute on function public.axon_admin_get_plan_catalog(text) to anon, authenticated;
grant execute on function public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text) to anon, authenticated;
grant execute on function public.axon_admin_set_plan_catalog_status(text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_delete_plan_catalog(text,text) to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;

# AXON DIGITAL NFTs V6.8.16 Deployment Checklist

1. Upload the contents of `build_v6816/` to both domains.
2. Run `supabase_v6_8_16_admin_action_list_fix.sql` in Supabase SQL Editor.
3. Test `admin.html?fresh=6816`, `admin-deposits.html?fresh=6816`, `admin-withdrawals.html?fresh=6816`, and `admin-users.html?fresh=6816`.
4. Approve/reject a deposit and confirm no invalid UUID dialogue appears.

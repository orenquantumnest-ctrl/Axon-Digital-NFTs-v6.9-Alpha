# AXON DIGITAL NFTs V6.8.5.3 Deployment Checklist

## Purpose
Fixes admin pages where Safari Network shows an empty stats request and admin cards remain at `0`.

## Upload
Upload the extracted contents of this folder to both:

- `axondigitalnfts.com`
- `axonprime-vault.netlify.app`

The files must sit at the web root. Example:

- `/admin.html`
- `/admin-dashboard.html`
- `/admin-withdrawals.html`
- `/js/config.js`
- `/js/supabase-config.js`
- `/js/v68-admin-pages.js`

## Supabase
Run the following SQL only once in the Supabase project used by both domains:

1. `supabase_v6_8_5_admin_console_live_data_patch.sql`
2. `supabase_v6_8_5_1_admin_live_data_backfill_patch.sql`
3. `supabase_v6_8_5_3_admin_rpc_visibility_fix.sql`

Then run:

```sql
select public.axon_admin_browser_rpc_health();
select public.axon_admin_live_data_probe();
```

## Test links

- `https://axondigitalnfts.com/admin.html?fresh=6853`
- `https://axondigitalnfts.com/admin-withdrawals.html?fresh=6853`
- `https://axonprime-vault.netlify.app/admin.html?fresh=6853`
- `https://axonprime-vault.netlify.app/admin-withdrawals.html?fresh=6853`

## Expected Safari Network

You should see a POST request to:

`https://soulxqkznkzigsvazijp.supabase.co/rest/v1/rpc/axon_admin_get_console`

The request payload must include:

```json
{"p_admin_session_token":"..."}
```

Expected status: `200`.

## Expected UI

The admin page should show:

- `Live admin data loaded from Supabase...`
- real stat values when database records exist
- a visible error card if the RPC fails
- a `Live data probe` details block on page-specific lists


(function(){
  'use strict';
  function boot(){
    var nodes=[].slice.call(document.querySelectorAll('[data-lottie-path]'));
    if(!nodes.length) return;
    if(!window.lottie || typeof window.lottie.loadAnimation !== 'function'){
      nodes.forEach(function(node){ node.setAttribute('data-lottie-fallback','true'); });
      return;
    }
    nodes.forEach(function(node){
      try{
        window.lottie.loadAnimation({container:node,renderer:'svg',loop:true,autoplay:true,path:node.getAttribute('data-lottie-path')});
      }catch(error){ node.setAttribute('data-lottie-fallback','true'); console.warn('[AXON LOTTIE]', error); }
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();

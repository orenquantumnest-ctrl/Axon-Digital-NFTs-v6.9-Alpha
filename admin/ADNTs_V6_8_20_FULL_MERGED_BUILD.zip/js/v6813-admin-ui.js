
(function(){
  'use strict';
  function boot(){
    var toggle=document.querySelector('[data-a13-menu-toggle]');
    if(toggle){toggle.addEventListener('click',function(){document.body.classList.toggle('admin-a13-open');});}
    document.addEventListener('click',function(ev){
      if(!document.body.classList.contains('admin-a13-open')) return;
      if(ev.target.closest('[data-a13-menu-toggle]') || ev.target.closest('.admin-a13-sidebar')) return;
      document.body.classList.remove('admin-a13-open');
    });
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')document.body.classList.remove('admin-a13-open');});
    document.querySelectorAll('[data-admin-logout]').forEach(function(node){
      node.addEventListener('click',function(){
        try{ if(window.AXONAdminRuntime && window.AXONAdminRuntime.clearToken) window.AXONAdminRuntime.clearToken(); }catch(_){ }
        try{ localStorage.removeItem('axonAdminSessionToken'); localStorage.removeItem('axonAdminSessionMeta'); }catch(_){ }
        try{ sessionStorage.removeItem('axonAdminSessionToken'); sessionStorage.removeItem('axonAdminSessionMeta'); }catch(_){ }
        try{ document.cookie='axonAdminSessionToken=; Path=/; Max-Age=-1; SameSite=Lax'; document.cookie='axonAdminSessionMeta=; Path=/; Max-Age=-1; SameSite=Lax'; }catch(_){ }
        location.href='admin.html?fresh=6813&logout=1';
      });
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

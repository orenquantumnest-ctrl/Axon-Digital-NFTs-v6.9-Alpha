/*
  AXON DIGITAL NFTs — V6.8.13 Runtime Configuration
  Purpose:
  - Primary browser-side configuration bridge for both production domains:
    1) https://axondigitalnfts.com
    2) https://axonprime-vault.netlify.app
  - Keeps both deployments connected to the same Supabase project.
  - Public browser config only. Do NOT place service-role keys or admin passwords here.
*/
(function configureAxonRuntime(global) {
  'use strict';

  var CONFIG = {
    appName: 'AXON DIGITAL NFTs',
    version: '6.8.19',
    buildName: 'ADMIN_SWIFTUI_PAGES_LOCKED',
    buildHash: '91465d78925a794021c91214650922f790113dd472918bdd62259b6529f961cd',

    productionDomains: [
      'https://axondigitalnfts.com',
      'https://axonprime-vault.netlify.app'
    ],

    // Public Supabase browser values. These must match on both domains.
    supabaseUrl: 'https://soulxqkznkzigsvazijp.supabase.co',
    supabaseAnonKey: 'sb_publishable_4Mn99qeGLSLC00IPHutIQQ_yOm22eHl',

    // Admin key policy: the admin password is configured in Supabase only.
    adminKeyPolicy: 'v6819-wallet-password-swiftui-admin-pages',
    // V6.8.12 admin login identity. Password is never stored in frontend.
    adminWalletAddress: '0x7bbc456c2c34972723cf03b9d44323d2539514de',

    // Cache-bust marker used by manual testing links and static-host refreshes.
    cacheVersion: '6819'
  };

  global.AXON_CONFIG = Object.assign({}, CONFIG, global.AXON_CONFIG || {});

  // Primary names used by the existing AXON codebase.
  global.AXON_SUPABASE_URL = global.AXON_SUPABASE_URL || global.AXON_CONFIG.supabaseUrl;
  global.AXON_SUPABASE_ANON_KEY = global.AXON_SUPABASE_ANON_KEY || global.AXON_CONFIG.supabaseAnonKey;

  // Compatibility aliases for files or future modules expecting config.js style names.
  global.SUPABASE_URL = global.SUPABASE_URL || global.AXON_SUPABASE_URL;
  global.SUPABASE_ANON_KEY = global.SUPABASE_ANON_KEY || global.AXON_SUPABASE_ANON_KEY;
  global.AXON_PUBLIC_SUPABASE_URL = global.AXON_PUBLIC_SUPABASE_URL || global.AXON_SUPABASE_URL;
  global.AXON_PUBLIC_SUPABASE_ANON_KEY = global.AXON_PUBLIC_SUPABASE_ANON_KEY || global.AXON_SUPABASE_ANON_KEY;

  global.AXON_ENV_READY = Boolean(global.AXON_SUPABASE_URL && global.AXON_SUPABASE_ANON_KEY);
})(window);

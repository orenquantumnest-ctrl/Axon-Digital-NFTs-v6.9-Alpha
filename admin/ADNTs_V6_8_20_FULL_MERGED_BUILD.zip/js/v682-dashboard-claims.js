(function(){
  'use strict';
  if(!document.body || document.body.dataset.page !== 'dashboard') return;

  var SUPABASE_URL = window.AXON_SUPABASE_URL;
  var SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  var client = (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase) ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
  var AXONAuth = window.AXONAuth;
  var planState = [];
  var activeClaimId = null;

  function $(id){ return document.getElementById(id); }
  function esc(value){
    return String(value == null ? '' : value).replace(/[&<>'"]/g,function(ch){
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch];
    });
  }
  function usd(value){
    return '$' + Number(value || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
  }
  function clamp(value,min,max){ return Math.max(min, Math.min(max, Number(value || 0))); }
  function plural(n,one,many){ return Number(n) === 1 ? one : many; }
  function formatTime(value){
    if(!value) return 'Ready now';
    var date = new Date(value);
    if(Number.isNaN(date.getTime())) return 'Ready now';
    return date.toLocaleString();
  }
  function formatDuration(seconds){
    seconds = Math.max(0, Math.floor(Number(seconds || 0)));
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    if(h > 0) return h + 'h ' + String(m).padStart(2,'0') + 'm';
    if(m > 0) return m + 'm ' + String(s).padStart(2,'0') + 's';
    return s + 's';
  }
  function getUser(){ return AXONAuth && typeof AXONAuth.getUser === 'function' ? AXONAuth.getUser() : null; }
  function setFeedback(message,type){
    var box = $('paidClaimFeedback');
    if(!box) return;
    box.className = 'v682-claim-feedback' + (type ? ' ' + type : '');
    box.textContent = message;
  }
  function getClaimId(plan){ return plan.claim_account_id || plan.id || plan.user_plan_id || ''; }
  function canClaim(plan){ return !!plan.can_claim && String(plan.status || '').toLowerCase() !== 'completed'; }
  function statusLabel(plan){
    var status = String(plan.status || 'active').toLowerCase();
    if(status === 'completed') return 'Completed';
    if(canClaim(plan)) return 'Ready to Claim';
    return 'Cooldown';
  }
  function statusClass(plan){
    var status = String(plan.status || 'active').toLowerCase();
    if(status === 'completed') return 'completed';
    if(canClaim(plan)) return 'ready';
    return 'cooldown';
  }
  function renderEmpty(){
    var panel = $('paidClaimStatusPanel');
    if(!panel) return;
    panel.innerHTML = '<div class="v68-empty">No active paid-plan claim account is available yet. Once an admin approves a paid deposit, the daily claim bar will appear here.</div>';
    setFeedback('No active subscribed paid plan is ready for daily claiming yet.','warn');
  }
  function renderPlans(plans){
    var panel = $('paidClaimStatusPanel');
    if(!panel) return;
    planState = Array.isArray(plans) ? plans.slice() : [];
    if(!planState.length){ renderEmpty(); return; }

    var readyCount = planState.filter(canClaim).length;
    setFeedback(readyCount ? (readyCount + ' active ' + plural(readyCount,'plan is','plans are') + ' ready. Tap the plan card or Claim Daily Reward button.') : 'All active paid plans are currently cooling down or completed. Check the progress bars for the next window.', readyCount ? 'success' : 'warn');

    panel.innerHTML = planState.map(function(plan,index){
      var claimId = esc(getClaimId(plan));
      var status = statusLabel(plan);
      var klass = statusClass(plan);
      var cyclePercent = clamp(plan.cycle_progress_percent,0,100);
      var completionPercent = clamp((Number(plan.claims_completed || 0) / Math.max(1, Number(plan.max_claims || 40))) * 100,0,100);
      var seconds = Number(plan.seconds_remaining || 0);
      var isReady = canClaim(plan);
      var isCompleted = klass === 'completed';
      var buttonText = isCompleted ? 'Cycle Complete' : isReady ? 'Claim Daily Reward' : 'Wait ' + formatDuration(seconds);
      return ''+
        '<article class="v682-plan-card '+klass+(isReady?' can-claim':'')+'" data-claim-account-id="'+claimId+'" tabindex="0" role="button" aria-label="'+esc(plan.plan_name || ('Plan '+(index+1)))+' daily claim card">'+
          '<div class="v682-plan-top">'+
            '<div>'+ 
              '<h3 class="v682-plan-name">'+esc(plan.plan_name || ('Paid Plan '+(index+1)))+'</h3>'+ 
              '<div class="v682-plan-meta">'+
                '<span>'+esc(usd(plan.daily_claim_amount || 0))+' daily</span>'+ 
                '<span>'+esc(Number(plan.daily_rate || 0))+'% rate</span>'+ 
                '<span>Claim '+esc(Number(plan.claims_completed || 0))+' / '+esc(Number(plan.max_claims || 40))+'</span>'+ 
              '</div>'+ 
            '</div>'+ 
            '<div>'+ 
              '<div class="v682-plan-price">'+esc(usd(plan.plan_price || 0))+'</div>'+ 
              '<div class="v682-plan-status '+klass+'">'+esc(status)+'</div>'+ 
            '</div>'+ 
          '</div>'+ 
          '<div class="v682-bar-group">'+
            '<div class="v682-bar-row">'+
              '<div class="v682-bar-label"><span>24h Claim Window</span><strong>'+cyclePercent.toFixed(0)+'%</strong></div>'+ 
              '<div class="v682-claim-bar"><span style="width:'+cyclePercent+'%"></span></div>'+ 
            '</div>'+ 
            '<div class="v682-bar-row">'+
              '<div class="v682-bar-label"><span>Plan Completion</span><strong>'+completionPercent.toFixed(0)+'%</strong></div>'+ 
              '<div class="v682-claim-bar"><span style="width:'+completionPercent+'%"></span></div>'+ 
            '</div>'+ 
          '</div>'+ 
          '<div class="v682-plan-bottom">'+
            '<div class="v682-mini-stats">'+
              '<span>Total claimed: <strong>'+esc(usd(plan.total_claimed || 0))+'</strong></span>'+ 
              '<span>Next window: '+esc(isReady ? 'Ready now' : formatTime(plan.next_claim_at))+'</span>'+ 
            '</div>'+ 
            '<button class="v682-claim-button" type="button" data-claim-account-id="'+claimId+'" '+((!isReady || activeClaimId === getClaimId(plan))?'disabled':'')+'>'+esc(activeClaimId === getClaimId(plan) ? 'Claiming…' : buttonText)+'</button>'+ 
          '</div>'+ 
        '</article>';
    }).join('');
  }
  async function validateSession(user){
    if(!user || !user.wallet || !user.sessionToken) return false;
    if(!client) return true;
    try{
      var res = await client.rpc('axon_get_session_status',{p_wallet:user.wallet,p_session_token:user.sessionToken});
      if(res.error && /does not exist/i.test(res.error.message || '')) return true;
      if(res.error) throw res.error;
      return !!(res.data && res.data.valid);
    }catch(error){
      console.warn('[AXON V6.8.2] Session validation warning:', error);
      return false;
    }
  }
  async function loadPlanClaims(){
    var user = getUser();
    if(!await validateSession(user)) return;
    if(!client){
      renderEmpty();
      setFeedback('Supabase browser client is not configured. Add the live Supabase URL and anon key in js/supabase-config.js.','error');
      return;
    }
    try{
      setFeedback('Refreshing paid-plan claim windows…');
      var res = await client.rpc('axon_get_dashboard',{p_wallet:user.wallet,p_session_token:user.sessionToken});
      if(res.error) throw res.error;
      var dashboard = res.data || {};
      renderPlans(dashboard.active_plans || []);
    }catch(error){
      console.error('[AXON V6.8.2] Paid plan claim load failed:', error);
      renderEmpty();
      setFeedback(error.message || 'Unable to load paid claim windows. Confirm the V6.7 Supabase RPCs are installed.','error');
    }
  }
  async function claimPlan(claimId){
    var user = getUser();
    if(!claimId || !client || !user) return;
    var plan = planState.find(function(item){ return String(getClaimId(item)) === String(claimId); });
    if(!plan){ setFeedback('The selected plan could not be matched. Refresh the dashboard and try again.','error'); return; }
    if(!canClaim(plan)){
      var wait = Number(plan.seconds_remaining || 0) > 0 ? ' Wait time: ' + formatDuration(plan.seconds_remaining) + '.' : '';
      setFeedback('This plan is not claimable yet.' + wait,'warn');
      return;
    }
    activeClaimId = claimId;
    renderPlans(planState);
    setFeedback('Submitting daily paid-plan claim for '+(plan.plan_name || 'selected plan')+'…');
    try{
      var res = await client.rpc('axon_claim_plan_reward',{p_wallet:user.wallet,p_session_token:user.sessionToken,p_claim_account_id:claimId});
      if(res.error) throw res.error;
      setFeedback('Claim successful: '+usd((res.data && res.data.daily_claim_amount) || plan.daily_claim_amount || 0)+' added to your claim ledger.','success');
      activeClaimId = null;
      await loadPlanClaims();
      if(window.navigator && typeof window.navigator.vibrate === 'function') window.navigator.vibrate(18);
    }catch(error){
      activeClaimId = null;
      renderPlans(planState);
      setFeedback(error.message || 'Paid-plan daily claim failed.','error');
    }
  }
  function initEvents(){
    var panel = $('paidClaimStatusPanel');
    if(!panel) return;
    panel.addEventListener('click',function(event){
      var button = event.target.closest('[data-claim-account-id]');
      if(!button) return;
      var card = event.target.closest('.v682-plan-card');
      var id = button.getAttribute('data-claim-account-id') || (card && card.getAttribute('data-claim-account-id'));
      if(event.target.closest('button') && event.target.closest('button').disabled) return;
      claimPlan(id);
    });
    panel.addEventListener('keydown',function(event){
      if(event.key !== 'Enter' && event.key !== ' ') return;
      var card = event.target.closest('.v682-plan-card');
      if(!card) return;
      event.preventDefault();
      claimPlan(card.getAttribute('data-claim-account-id'));
    });
  }
  function boot(){ initEvents(); loadPlanClaims(); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();

(function () {
  const KEY = 'axonUser';
  const REF_LINK_KEY = 'axonReferralLink';
  const REF_VISITOR_KEY = 'axonReferralVisitorKey';
  const REF_REF_KEY = 'axonReferralRef';
  const EXTRA_CLEAR_KEYS = ['axonSelectedPlan', 'axonTransactions'];

  function storageList() {
    return [window.localStorage, window.sessionStorage].filter(Boolean);
  }

  function normalizeWallet(address) {
    return String(address || '').trim().toLowerCase();
  }

  function isValidWallet(address) {
    return /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
  }

  function parseUserCandidate(value) {
    if (!value) return null;
    let raw = value;
    if (typeof raw === 'string') {
      try {
        raw = JSON.parse(raw);
      } catch (error) {
        return null;
      }
    }

    if (!raw || typeof raw !== 'object') return null;

    const wallet = normalizeWallet(raw.wallet || raw.walletAddress || raw.wallet_address || '');
    const sessionToken = String(raw.sessionToken || raw.session_token || raw.token || '').trim();
    if (!wallet) return null;

    return {
      wallet,
      sessionToken,
      loggedInAt: raw.loggedInAt || raw.logged_in_at || new Date().toISOString()
    };
  }

  function readStoredUser() {
    for (const storage of storageList()) {
      try {
        const parsed = parseUserCandidate(storage.getItem(KEY));
        if (parsed) return parsed;
      } catch (error) {}
    }
    return null;
  }

  function writeStoredUser(payload) {
    const parsed = parseUserCandidate(payload);
    if (!parsed) return null;
    const serialized = JSON.stringify(parsed);
    for (const storage of storageList()) {
      try { storage.setItem(KEY, serialized); } catch (error) {}
    }
    return parsed;
  }

  function clearStoredUser() {
    for (const storage of storageList()) {
      try {
        storage.removeItem(KEY);
        EXTRA_CLEAR_KEYS.forEach(key => storage.removeItem(key));
      } catch (error) {}
    }
  }

  function hasLiveSession(user) {
    return Boolean(user && user.wallet && user.sessionToken);
  }

  function buildReferralLink(wallet) {
    const safe = normalizeWallet(wallet);
    return safe ? `${window.location.origin}/signup.html?ref=${safe}` : '';
  }

  function persistUserSession(payload) {
    const stored = writeStoredUser({
      wallet: payload.wallet_address || payload.wallet || '',
      sessionToken: payload.session_token || payload.sessionToken || '',
      loggedInAt: new Date().toISOString()
    });
    const referralLink = payload.referral_link || buildReferralLink(stored && stored.wallet ? stored.wallet : '');
    if (referralLink) {
      for (const storage of storageList()) {
        try { storage.setItem(REF_LINK_KEY, referralLink); } catch (error) {}
      }
    }
    return stored;
  }

  function getReferralLink(wallet) {
    const safe = normalizeWallet(wallet);
    if (!safe) return '';
    return buildReferralLink(safe);
  }

  function getLoginHref(target) {
    const safeTarget = String(target || 'dashboard.html').trim() || 'dashboard.html';
    return 'login.html?next=' + encodeURIComponent(safeTarget);
  }

  function migrateLegacyState() {
    const parsed = readStoredUser();
    if (parsed) writeStoredUser(parsed);
  }

  window.AXONAuth = {
    key: KEY,
    referralLinkKey: REF_LINK_KEY,
    referralVisitKey: REF_VISITOR_KEY,
    referralRefKey: REF_REF_KEY,
    normalizeWallet,
    isValidWallet,
    parseUserCandidate,
    getUser: readStoredUser,
    setUser: writeStoredUser,
    clearUser: clearStoredUser,
    hasLiveSession,
    buildReferralLink,
    getReferralLink,
    persistUserSession,
    getLoginHref,
    migrateLegacyState
  };

  migrateLegacyState();
})();

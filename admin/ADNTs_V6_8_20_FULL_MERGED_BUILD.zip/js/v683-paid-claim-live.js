(function(){
  'use strict';
  if(!document.body || document.body.dataset.page !== 'dashboard') return;

  var SUPABASE_URL = window.AXON_SUPABASE_URL;
  var SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  var client = (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase) ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
  var AXONAuth = window.AXONAuth;
  var planState = [];
  var activeClaimId = null;
  var refreshTimer = null;
  var tickTimer = null;
  var zeroRefreshLock = false;
  var DAY_SECONDS = 86400;

  function $(id){ return document.getElementById(id); }
  function esc(value){
    return String(value == null ? '' : value).replace(/[&<>'"]/g,function(ch){
      return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch];
    });
  }
  function usd(value){
    return '$' + Number(value || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
  }
  function clamp(value,min,max){ return Math.max(min, Math.min(max, Number(value || 0))); }
  function plural(n,one,many){ return Number(n) === 1 ? one : many; }
  function getUser(){ return AXONAuth && typeof AXONAuth.getUser === 'function' ? AXONAuth.getUser() : null; }
  function claimIdOf(plan){ return plan.claim_account_id || plan.id || plan.user_plan_id || ''; }
  function cssEscape(value){
    var s = String(value == null ? '' : value);
    if(window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(s);
    return s.replace(/[^a-zA-Z0-9_-]/g,function(ch){ return '\\' + ch; });
  }
  function planHref(plan){
    var id = claimIdOf(plan);
    return id ? 'plans.html?claim_account_id=' + encodeURIComponent(id) : 'plans.html';
  }
  function planName(plan,index){ return plan.plan_name || plan.name || ('Paid Plan ' + (index + 1)); }
  function maxClaims(plan){ return Math.max(1, Number(plan.max_claims || plan.duration_days || 40)); }
  function claimsCompleted(plan){ return clamp(plan.claims_completed || plan.days_claimed || 0,0,maxClaims(plan)); }
  function daysRemaining(plan){ return Math.max(0, maxClaims(plan) - claimsCompleted(plan)); }
  function isCompleted(plan){ return String(plan.status || '').toLowerCase() === 'completed' || daysRemaining(plan) <= 0; }
  function secondsUntilNext(plan){
    if(isCompleted(plan)) return 0;
    if(plan.can_claim) return 0;
    if(plan.next_claim_at){
      var nextMs = new Date(plan.next_claim_at).getTime();
      if(!Number.isNaN(nextMs)) return Math.max(0, Math.ceil((nextMs - Date.now()) / 1000));
    }
    return Math.max(0, Math.ceil(Number(plan.seconds_remaining || 0)));
  }
  function cyclePercent(plan){
    if(isCompleted(plan) || plan.can_claim) return 100;
    var remaining = secondsUntilNext(plan);
    var elapsed = clamp(DAY_SECONDS - remaining,0,DAY_SECONDS);
    return clamp((elapsed / DAY_SECONDS) * 100,0,100);
  }
  function completionPercent(plan){ return clamp((claimsCompleted(plan) / maxClaims(plan)) * 100,0,100); }
  function canClaim(plan){ return !isCompleted(plan) && (plan.can_claim || secondsUntilNext(plan) <= 0); }
  function statusClass(plan){
    if(isCompleted(plan)) return 'completed';
    if(canClaim(plan)) return 'ready';
    return 'cooldown';
  }
  function statusLabel(plan){
    if(isCompleted(plan)) return 'Cycle Complete';
    if(canClaim(plan)) return 'Ready to Claim';
    return 'Cooling Down';
  }
  function formatDuration(totalSeconds){
    var seconds = Math.max(0, Math.floor(Number(totalSeconds || 0)));
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    return String(h).padStart(2,'0') + 'h ' + String(m).padStart(2,'0') + 'm ' + String(s).padStart(2,'0') + 's';
  }
  function formatTime(value){
    if(!value) return 'Ready now';
    var date = new Date(value);
    if(Number.isNaN(date.getTime())) return 'Ready now';
    return date.toLocaleString();
  }
  function setFeedback(message,type){
    var box = $('paidClaimFeedback');
    if(!box) return;
    box.className = 'v682-claim-feedback' + (type ? ' ' + type : '');
    box.textContent = message;
  }
  function setText(selector, root, text){
    var el = root.querySelector(selector);
    if(el) el.textContent = text;
  }
  function setWidth(selector, root, value){
    var el = root.querySelector(selector);
    if(el) el.style.width = value + '%';
  }
  function renderEmpty(){
    var claimPanel = $('paidClaimStatusPanel');
    var preview = $('activePaidPlanPreview');
    var empty = '<div class="v68-empty">No active paid-plan claim account is available yet. Once an admin approves a paid deposit, the paid-plan claim card will appear here.</div>';
    if(claimPanel) claimPanel.innerHTML = empty;
    if(preview) preview.innerHTML = empty;
    setFeedback('No active subscribed paid plan is available for dashboard claiming yet.','warn');
  }
  function renderPreview(plans){
    var box = $('activePaidPlanPreview');
    if(!box) return;
    if(!plans.length){ box.innerHTML = '<div class="v68-empty">No active paid plan yet. Open the plans page and subscribe to a paid plan to activate this dashboard preview.</div>'; return; }
    box.innerHTML = plans.slice(0,3).map(function(plan,index){
      var id = esc(claimIdOf(plan));
      var klass = statusClass(plan);
      var claimed = claimsCompleted(plan);
      var remaining = daysRemaining(plan);
      var completion = completionPercent(plan);
      return ''+
        '<article class="v683-preview-card '+klass+'" data-preview-claim-id="'+id+'">'+
          '<div class="v683-preview-main">'+
            '<div><h3>'+esc(planName(plan,index))+'</h3><p>Status: '+esc(plan.status || 'active')+' · Plan: '+esc(usd(plan.plan_price || 0))+' · Daily: '+esc(usd(plan.daily_claim_amount || 0))+'</p></div>'+
            '<strong>'+esc(usd(plan.total_claimed || 0))+'</strong>'+
          '</div>'+
          '<div class="v683-preview-stats">'+
            '<span><b>Days Claimed</b>'+esc(claimed)+' / '+esc(maxClaims(plan))+'</span>'+
            '<span><b>Days Remaining</b>'+esc(remaining)+'</span>'+
            '<span><b>Countdown</b><em class="v683-preview-countdown">'+esc(canClaim(plan)?'Ready now':formatDuration(secondsUntilNext(plan)))+'</em></span>'+
          '</div>'+
          '<div class="v682-claim-bar v683-preview-bar"><span style="width:'+completion+'%"></span></div>'+
          '<div class="v683-preview-actions">'+
            '<a class="v68-btn ghost" href="'+esc(planHref(plan))+'">Go to this plan</a>'+
            '<button class="v682-claim-button v683-preview-claim" type="button" data-claim-account-id="'+id+'" '+(!canClaim(plan)?'disabled':'')+'>'+esc(canClaim(plan)?'Claim Now':'Wait '+formatDuration(secondsUntilNext(plan)))+'</button>'+
          '</div>'+
        '</article>';
    }).join('');
  }
  function renderClaims(plans){
    var panel = $('paidClaimStatusPanel');
    if(!panel) return;
    if(!plans.length){ renderEmpty(); return; }
    panel.innerHTML = plans.map(function(plan,index){
      var id = esc(claimIdOf(plan));
      var klass = statusClass(plan);
      var claimed = claimsCompleted(plan);
      var max = maxClaims(plan);
      var remaining = daysRemaining(plan);
      var cycle = cyclePercent(plan);
      var completion = completionPercent(plan);
      var seconds = secondsUntilNext(plan);
      var ready = canClaim(plan);
      var complete = isCompleted(plan);
      var buttonText = complete ? 'Cycle Complete' : ready ? 'Claim Daily Reward' : 'Wait ' + formatDuration(seconds);
      return ''+
        '<article class="v682-plan-card v683-live-plan-card '+klass+(ready?' can-claim':'')+'" data-claim-account-id="'+id+'" data-next-claim-at="'+esc(plan.next_claim_at || '')+'" tabindex="0" role="button" aria-label="'+esc(planName(plan,index))+' daily claim card">'+
          '<div class="v682-plan-top">'+
            '<div><h3 class="v682-plan-name">'+esc(planName(plan,index))+'</h3><div class="v682-plan-meta"><span>'+esc(usd(plan.daily_claim_amount || 0))+' daily</span><span>'+esc(Number(plan.daily_rate || 0))+'% rate</span><span class="v683-days-claimed-meta">Days claimed: '+esc(claimed)+' / '+esc(max)+'</span><span class="v683-days-remaining-meta">Days remaining: '+esc(remaining)+'</span></div></div>'+
            '<div><div class="v682-plan-price">'+esc(usd(plan.plan_price || 0))+'</div><div class="v682-plan-status '+klass+'">'+esc(statusLabel(plan))+'</div></div>'+
          '</div>'+
          '<div class="v683-countdown-shell">'+
            '<span>24h Countdown</span><strong class="v683-live-countdown">'+esc(ready ? 'Ready now' : formatDuration(seconds))+'</strong>'+
          '</div>'+
          '<div class="v682-bar-group">'+
            '<div class="v682-bar-row"><div class="v682-bar-label"><span>24h Claim Window</span><strong class="v683-cycle-pct">'+cycle.toFixed(0)+'%</strong></div><div class="v682-claim-bar"><span class="v683-cycle-bar" style="width:'+cycle+'%"></span></div></div>'+
            '<div class="v682-bar-row"><div class="v682-bar-label"><span>Plan Completion</span><strong class="v683-completion-pct">'+completion.toFixed(0)+'%</strong></div><div class="v682-claim-bar"><span class="v683-completion-bar" style="width:'+completion+'%"></span></div></div>'+
          '</div>'+
          '<div class="v683-days-grid"><div><span>Days Claimed</span><strong>'+esc(claimed)+' / '+esc(max)+'</strong></div><div><span>Days Remaining</span><strong>'+esc(remaining)+'</strong></div><div><span>Next Claim</span><strong class="v683-next-window">'+esc(ready?'Ready now':formatTime(plan.next_claim_at))+'</strong></div></div>'+
          '<div class="v682-plan-bottom">'+
            '<div class="v682-mini-stats"><span>Total claimed: <strong>'+esc(usd(plan.total_claimed || 0))+'</strong></span><span>Claim account: '+esc(String(claimIdOf(plan)).slice(0,8) || '—')+'</span></div>'+
            '<div class="v683-card-actions"><a class="v68-btn ghost" href="'+esc(planHref(plan))+'">Go to this plan</a><button class="v682-claim-button" type="button" data-claim-account-id="'+id+'" '+((!ready || activeClaimId === claimIdOf(plan))?'disabled':'')+'>'+esc(activeClaimId === claimIdOf(plan) ? 'Claiming…' : buttonText)+'</button></div>'+
          '</div>'+
        '</article>';
    }).join('');
  }
  function renderAll(plans){
    planState = Array.isArray(plans) ? plans.slice() : [];
    if(!planState.length){ renderEmpty(); return; }
    var readyCount = planState.filter(canClaim).length;
    setFeedback(readyCount ? (readyCount + ' active ' + plural(readyCount,'paid plan is','paid plans are') + ' ready for daily claiming.') : 'All active paid plans are cooling down or completed. The dashboard countdown updates live.', readyCount ? 'success' : 'warn');
    renderPreview(planState);
    renderClaims(planState);
  }
  function updateLiveTimers(){
    if(!planState.length) return;
    var reachedZero = false;
    planState.forEach(function(plan){
      var id = String(claimIdOf(plan));
      var seconds = secondsUntilNext(plan);
      var ready = canClaim(plan);
      var cycle = cyclePercent(plan);
      var completion = completionPercent(plan);
      var claimCard = document.querySelector('.v683-live-plan-card[data-claim-account-id="'+cssEscape(id)+'"]');
      if(claimCard){
        claimCard.classList.toggle('ready', ready);
        claimCard.classList.toggle('cooldown', !ready && !isCompleted(plan));
        claimCard.classList.toggle('completed', isCompleted(plan));
        setText('.v683-live-countdown',claimCard, ready ? 'Ready now' : formatDuration(seconds));
        setText('.v683-cycle-pct',claimCard, cycle.toFixed(0)+'%');
        setWidth('.v683-cycle-bar',claimCard, cycle);
        setText('.v683-completion-pct',claimCard, completion.toFixed(0)+'%');
        setWidth('.v683-completion-bar',claimCard, completion);
        var button = claimCard.querySelector('.v682-claim-button[data-claim-account-id]');
        if(button && activeClaimId !== id){
          button.disabled = !ready;
          button.textContent = isCompleted(plan) ? 'Cycle Complete' : ready ? 'Claim Daily Reward' : 'Wait ' + formatDuration(seconds);
        }
        var status = claimCard.querySelector('.v682-plan-status');
        if(status){ status.className = 'v682-plan-status ' + statusClass(plan); status.textContent = statusLabel(plan); }
      }
      var previewCard = document.querySelector('.v683-preview-card[data-preview-claim-id="'+cssEscape(id)+'"]');
      if(previewCard){
        setText('.v683-preview-countdown',previewCard, ready ? 'Ready now' : formatDuration(seconds));
        setWidth('.v683-preview-bar span',previewCard, completion);
        var pbtn = previewCard.querySelector('.v683-preview-claim');
        if(pbtn && activeClaimId !== id){
          pbtn.disabled = !ready;
          pbtn.textContent = ready ? 'Claim Now' : 'Wait ' + formatDuration(seconds);
        }
      }
      if(seconds <= 0 && !plan.can_claim && !isCompleted(plan)) reachedZero = true;
    });
    if(reachedZero && !zeroRefreshLock){
      zeroRefreshLock = true;
      window.setTimeout(function(){ loadPlanClaims(true); }, 1200);
    }
  }
  async function validateSession(user){
    if(!user || !user.wallet || !user.sessionToken) return false;
    if(!client) return true;
    try{
      var res = await client.rpc('axon_get_session_status',{p_wallet:user.wallet,p_session_token:user.sessionToken});
      if(res.error && /does not exist/i.test(res.error.message || '')) return true;
      if(res.error) throw res.error;
      return !!(res.data && res.data.valid);
    }catch(error){
      console.warn('[AXON V6.8.3] Session validation warning:', error);
      return false;
    }
  }
  async function loadPlanClaims(silent){
    var user = getUser();
    if(!await validateSession(user)) return;
    if(!client){
      renderEmpty();
      setFeedback('Supabase browser client is not configured. Add the live Supabase URL and anon key in js/supabase-config.js.','error');
      return;
    }
    try{
      if(!silent) setFeedback('Refreshing paid-plan claim windows…');
      var res = await client.rpc('axon_get_dashboard',{p_wallet:user.wallet,p_session_token:user.sessionToken});
      if(res.error) throw res.error;
      var dashboard = res.data || {};
      zeroRefreshLock = false;
      renderAll(dashboard.active_plans || []);
      ensureTimers();
    }catch(error){
      console.error('[AXON V6.8.3] Paid plan claim load failed:', error);
      renderEmpty();
      setFeedback(error.message || 'Unable to load paid claim windows. Confirm the V6.7 Supabase RPCs are installed.','error');
    }
  }
  async function claimPlan(claimId){
    var user = getUser();
    if(!claimId || !client || !user) return;
    var plan = planState.find(function(item){ return String(claimIdOf(item)) === String(claimId); });
    if(!plan){ setFeedback('The selected plan could not be matched. Refresh the dashboard and try again.','error'); return; }
    if(!canClaim(plan)){
      var wait = secondsUntilNext(plan) > 0 ? ' Wait time: ' + formatDuration(secondsUntilNext(plan)) + '.' : '';
      setFeedback('This paid plan is not claimable yet.' + wait,'warn');
      return;
    }
    activeClaimId = claimId;
    renderAll(planState);
    setFeedback('Submitting daily paid-plan claim for '+(plan.plan_name || 'selected plan')+'…');
    try{
      var res = await client.rpc('axon_claim_plan_reward',{p_wallet:user.wallet,p_session_token:user.sessionToken,p_claim_account_id:claimId});
      if(res.error) throw res.error;
      setFeedback('Claim successful: '+usd((res.data && res.data.daily_claim_amount) || plan.daily_claim_amount || 0)+' added to the claim ledger.','success');
      activeClaimId = null;
      await loadPlanClaims(true);
      if(window.navigator && typeof window.navigator.vibrate === 'function') window.navigator.vibrate(24);
    }catch(error){
      activeClaimId = null;
      renderAll(planState);
      setFeedback(error.message || 'Paid-plan daily claim failed.','error');
    }
  }
  function handleClaimClick(event){
    var trigger = event.target.closest('[data-claim-account-id]');
    if(!trigger) return;
    if(trigger.tagName === 'A') return;
    var id = trigger.getAttribute('data-claim-account-id') || (event.target.closest('.v682-plan-card') && event.target.closest('.v682-plan-card').getAttribute('data-claim-account-id'));
    if(event.target.closest('button') && event.target.closest('button').disabled) return;
    claimPlan(id);
  }
  function initEvents(){
    var claimPanel = $('paidClaimStatusPanel');
    var preview = $('activePaidPlanPreview');
    if(claimPanel){
      claimPanel.addEventListener('click',handleClaimClick);
      claimPanel.addEventListener('keydown',function(event){
        if(event.key !== 'Enter' && event.key !== ' ') return;
        var card = event.target.closest('.v682-plan-card');
        if(!card) return;
        event.preventDefault();
        claimPlan(card.getAttribute('data-claim-account-id'));
      });
    }
    if(preview) preview.addEventListener('click',handleClaimClick);
  }
  function ensureTimers(){
    if(tickTimer) window.clearInterval(tickTimer);
    tickTimer = window.setInterval(updateLiveTimers, 1000);
    if(refreshTimer) window.clearInterval(refreshTimer);
    refreshTimer = window.setInterval(function(){ loadPlanClaims(true); }, 120000);
    updateLiveTimers();
  }
  function boot(){ initEvents(); loadPlanClaims(false); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();

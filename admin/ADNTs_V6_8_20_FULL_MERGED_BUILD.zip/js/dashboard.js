(function () {
  const SUPABASE_URL = window.AXON_SUPABASE_URL;
  const SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  const supabase = SUPABASE_URL && SUPABASE_ANON_KEY
    ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : null;
  const AXONAuth = window.AXONAuth;

  let freeMinerCountdownTimer = null;
  let latestFreeMinerState = null;
  let planCountdownTimers = [];
  let latestActivePlans = [];
  let latestWithdrawalSummary = null;
  let toastHideTimer = null;

  function normalizeWallet(address) {
    return AXONAuth ? AXONAuth.normalizeWallet(address) : String(address || '').trim().toLowerCase();
  }

  function formatUsd(value) {
    const num = Number(value || 0);
    return '$' + num.toFixed(2);
  }

  function formatPercent(value) {
    const num = Number(value || 0);
    return (num * 100).toFixed(1) + '%';
  }

  function formatDuration(totalSeconds) {
    const safe = Math.max(0, Math.floor(Number(totalSeconds || 0)));
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const seconds = safe % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function isValidBep20(address) {
    return /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
  }

  function showToast(message, tone) {
    const el = document.getElementById('axonToast');
    if (!el) {
      if (tone === 'error') window.alert(message);
      return;
    }
    el.textContent = message;
    el.className = 'axon-toast show' + (tone ? ' ' + tone : '');
    if (toastHideTimer) window.clearTimeout(toastHideTimer);
    toastHideTimer = window.setTimeout(function () {
      el.className = 'axon-toast';
    }, 3200);
  }

  function getUser() {
    return AXONAuth ? AXONAuth.getUser() : null;
  }

  function clearUser() {
    if (AXONAuth) AXONAuth.clearUser();
    else {
      window.localStorage.removeItem('axonUser');
      window.localStorage.removeItem('axonSelectedPlan');
      window.localStorage.removeItem('axonTransactions');
    }
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  function hasLiveSession(user) {
    return Boolean(user && user.wallet && user.sessionToken);
  }

  function buildLoginNext(target) {
    return AXONAuth ? AXONAuth.getLoginHref(target) : ('login.html?next=' + encodeURIComponent(target));
  }

  function buildReferralLink(wallet) {
    return AXONAuth ? AXONAuth.getReferralLink(wallet) : `https://axondigitalnfts.com/signup.html?ref=${wallet}`;
  }

  function isAuthError(error) {
    const message = String(error && error.message ? error.message : error || '').toLowerCase();
    return /session|log in again|invalid credentials|not authenticated|expired/.test(message);
  }

  async function validateSession(user) {
    if (!user || !user.wallet || !user.sessionToken || !supabase) return { valid: hasLiveSession(user), checked: false };
    try {
      const { data, error } = await supabase.rpc('axon_get_session_status', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken
      });
      if (error) {
        if (/does not exist/i.test(String(error.message || ''))) return { valid: true, checked: false };
        throw error;
      }
      return { valid: Boolean(data && data.valid), checked: true, expiresAt: data && data.expires_at ? data.expires_at : null };
    } catch (error) {
      if (/does not exist/i.test(String(error && error.message ? error.message : ''))) {
        return { valid: true, checked: false };
      }
      return { valid: false, checked: true, error };
    }
  }

  function showFreeMinerMessage(text, tone) {
    const box = document.getElementById('freeMinerMessage');
    if (!box) return;
    box.className = 'free-miner-message' + (tone ? ' ' + tone : '');
    box.textContent = text;
  }

  function stopFreeMinerCountdown() {
    if (freeMinerCountdownTimer) {
      window.clearInterval(freeMinerCountdownTimer);
      freeMinerCountdownTimer = null;
    }
  }

  function stopPlanCountdowns() {
    planCountdownTimers.forEach(timerId => window.clearInterval(timerId));
    planCountdownTimers = [];
  }

  function shortWallet(wallet) {
    const safe = String(wallet || '');
    if (!safe) return '—';
    return safe.slice(0, 6) + '…' + safe.slice(-4);
  }

  function populateUserInfo() {
    const user = getUser();
    const walletDisplay = document.getElementById('walletDisplay');
    const refLinkEl = document.getElementById('userReferralLink');
    const profileWalletFull = document.getElementById('profileWalletFull');

    if (!user || !user.wallet) {
      if (walletDisplay) walletDisplay.textContent = 'Wallet: —';
      if (refLinkEl) refLinkEl.textContent = 'N/A';
      if (profileWalletFull) profileWalletFull.textContent = '—';
      return null;
    }

    const link = buildReferralLink(user.wallet);
    if (walletDisplay) walletDisplay.textContent = 'Wallet: ' + shortWallet(user.wallet);
    if (profileWalletFull) profileWalletFull.textContent = user.wallet;
    if (refLinkEl) {
      refLinkEl.textContent = link;
      refLinkEl.setAttribute('data-link', link);
    }
    return user;
  }

  function renderFallbackFromLocalStorage(reasonText) {
    const raw = window.localStorage.getItem('axonTransactions');
    let items = [];
    try {
      items = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(items)) items = [];
    } catch (error) {
      items = [];
    }
    renderTransactions(items);
    renderActivePlans([]);
    renderFreeMinerRecentClaims([]);
    renderWithdrawalLoggedOutState(reasonText);
    setText('statPortfolio', '$0');
    setText('statEarnings', '$0');
    setText('statReferrals', '0');
    setText('statNFTs', '0');
    setText('referralRegisteredCount', '0');
    setText('referralVisitCount', '0');
    setText('referralLatestWallet', '—');
    setText('referralLatestDate', '—');
    setText('profileReferredBy', '—');
    const msg = document.getElementById('referralMessage');
    if (msg) msg.textContent = 'Log in with a valid AXON session to load live referral analytics.';
    renderRecentReferrals([]);
    renderFreeMinerLoggedOutState(reasonText || 'Log in to activate the free miner dashboard controls.');
  }

  function renderTransactions(items) {
    const container = document.getElementById('transactionsContainer');
    if (!container) return;
    if (!items || !items.length) {
      container.innerHTML = '<p class="body-md text-muted">No transactions yet. Free-miner claims, paid-plan daily claims, payment submissions, and completed plan cycles will appear here newest to oldest.</p>';
      return;
    }

    container.innerHTML = items.map(function (tx) {
      const amount = formatUsd(tx.amount || 0);
      const status = String(tx.status || 'pending');
      const statusColor = status === 'active' || status === 'completed' ? 'var(--em)' : (status === 'rejected' ? '#ff7d7d' : 'var(--gold)');
      const date = new Date(tx.created_at || tx.createdAt || Date.now()).toLocaleString();
      const metaBits = [];
      if (tx.plan_name) metaBits.push(tx.plan_name);
      if (tx.claim_number) metaBits.push('Claim #' + tx.claim_number);
      if (tx.source === 'payment_submission') metaBits.push('Awaiting admin review / payment record');
      if (tx.source === 'plan_claim') metaBits.push('24-hour paid-plan cycle entry');
      if (tx.source === 'free_miner_claim') metaBits.push('24-hour free-miner cycle entry');
      return `
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:16px 0;border-bottom:1px solid rgba(255,255,255,.06);flex-wrap:wrap;">
          <div>
            <div style="font-family: var(--fh); font-size: 16px; font-weight: 600; margin-bottom: 6px;">${tx.type || 'Transaction'}</div>
            <div class="body-md text-muted">${date}</div>
            <div class="body-md text-muted">${metaBits.join(' • ') || 'AXON platform entry'}</div>
          </div>
          <div style="text-align:right;">
            <div style="font-family: var(--fd); font-size: 18px; color: var(--em);">${amount}</div>
            <div style="margin-top: 6px; padding: 6px 10px; border-radius: 999px; border: 1px solid rgba(255,255,255,.08); color: ${statusColor}; font-size: 11px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;">${status}</div>
          </div>
        </div>`;
    }).join('');
  }

  function renderFreeMinerRecentClaims(items) {
    const container = document.getElementById('freeMinerRecentClaims');
    if (!container) return;
    if (!items || !items.length) {
      container.innerHTML = '<p class="body-md text-muted">No daily claims yet. Once claims begin, the newest five claim records will appear here.</p>';
      return;
    }

    container.innerHTML = items.map(function (item) {
      const date = new Date(item.claimed_at).toLocaleString();
      return `<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.06);flex-wrap:wrap;">
        <div>
          <div style="font-family: var(--fh); font-size: 15px; font-weight: 600; margin-bottom: 6px;">Free Miner Claim #${item.claim_number}</div>
          <div class="body-md text-muted">${date}</div>
        </div>
        <div style="text-align:right;">
          <div style="font-family: var(--fd); font-size: 18px; color: var(--em);">${formatUsd(item.claim_amount || 0)}</div>
          <div style="margin-top: 6px; padding: 6px 10px; border-radius: 999px; border: 1px solid rgba(255,255,255,.08); color: var(--em); font-size: 11px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;">completed</div>
        </div>
      </div>`;
    }).join('');
  }

  function renderRecentReferrals(items) {
    const container = document.getElementById('recentReferralsContainer');
    if (!container) return;
    if (!items || !items.length) {
      container.innerHTML = '<p class="body-md text-muted">No registered referrals yet. Referral link visits will still update while people open your link.</p>';
      return;
    }

    container.innerHTML = items.map(function (item) {
      const date = new Date(item.created_at).toLocaleString();
      return `<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.06);flex-wrap:wrap;">
        <div>
          <div style="font-family: var(--fh); font-size: 15px; font-weight: 600; margin-bottom: 6px;">${item.referred_wallet}</div>
          <div class="body-md text-muted">Signed up from your referral link</div>
        </div>
        <div style="text-align:right;">
          <div class="body-md text-muted">${date}</div>
        </div>
      </div>`;
    }).join('');
  }


  function showWithdrawalMessage(text, tone) {
    const box = document.getElementById('withdrawalMessage');
    if (!box) return;
    box.className = 'free-miner-message' + (tone ? ' ' + tone : '');
    box.textContent = text;
  }

  function renderWithdrawalHistory(items) {
    const container = document.getElementById('withdrawalHistory');
    if (!container) return;
    if (!items || !items.length) {
      container.innerHTML = '<p class="body-md text-muted">No withdrawal requests yet. Once you request a withdrawal, the newest requests will appear here.</p>';
      return;
    }

    container.innerHTML = items.map(function (item) {
      const date = new Date(item.created_at || Date.now()).toLocaleString();
      const status = String(item.status || 'pending').toLowerCase();
      const processed = item.processed_at ? new Date(item.processed_at).toLocaleString() : '';
      const noteBits = [];
      if (item.user_note) noteBits.push(item.user_note);
      if (item.admin_note) noteBits.push('Admin: ' + item.admin_note);
      if (processed) noteBits.push('Updated: ' + processed);
      return `<div class="withdrawal-item">
        <div>
          <div style="font-family: var(--fh); font-size: 15px; font-weight: 600; margin-bottom: 6px;">${formatUsd(item.requested_amount || 0)} → ${item.payout_wallet || '—'}</div>
          <div class="body-md text-muted">${date}</div>
          <div class="body-md text-muted">${noteBits.join(' • ') || 'Withdrawal request recorded for manual review.'}</div>
        </div>
        <div style="text-align:right;">
          <div class="withdrawal-pill ${status}">${status}</div>
        </div>
      </div>`;
    }).join('');
  }

  function renderWithdrawalLoggedOutState(reasonText) {
    latestWithdrawalSummary = null;
    setText('withdrawAvailable', '$0.00');
    setText('withdrawReserved', '$0.00');
    setText('withdrawMinimum', '$10.00');
    setText('withdrawStatus', 'Login required');
    const walletInput = document.getElementById('withdrawalWallet');
    const amountInput = document.getElementById('withdrawalAmount');
    const noteInput = document.getElementById('withdrawalNote');
    const requestBtn = document.getElementById('withdrawRequestBtn');
    if (walletInput) walletInput.value = '';
    if (amountInput) amountInput.value = '';
    if (noteInput) noteInput.value = '';
    if (requestBtn) {
      requestBtn.disabled = true;
      requestBtn.textContent = 'Request Withdrawal';
    }
    renderWithdrawalHistory([]);
    showWithdrawalMessage(reasonText || 'Log in to request withdrawals once your accumulated claims reach the $10 minimum.', 'warn');
  }

  function renderWithdrawalSummary(summary) {
    latestWithdrawalSummary = summary || null;
    const available = Number(summary?.available_balance || 0);
    const reserved = Number(summary?.reserved_amount || 0);
    const minimum = Number(summary?.minimum_withdrawal || 10);
    const canRequest = Boolean(summary?.can_request);
    const requestBtn = document.getElementById('withdrawRequestBtn');
    const walletInput = document.getElementById('withdrawalWallet');
    const amountInput = document.getElementById('withdrawalAmount');
    const latestStatus = summary?.latest_status || (canRequest ? 'available' : 'minimum not reached');

    setText('withdrawAvailable', formatUsd(available));
    setText('withdrawReserved', formatUsd(reserved));
    setText('withdrawMinimum', formatUsd(minimum));
    setText('withdrawStatus', latestStatus);

    const user = getUser();
    if (walletInput && !walletInput.value && user?.wallet) walletInput.value = user.wallet;
    if (amountInput) amountInput.min = String(minimum);
    if (requestBtn) {
      requestBtn.disabled = false;
      requestBtn.textContent = canRequest ? 'Request Withdrawal' : 'Check Withdrawal';
    }

    renderWithdrawalHistory(summary?.recent_requests || []);

    if (canRequest) {
      showWithdrawalMessage('Your claim earnings have reached the minimum threshold. Submit a withdrawal request and it will be created as pending for manual processing.', 'success');
    } else {
      showWithdrawalMessage(`Withdrawal opens once your available claim earnings reach ${formatUsd(minimum)}. Pending or processing requests are reserved automatically.`, '');
    }
  }

  async function loadWithdrawalSummary(user) {
    if (!user || !user.wallet || !user.sessionToken || !supabase) {
      renderWithdrawalLoggedOutState();
      return;
    }
    const { data, error } = await supabase.rpc('axon_get_withdrawal_summary', {
      p_wallet: user.wallet,
      p_session_token: user.sessionToken || ''
    });
    if (error) throw error;
    renderWithdrawalSummary(data || {});
  }

  async function requestWithdrawal() {
    const user = getUser();
    if (!user || !user.wallet || !user.sessionToken || !supabase) {
      renderWithdrawalLoggedOutState('Log in before requesting a withdrawal.');
      showToast('Log in again before requesting a withdrawal.', 'warn');
      return;
    }

    const requestBtn = document.getElementById('withdrawRequestBtn');
    const walletInput = document.getElementById('withdrawalWallet');
    const amountInput = document.getElementById('withdrawalAmount');
    const noteInput = document.getElementById('withdrawalNote');
    const payoutWallet = String(walletInput?.value || '').trim();
    const amount = Number(amountInput?.value || 0);
    const note = String(noteInput?.value || '').trim();
    const minimum = Number(latestWithdrawalSummary?.minimum_withdrawal || 10);
    const available = Number(latestWithdrawalSummary?.available_balance || 0);

    if (!isValidBep20(payoutWallet)) {
      showWithdrawalMessage('Enter a valid BEP20 wallet before submitting the withdrawal request.', 'warn');
      showToast('Enter a valid BEP20 receiving wallet.', 'error');
      return;
    }

    if (!amount || amount < minimum) {
      showWithdrawalMessage(`The minimum withdrawal is ${formatUsd(minimum)}. Keep claiming daily rewards until that threshold is reached.`, 'warn');
      showToast('Minimum withdrawal not reached yet.', 'warn');
      return;
    }

    if (amount > available) {
      showWithdrawalMessage(`You can request up to ${formatUsd(available)} right now. Pending or processing withdrawals are already reserved.`, 'warn');
      showToast('Requested amount is above your available withdrawal balance.', 'error');
      return;
    }

    if (requestBtn) {
      requestBtn.disabled = true;
      requestBtn.textContent = 'Submitting…';
    }

    try {
      const { error } = await supabase.rpc('axon_request_withdrawal', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken,
        p_amount: amount,
        p_payout_wallet: payoutWallet,
        p_user_note: note || null
      });
      if (error) throw error;
      if (amountInput) amountInput.value = '';
      if (noteInput) noteInput.value = '';
      await loadWithdrawalSummary(user);
      await loadFromSupabase(user);
      showWithdrawalMessage('Withdrawal request submitted successfully. It is now pending manual processing from Supabase.', 'success');
      showToast('Withdrawal request submitted.', 'success');
    } catch (error) {
      console.error(error);
      if (isAuthError(error)) {
        clearUser();
        window.location.href = buildLoginNext('dashboard.html#withdrawals');
        return;
      }
      showWithdrawalMessage(error.message || 'Withdrawal request failed.', 'warn');
      showToast(error.message || 'Withdrawal request failed.', 'error');
      if (requestBtn) {
        requestBtn.disabled = false;
        requestBtn.textContent = 'Request Withdrawal';
      }
    }
  }

  function getPlanCardStatus(item) {
    const raw = String(item.status || '').toLowerCase();
    if (raw === 'completed') return { text: 'Cycle Complete', className: 'is-completed', helper: 'This paid plan finished its allowed claim cycle.' };
    if (item.can_claim) return { text: 'Claim Ready', className: 'is-active', helper: 'The next 24-hour window is open. Claim the current cycle now.' };
    return { text: 'Cooldown Active', className: 'is-locked', helper: 'The next daily claim unlocks automatically when the 24-hour timer ends.' };
  }

  function renderActivePlans(plans) {
    latestActivePlans = Array.isArray(plans) ? plans.slice() : [];
    stopPlanCountdowns();
    const container = document.getElementById('activePlanContainer');
    if (!container) return;

    if (!latestActivePlans.length) {
      container.innerHTML = '<p class="body-md text-muted">You do not have an active paid plan yet. Once a paid plan is approved and active, it will appear here with its own 24-hour timer, animated progress bar, and claim action. The FREE NFT miner remains available above.</p>';
      return;
    }

    container.innerHTML = latestActivePlans.map(function (item, index) {
      const state = getPlanCardStatus(item);
      const progress = Math.max(0, Math.min(100, Number(item.cycle_progress_percent || (item.can_claim ? 100 : 0))));
      const cycleText = item.status === 'completed'
        ? `${item.max_claims} / ${item.max_claims} cycles completed`
        : `${Number(item.claims_completed || 0)} / ${Number(item.max_claims || 40)} cycles completed`;
      const countdownText = item.status === 'completed'
        ? 'Cycle complete'
        : (Number(item.seconds_remaining || 0) > 0 ? formatDuration(item.seconds_remaining) : 'Claim available now');
      const ctaLabel = item.status === 'completed' ? 'Cycle Complete' : (item.can_claim ? `Claim ${formatUsd(item.daily_claim_amount || 0)} Now` : 'Claim Locked');
      return `
        <div class="glass-card" style="padding:20px;margin-bottom:${index === latestActivePlans.length - 1 ? 0 : 16}px;">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;">
            <div>
              <h4 style="font-family: var(--fh); font-size: 20px; margin-bottom: 8px;">${item.plan_name} Plan</h4>
              <p class="body-md" style="color: var(--txt2); margin-bottom: 8px;">Plan amount: ${formatUsd(item.plan_price || 0)} • Daily reward: ${formatUsd(item.daily_claim_amount || 0)} • Claim rate: ${formatPercent(item.daily_rate || 0)}</p>
              <p class="body-md text-muted">${state.helper}</p>
            </div>
            <div style="padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;" class="status-pill ${state.className}">${state.text}</div>
          </div>

          <div class="free-miner-summary" style="margin-top:16px;">
            <div class="free-mini"><span>Total Claimed</span><strong class="gold">${formatUsd(item.total_claimed || 0)}</strong></div>
            <div class="free-mini"><span>Plan Runtime</span><strong class="em">${cycleText}</strong></div>
            <div class="free-mini"><span>Next Claim Window</span><strong id="plan-next-${item.claim_account_id}" style="font-size:15px;">${countdownText}</strong></div>
            <div class="free-mini"><span>Claim Status</span><strong id="plan-status-${item.claim_account_id}" style="font-size:15px;">${state.text}</strong></div>
          </div>

          <div class="free-miner-progress-wrap" style="margin-top:16px;">
            <div class="free-progress-bar"><span id="plan-progress-${item.claim_account_id}" style="width:${progress}%;"></span></div>
            <div class="free-progress-meta">
              <span id="plan-progress-text-${item.claim_account_id}">24-hour cycle progress: ${progress.toFixed(0)}%</span>
              <span>${item.status === 'completed' ? 'Maximum cycle count reached' : `Allowed claims: ${Number(item.max_claims || 40)}`}</span>
            </div>
          </div>

          <div class="free-miner-actions" style="margin-top:16px;">
            <button type="button" class="btn btn-primary paid-plan-claim-btn" data-claim-account-id="${item.claim_account_id}" ${item.can_claim && item.status !== 'completed' ? '' : 'disabled'}>${ctaLabel}</button>
          </div>
        </div>`;
    }).join('');

    container.querySelectorAll('.paid-plan-claim-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const claimAccountId = btn.getAttribute('data-claim-account-id');
        if (claimAccountId) claimPaidPlanReward(claimAccountId);
      });
    });

    startPlanCountdowns(latestActivePlans);
  }

  function startPlanCountdowns(plans) {
    stopPlanCountdowns();
    plans.forEach(function (item) {
      if (!item || item.status === 'completed') return;
      let remaining = Number(item.seconds_remaining || 0);
      const bar = document.getElementById(`plan-progress-${item.claim_account_id}`);
      const nextEl = document.getElementById(`plan-next-${item.claim_account_id}`);
      const progressText = document.getElementById(`plan-progress-text-${item.claim_account_id}`);
      const statusEl = document.getElementById(`plan-status-${item.claim_account_id}`);
      const button = document.querySelector(`.paid-plan-claim-btn[data-claim-account-id="${item.claim_account_id}"]`);

      function paint(seconds) {
        if (item.status === 'completed') {
          if (nextEl) nextEl.textContent = 'Cycle complete';
          if (progressText) progressText.textContent = '24-hour cycle progress: 100%';
          if (statusEl) statusEl.textContent = 'Cycle Complete';
          if (bar) bar.style.width = '100%';
          if (button) {
            button.disabled = true;
            button.textContent = 'Cycle Complete';
          }
          return;
        }

        const available = seconds <= 0;
        const percent = available ? 100 : Math.max(0, Math.min(100, ((86400 - seconds) / 86400) * 100));
        if (bar) bar.style.width = percent.toFixed(2) + '%';
        if (progressText) progressText.textContent = '24-hour cycle progress: ' + percent.toFixed(0) + '%';
        if (nextEl) nextEl.textContent = available ? 'Claim available now' : formatDuration(seconds);
        if (statusEl) statusEl.textContent = available ? 'Claim Ready' : 'Cooldown Active';
        if (button) {
          button.disabled = !available;
          button.textContent = available ? `Claim ${formatUsd(item.daily_claim_amount || 0)} Now` : 'Claim Locked';
        }
      }

      paint(remaining);
      if (remaining > 0) {
        const timerId = window.setInterval(function () {
          remaining -= 1;
          paint(remaining);
          if (remaining <= 0) {
            window.clearInterval(timerId);
          }
        }, 1000);
        planCountdownTimers.push(timerId);
      }
    });
  }

  function renderFreeMinerLoggedOutState(reasonText) {
    latestFreeMinerState = null;
    stopFreeMinerCountdown();
    setText('freeMinerClaimed', '$0.00');
    setText('freeMinerClaimsCompleted', '0 / 40');
    setText('freeMinerReferralGate', '0 / 1');
    setText('freeMinerNextClaim', 'Log in required');
    setText('freeMinerProgressText', '0 of 40 daily claims completed. $0.00 collected so far.');
    setText('freeMinerCountdown', 'Countdown: --:--:--');
    const statusPill = document.getElementById('freeMinerStatusPill');
    if (statusPill) {
      statusPill.className = 'status-pill is-locked';
      statusPill.textContent = 'locked';
    }
    const bar = document.getElementById('freeMinerProgressBar');
    if (bar) bar.style.width = '0%';
    const claimBtn = document.getElementById('freeMinerClaimBtn');
    const activateBtn = document.getElementById('freeMinerActivateBtn');
    if (claimBtn) {
      claimBtn.disabled = true;
      claimBtn.textContent = 'Claim $1 Now';
    }
    if (activateBtn) {
      activateBtn.disabled = true;
      activateBtn.textContent = 'Activate Miner';
    }
    renderFreeMinerRecentClaims([]);
    showFreeMinerMessage(reasonText || 'Log in with a valid AXON session to claim the free miner daily reward. The secure 24-hour timer is enforced automatically.', 'warn');
  }

  async function loadFromSupabase(user) {
    const { data, error } = await supabase.rpc('axon_get_dashboard', {
      p_wallet: user.wallet,
      p_session_token: user.sessionToken || ''
    });

    if (error) throw error;

    const latestPlan = data?.latest_plan || null;
    const activePlans = data?.active_plans || [];
    renderActivePlans(activePlans);
    renderTransactions(data?.transactions || []);

    const registeredCount = Number(data?.referrals_count || 0);
    const visitCount = Number(data?.referral_visits_count || 0);
    const recentReferrals = data?.recent_referrals || [];
    const referredBy = data?.referred_by || '';
    const totalEarnings = Number(data?.total_earnings || 0);
    const portfolioFromLatest = Number(latestPlan?.plan_price || 0);
    const portfolioFromActivePlans = Array.isArray(activePlans)
      ? activePlans.reduce(function (sum, item) {
          return sum + Number(item?.plan_price || 0);
        }, 0)
      : 0;
    const portfolioValue = portfolioFromLatest > 0 ? portfolioFromLatest : portfolioFromActivePlans;
    const activeNftsCount = Number(data?.active_nfts || (Array.isArray(activePlans) ? activePlans.filter(function (item) {
      return String(item?.status || '').toLowerCase() === 'active' || String(item?.status || '').toLowerCase() === 'completed';
    }).length : 0));

    setText('statPortfolio', formatUsd(portfolioValue));
    setText('statEarnings', formatUsd(totalEarnings));
    setText('statReferrals', String(registeredCount));
    setText('statNFTs', String(activeNftsCount));
    setText('referralRegisteredCount', String(registeredCount));
    setText('referralVisitCount', String(visitCount));
    setText('profileReferredBy', referredBy || '—');

    const latestReferral = recentReferrals.length ? recentReferrals[0] : null;
    setText('referralLatestWallet', latestReferral?.referred_wallet || '—');
    setText('referralLatestDate', latestReferral?.created_at ? new Date(latestReferral.created_at).toLocaleString() : '—');
    renderRecentReferrals(recentReferrals);

    const referralMessage = document.getElementById('referralMessage');
    if (referralMessage) {
      if (registeredCount > 0) {
        referralMessage.textContent = `You have ${registeredCount} registered referral${registeredCount === 1 ? '' : 's'} on record and ${visitCount} referral link visit${visitCount === 1 ? '' : 's'}. Registered referrals are used for the FREE NFT activation gate.`;
      } else if (visitCount > 0) {
        referralMessage.textContent = `Your referral link has already been opened ${visitCount} time${visitCount === 1 ? '' : 's'}, but no completed sign-up is attached yet. Registered referrals are what unlock the FREE NFT activation gate.`;
      } else {
        referralMessage.textContent = 'You have not referred anyone yet. Share your referral link to start earning bonus rewards and to unlock the FREE NFT activation gate.';
      }
    }
  }

  function renderFreeMinerStatus(data) {
    latestFreeMinerState = data || null;
    const status = String(data?.status || 'locked');
    const claimsCompleted = Number(data?.claims_completed || 0);
    const claimedAmount = Number(data?.claimed_amount || 0);
    const referrals = Number(data?.referral_count || 0);
    const nextClaimAt = data?.next_claim_at || null;
    const canClaim = Boolean(data?.can_claim);
    const canActivate = Boolean(data?.can_activate);
    const secondsRemaining = Number(data?.seconds_remaining || 0);

    setText('freeMinerClaimed', formatUsd(claimedAmount));
    setText('freeMinerClaimsCompleted', `${claimsCompleted} / 40`);
    setText('freeMinerReferralGate', `${Math.min(referrals, 1)} / 1`);
    setText('freeMinerNextClaim', nextClaimAt ? new Date(nextClaimAt).toLocaleString() : (claimsCompleted >= 40 ? 'Claiming complete' : 'Available now'));
    setText('freeMinerProgressText', `${claimsCompleted} of 40 daily claims completed. ${formatUsd(claimedAmount)} collected so far.`);

    const bar = document.getElementById('freeMinerProgressBar');
    if (bar) bar.style.width = `${Math.min(100, (claimsCompleted / 40) * 100)}%`;

    const statusPill = document.getElementById('freeMinerStatusPill');
    if (statusPill) {
      statusPill.className = 'status-pill is-' + status;
      statusPill.textContent = status.replace(/_/g, ' ');
    }

    const claimBtn = document.getElementById('freeMinerClaimBtn');
    const activateBtn = document.getElementById('freeMinerActivateBtn');
    if (claimBtn) {
      claimBtn.disabled = !canClaim;
      claimBtn.textContent = claimsCompleted >= 40 ? '40 / 40 Claims Completed' : (canClaim ? 'Claim $1 Now' : 'Claim Locked');
    }
    if (activateBtn) {
      activateBtn.disabled = !canActivate;
      activateBtn.textContent = canActivate ? 'Activate Miner' : 'Activation Locked';
    }

    stopFreeMinerCountdown();
    const countdownEl = document.getElementById('freeMinerCountdown');
    if (countdownEl) {
      if (canClaim) {
        countdownEl.textContent = 'Countdown: Claim available now';
      } else if (secondsRemaining > 0) {
        let liveSeconds = secondsRemaining;
        countdownEl.textContent = 'Countdown: ' + formatDuration(liveSeconds);
        freeMinerCountdownTimer = window.setInterval(function () {
          liveSeconds -= 1;
          if (liveSeconds <= 0) {
            stopFreeMinerCountdown();
            countdownEl.textContent = 'Countdown: Claim available now';
            if (claimBtn && claimsCompleted < 40) {
              claimBtn.disabled = false;
              claimBtn.textContent = 'Claim $1 Now';
            }
            showFreeMinerMessage('The 24-hour cooldown has ended. Tap Claim $1 to record the next daily reward.', 'success');
            return;
          }
          countdownEl.textContent = 'Countdown: ' + formatDuration(liveSeconds);
        }, 1000);
      } else if (claimsCompleted >= 40) {
        countdownEl.textContent = 'Countdown: Claim cycle complete';
      } else {
        countdownEl.textContent = 'Countdown: --:--:--';
      }
    }

    renderFreeMinerRecentClaims(data?.recent_claims || []);

    const activationReason = data?.activation_locked_reason || '';
    if (canActivate) {
      showFreeMinerMessage('All 40 claims are complete and the referral gate is satisfied. The miner can now be activated from this dashboard.', 'success');
    } else if (claimsCompleted >= 40 && referrals < 1) {
      showFreeMinerMessage('All 40 claims are complete, but activation stays locked until at least 1 registered referral is confirmed.', 'warn');
    } else if (activationReason) {
      showFreeMinerMessage(activationReason, '');
    } else if (!canClaim && secondsRemaining > 0) {
      showFreeMinerMessage('The claim button is disabled because the 24-hour cooldown is still active. Device time changes will not bypass this rule.', '');
    } else {
      showFreeMinerMessage('Claim once every 24 hours, complete 40 claims, then activate the miner after at least 1 referral.', '');
    }
  }

  async function loadFreeMinerStatus(user) {
    const { data, error } = await supabase.rpc('axon_get_free_miner_status', {
      p_wallet: user.wallet,
      p_session_token: user.sessionToken || ''
    });
    if (error) throw error;
    renderFreeMinerStatus(data || {});
  }

  async function claimFreeMiner() {
    const user = getUser();
    if (!user || !user.wallet || !user.sessionToken || !supabase) {
      showFreeMinerMessage('You must be logged in before the daily free-miner claim can be submitted.', 'warn');
      return;
    }
    const btn = document.getElementById('freeMinerClaimBtn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Claiming…';
    }
    try {
      const { data, error } = await supabase.rpc('axon_claim_free_miner', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken || ''
      });
      if (error) throw error;
      renderFreeMinerStatus(data || {});
      try { await loadFromSupabase(user); } catch (innerError) { console.error(innerError); }
      try { await loadWithdrawalSummary(user); } catch (innerError) { console.error(innerError); }
      showFreeMinerMessage('Daily claim recorded successfully. The next 24-hour cooldown has started.', 'success');
    } catch (error) {
      console.error(error);
      if (isAuthError(error)) clearUser();
      showFreeMinerMessage(error.message || 'Daily claim failed.', 'warn');
      if (latestFreeMinerState) renderFreeMinerStatus(latestFreeMinerState);
      else if (btn) {
        btn.disabled = false;
        btn.textContent = 'Claim $1 Now';
      }
    }
  }

  async function activateFreeMiner() {
    const user = getUser();
    if (!user || !user.wallet || !user.sessionToken || !supabase) {
      showFreeMinerMessage('You must be logged in before the FREE NFT miner can be activated.', 'warn');
      return;
    }
    const btn = document.getElementById('freeMinerActivateBtn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Activating…';
    }
    try {
      const { data, error } = await supabase.rpc('axon_activate_free_miner', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken || ''
      });
      if (error) throw error;
      renderFreeMinerStatus(data || {});
      try { await loadFromSupabase(user); } catch (innerError) { console.error(innerError); }
      try { await loadWithdrawalSummary(user); } catch (innerError) { console.error(innerError); }
      showFreeMinerMessage('FREE NFT miner activated successfully. The plan now appears as active inside your dashboard data.', 'success');
    } catch (error) {
      console.error(error);
      if (isAuthError(error)) clearUser();
      showFreeMinerMessage(error.message || 'FREE NFT activation failed.', 'warn');
      if (latestFreeMinerState) renderFreeMinerStatus(latestFreeMinerState);
    }
  }

  async function claimPaidPlanReward(claimAccountId) {
    const user = getUser();
    if (!user || !user.wallet || !user.sessionToken || !supabase) {
      alert('Log in again before claiming from an active plan.');
      return;
    }
    const button = document.querySelector(`.paid-plan-claim-btn[data-claim-account-id="${claimAccountId}"]`);
    if (button) {
      button.disabled = true;
      button.textContent = 'Claiming…';
    }
    try {
      const { error } = await supabase.rpc('axon_claim_plan_reward', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken,
        p_claim_account_id: claimAccountId
      });
      if (error) throw error;
      await loadFromSupabase(user);
      try { await loadWithdrawalSummary(user); } catch (innerError) { console.error(innerError); }
      showFreeMinerMessage('Paid-plan daily claim recorded successfully. The unified transaction history and 24-hour plan timer were refreshed.', 'success');
    } catch (error) {
      console.error(error);
      if (isAuthError(error)) {
        clearUser();
        window.location.href = buildLoginNext('dashboard.html#activePlans');
        return;
      }
      alert(error.message || 'Paid-plan claim failed.');
      if (button) {
        button.disabled = false;
        button.textContent = 'Claim Again Later';
      }
    }
  }

  window.copyReferral = function () {
    const el = document.getElementById('userReferralLink');
    const link = el ? el.getAttribute('data-link') : '';
    if (!link) return;
    navigator.clipboard.writeText(link).then(function () {
      showToast('Referral link copied to clipboard.', 'success');
    });
  };

  window.openFreeMinerPanel = function () {
    const section = document.getElementById('freeMiner');
    if (section) section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  window.selectPlan = function (name, price) {
    const user = getUser();
    if (String(name || '').toLowerCase().includes('free')) {
      if (!hasLiveSession(user)) {
        window.location.href = buildLoginNext('dashboard.html#freeMiner');
        return;
      }
      window.openFreeMinerPanel();
      return;
    }

    if (!hasLiveSession(user)) {
      window.location.href = buildLoginNext(`payment.html?plan=${encodeURIComponent(name)}&price=${encodeURIComponent(price)}`);
      return;
    }

    window.location.href = `payment.html?plan=${encodeURIComponent(name)}&price=${encodeURIComponent(price)}`;
  };

  window.logoutAxon = async function (event) {
    if (event) event.preventDefault();
    const user = getUser();
    try {
      if (supabase && hasLiveSession(user)) {
        const { error } = await supabase.rpc('axon_logout_user', {
          p_wallet: user.wallet,
          p_session_token: user.sessionToken
        });
        if (error && !/does not exist/i.test(String(error.message || ''))) console.error(error);
      }
    } catch (error) {
      console.error(error);
    } finally {
      clearUser();
      window.location.href = 'login.html?logged_out=1';
    }
  };

  function setupMobileNav() {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('navToggle');
    if (!sidebar || !toggle) return;

    const toggleSidebar = function (event) {
      if (event) event.preventDefault();
      const isOpen = sidebar.classList.toggle('open');
      document.body.style.overflow = isOpen ? 'hidden' : '';
    };

    ['click', 'touchstart'].forEach(function (eventName) {
      toggle.addEventListener(eventName, toggleSidebar, { passive: false });
    });

    sidebar.querySelectorAll('a').forEach(function (link) {
      ['click', 'touchstart'].forEach(function (eventName) {
        link.addEventListener(eventName, function () {
          if (link.getAttribute('onclick')) return;
          sidebar.classList.remove('open');
          document.body.style.overflow = '';
        }, { passive: true });
      });
    });
  }

  async function init() {
    const user = populateUserInfo();
    setupMobileNav();

    const claimBtn = document.getElementById('freeMinerClaimBtn');
    const activateBtn = document.getElementById('freeMinerActivateBtn');
    const withdrawBtn = document.getElementById('withdrawRequestBtn');
    if (claimBtn) claimBtn.addEventListener('click', claimFreeMiner);
    if (activateBtn) activateBtn.addEventListener('click', activateFreeMiner);
    if (withdrawBtn) withdrawBtn.addEventListener('click', requestWithdrawal);

    if (!user) {
      console.warn('AXON dashboard fallback: no local user session was found.');
      renderFallbackFromLocalStorage('Log in to activate the free miner dashboard controls.');
      return;
    }

    if (!user.sessionToken) {
      console.warn('AXON dashboard fallback: browser session is missing the live payment token.');
      renderFallbackFromLocalStorage('This browser still has an older dashboard session. Log in once again before submitting payment proof or claiming the FREE NFT reward.');
      return;
    }

    if (!supabase) {
      console.warn('AXON dashboard fallback: Supabase client is unavailable.');
      renderFallbackFromLocalStorage('Supabase configuration is missing on this page.');
      return;
    }

    const sessionState = await validateSession(user);
    if (!sessionState.valid) {
      clearUser();
      renderFallbackFromLocalStorage('Your login session is no longer valid. Log in again to continue.');
      return;
    }

    try {
      await loadFromSupabase(user);
    } catch (error) {
      console.error('AXON dashboard load error:', error);
      if (isAuthError(error)) {
        clearUser();
        renderFallbackFromLocalStorage('Your login session expired while loading the dashboard. Log in again to continue.');
        return;
      }
      renderFallbackFromLocalStorage('Your dashboard session is still saved, but live dashboard data could not be loaded right now.');
      populateUserInfo();
    }

    try {
      await loadFreeMinerStatus(user);
    } catch (error) {
      console.error('AXON free miner load error:', error);
      if (isAuthError(error)) {
        clearUser();
        renderFallbackFromLocalStorage('Your login session expired while loading the free miner controls. Log in again to continue.');
        return;
      }
      showFreeMinerMessage('The free miner panel is temporarily unavailable, but your login session is still active. Refresh and try again.', 'warn');
    }

    try {
      await loadWithdrawalSummary(user);
    } catch (error) {
      console.error('AXON withdrawal load error:', error);
      if (isAuthError(error)) {
        clearUser();
        renderWithdrawalLoggedOutState('Your login session expired while loading withdrawal data. Log in again to continue.');
        return;
      }
      showWithdrawalMessage('Withdrawal data is temporarily unavailable, but your login session is still active. Refresh and try again.', 'warn');
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();

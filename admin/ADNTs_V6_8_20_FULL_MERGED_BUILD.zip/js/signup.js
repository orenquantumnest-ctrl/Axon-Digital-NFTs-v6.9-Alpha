(function () {
  const SUPABASE_URL = window.AXON_SUPABASE_URL;
  const SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
  const AXONAuth = window.AXONAuth;

  function normalizeWallet(address) {
    return AXONAuth ? AXONAuth.normalizeWallet(address) : String(address || '').trim().toLowerCase();
  }

  function isValidBep20(address) {
    return AXONAuth ? AXONAuth.isValidWallet(address) : /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
  }

  function isValidPassword(password) {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^().,_~])[A-Za-z\d@$!%*?&#^().,_~]{8,}$/.test(password);
  }

  function getReferralWallet() {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get('ref') || params.get('referral') || params.get('r');
    const fromStorage = window.localStorage.getItem('axonReferralRef') || window.sessionStorage.getItem('axonReferralRef');
    if (isValidBep20(fromUrl)) return normalizeWallet(fromUrl);
    if (isValidBep20(fromStorage)) return normalizeWallet(fromStorage);
    return null;
  }

  window.handleSignUp = async function (e) {
    e.preventDefault();

    const walletInput = document.getElementById('wallet').value;
    const wallet = normalizeWallet(walletInput);
    const password = document.getElementById('password').value.trim();
    const confirm = document.getElementById('confirm').value.trim();
    const msgEl = document.getElementById('signupMessage');
    msgEl.style.color = 'var(--txt2)';
    msgEl.textContent = '';

    if (!isValidBep20(walletInput)) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Invalid wallet address. It must start with 0x and contain exactly 40 hexadecimal characters.';
      return;
    }

    if (!isValidPassword(password)) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Password must be at least 8 characters and include uppercase, lowercase, number and special character.';
      return;
    }

    if (password !== confirm) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Passwords do not match.';
      return;
    }

    if (!supabase) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Supabase config is missing. Check js/supabase-config.js.';
      return;
    }

    const referredBy = getReferralWallet();

    try {
      if (referredBy) {
        try {
          const visitorKey = window.localStorage.getItem('axonReferralVisitorKey') || (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : 'signup_' + Date.now());
          window.localStorage.setItem('axonReferralVisitorKey', visitorKey);
          await supabase.rpc('axon_track_referral_visit', {
            p_referrer_wallet: referredBy,
            p_visitor_key: visitorKey,
            p_landing_path: window.location.pathname || '/signup.html'
          });
        } catch (visitError) { console.warn('[AXON_REFERRAL_VISIT_SIGNUP]', visitError); }
      }
      const { data, error } = await supabase.rpc('axon_register_user', {
        p_wallet: wallet,
        p_password: password,
        p_referred_by: referredBy
      });

      if (error || !data) {
        console.error(error);
        msgEl.style.color = '#e74c3c';
        msgEl.textContent = error?.message || 'Could not register user.';
        return;
      }

      if (AXONAuth) {
        AXONAuth.persistUserSession(data);
      }
      if (referredBy) {
        window.localStorage.setItem('axonReferralRef', referredBy);
      }

      msgEl.style.color = 'var(--em)';
      msgEl.innerHTML = 'Sign-up successful!<br/>Your referral link: ' +
        `<a href="${window.location.origin}/signup.html?ref=${wallet}" style="color: var(--gold); text-decoration: underline;">${window.location.origin}/signup.html?ref=${wallet}</a><br/>` +
        'Redirecting to onboarding and your FREE NFT dashboard flow...';

      window.setTimeout(function () {
        window.location.href = 'onboarding.html';
      }, 1200);
    } catch (err) {
      console.error(err);
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = err.message || 'An unexpected error occurred during sign up.';
    }
  };
})();

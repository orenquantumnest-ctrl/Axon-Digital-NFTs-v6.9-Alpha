
(function(){
  'use strict';
  var REF_KEY='axonReferralRef';
  var VISITOR_KEY='axonReferralVisitorKey';
  function norm(v){return String(v||'').trim().toLowerCase();}
  function validWallet(v){return /^0x[a-f0-9]{40}$/.test(norm(v));}
  function $(id){return document.getElementById(id);} 
  function esc(v){return String(v==null?'':v).replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c];});}
  function usd(v){return '$'+Number(v||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}
  function short(v){var s=String(v||'');return s.length>18?s.slice(0,8)+'…'+s.slice(-6):(s||'—');}
  function dt(v){if(!v)return '—';var d=new Date(v);return isNaN(d.getTime())?'—':d.toLocaleString();}
  function getClient(){
    if(window.axonSupabase) return window.axonSupabase;
    if(window.supabase && window.AXON_SUPABASE_URL && window.AXON_SUPABASE_ANON_KEY){
      window.axonSupabase=window.supabase.createClient(window.AXON_SUPABASE_URL,window.AXON_SUPABASE_ANON_KEY,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
      return window.axonSupabase;
    }
    return null;
  }
  function visitorKey(){
    try{var k=localStorage.getItem(VISITOR_KEY);if(k)return k; k=(crypto&&crypto.randomUUID?crypto.randomUUID():'rv_'+Math.random().toString(36).slice(2)+Date.now());localStorage.setItem(VISITOR_KEY,k);return k;}catch(_){return 'rv_'+Date.now();}
  }
  function getActiveRef(){
    var p=new URLSearchParams(location.search);
    var direct=norm(p.get('ref')||p.get('referral')||p.get('r')||'');
    if(validWallet(direct)) return direct;
    try{var saved=norm(localStorage.getItem(REF_KEY)); if(validWallet(saved)) return saved;}catch(_){}
    return '';
  }
  function storeRef(ref){ if(validWallet(ref)){try{localStorage.setItem(REF_KEY,norm(ref));sessionStorage.setItem(REF_KEY,norm(ref));}catch(_){}} }
  function rewriteLinks(ref){
    if(!validWallet(ref)) return;
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href')||'';
      if(!/(signup|login|index)\.html/i.test(href)) return;
      try{var u=new URL(href,location.href); if(/index\.html/i.test(href)===false) u.searchParams.set('ref',ref); a.setAttribute('href',u.pathname.split('/').pop()+u.search);}catch(_){}
    });
  }
  async function trackVisit(ref){
    if(!validWallet(ref)) return;
    var user=window.AXONAuth&&window.AXONAuth.getUser?window.AXONAuth.getUser():null;
    if(user&&norm(user.wallet)===norm(ref)) return;
    var client=getClient(); if(!client) return;
    try{await client.rpc('axon_track_referral_visit',{p_referrer_wallet:ref,p_visitor_key:visitorKey(),p_landing_path:location.pathname||'/'});}catch(e){try{console.warn('[AXON_REFERRAL_VISIT]',e);}catch(_){}}
  }
  function currentUser(){return window.AXONAuth&&window.AXONAuth.getUser?window.AXONAuth.getUser():null;}
  function referralLink(wallet){var w=norm(wallet);return w?location.origin+'/signup.html?ref='+encodeURIComponent(w):'—';}
  function renderSummary(data){
    data=data||{}; var summary=data.summary||data; var counts=data.counts||{};
    var direct=Number(summary.direct_referrals||counts.direct_referrals||data.referrals_count||0);
    var visits=Number(summary.referral_visits||counts.referral_visits||data.referral_visits_count||0);
    var totalEarn=Number(summary.total_referral_earnings||data.total_referral_earnings||0);
    var directEarn=Number(summary.level1_earnings||data.level1_earnings||0);
    var level2Earn=Number(summary.level2_earnings||data.level2_earnings||0);
    [['referralRegisteredCount',direct],['refCount',direct],['statReferrals',direct],['referralVisitCount',visits],['refVisits',visits]].forEach(function(x){var el=$(x[0]);if(el)el.textContent=String(x[1]);});
    [['referralEarnings',usd(totalEarn)],['referralDirectEarnings',usd(directEarn)],['referralSecondEarnings',usd(level2Earn)]].forEach(function(x){var el=$(x[0]);if(el)el.textContent=x[1];});
    var rb=$('profileReferredBy')||$('referredBy'); if(rb) rb.textContent=data.referred_by||'—';
    var link=$('userReferralLink')||$('profileReferral'); var user=currentUser(); if(link&&user&&user.wallet) link.textContent=referralLink(user.wallet);
    var msg=$('referralMessage'); if(msg){msg.textContent=direct>0?'Your referral system is active. You have '+direct+' direct referral'+(direct===1?'':'s')+' and '+visits+' tracked visit'+(visits===1?'':'s')+'.':'No completed referral signups are attached yet. Share your referral link and make sure signups happen through your URL.';}
    var latest=(data.direct_referrals&&data.direct_referrals[0])||(data.recent_referrals&&data.recent_referrals[0])||null;
    var lw=$('referralLatestWallet'); if(lw) lw.textContent=latest?(latest.referred_wallet||latest.wallet_address||'—'):'—';
    var ld=$('referralLatestDate'); if(ld) ld.textContent=latest?dt(latest.created_at||latest.registered_at):'—';
  }
  function referralRow(item,level){
    item=item||{}; var wallet=item.referred_wallet||item.wallet_address||item.referee_wallet||'';
    var deposits=Number(item.approved_deposit_total||item.deposit_total||0);
    var earn=Number(item.referral_earnings||item.earnings||0);
    return '<article class="axon-referral-row" data-referral-wallet="'+esc(wallet)+'"><div><h3>'+esc(wallet||'Referral wallet')+'</h3><p>'+esc('Joined '+dt(item.created_at||item.registered_at)+' · Approved deposits '+usd(deposits)+' · Status '+(item.status||'registered'))+'</p></div><div class="amount">'+esc(usd(earn))+'</div><button type="button" class="level-pill" data-referral-open="'+esc(wallet)+'">'+esc(level||item.level||'Level 1')+'</button></article>';
  }
  function renderLists(data){
    var direct=data.direct_referrals||data.recent_referrals||[]; var level2=data.level2_referrals||[];
    var html='';
    if(direct.length){html+='<h3 class="subheading" style="font-size:20px;margin:12px 0">Direct Referrals</h3><div class="axon-referral-list">'+direct.map(function(x){return referralRow(x,'Level 1');}).join('')+'</div>';}
    if(level2.length){html+='<h3 class="subheading" style="font-size:20px;margin:18px 0 12px">Second-Level Referrals</h3><div class="axon-referral-list">'+level2.map(function(x){return referralRow(x,'Level 2');}).join('')+'</div>';}
    if(!html) html='<div class="v68-empty admin-empty">No referral records are attached to your wallet yet.</div>';
    ['recentReferralsContainer','referralsList'].forEach(function(id){var el=$(id);if(el)el.innerHTML=html;});
  }
  async function loadUserReferralSummary(){
    var user=currentUser(); if(!user||!user.wallet||!user.sessionToken) return;
    var client=getClient(); if(!client) return;
    try{var res=await client.rpc('axon_get_referral_summary',{p_wallet:user.wallet,p_session_token:user.sessionToken}); if(res.error)throw res.error; var data=res.data||{}; renderSummary(data); renderLists(data);}catch(e){try{console.warn('[AXON_REFERRAL_SUMMARY]',e);}catch(_){}}
  }
  function copyReferral(){
    var user=currentUser(); var link=referralLink(user&&user.wallet); try{navigator.clipboard&&navigator.clipboard.writeText(link);}catch(_){}; return link;
  }
  function openModal(wallet,data){
    var root=$('axonReferralModalRoot'); if(!root){root=document.createElement('div');root.id='axonReferralModalRoot';root.className='axon-referral-modal-backdrop';document.body.appendChild(root);} 
    root.innerHTML='<div class="axon-referral-modal"><h2>Referral details</h2><p>Wallet: <strong>'+esc(wallet||'—')+'</strong></p><p>This modal is used to inspect referee wallet activity, approved deposits, and referral earnings after the live referral summary loads.</p><div class="axon-referral-modal-actions"><button class="admin-btn gold v68-btn gold" type="button" data-referral-modal-close>OK</button></div></div>';
    root.classList.add('open');
  }
  document.addEventListener('click',function(ev){var o=ev.target.closest('[data-referral-open]');if(o){openModal(o.getAttribute('data-referral-open'));return;} if(ev.target.closest('[data-referral-modal-close]')){var r=$('axonReferralModalRoot'); if(r)r.classList.remove('open');}});
  window.copyReferral=copyReferral;
  document.addEventListener('DOMContentLoaded',function(){var ref=getActiveRef(); if(ref){storeRef(ref);rewriteLinks(ref);trackVisit(ref);} loadUserReferralSummary();});
})();

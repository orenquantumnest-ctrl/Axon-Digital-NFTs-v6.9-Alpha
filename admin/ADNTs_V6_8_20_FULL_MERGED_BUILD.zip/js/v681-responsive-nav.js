(function(){
  function init(){
    document.querySelectorAll('.v68-topbar').forEach(function(bar){
      var btn=bar.querySelector('.v681-menu-toggle');
      var menu=bar.querySelector('.v68-menu');
      if(!btn||!menu)return;
      function close(){document.body.classList.remove('v681-nav-open');btn.setAttribute('aria-expanded','false');}
      function toggle(){var open=!document.body.classList.contains('v681-nav-open');document.body.classList.toggle('v681-nav-open',open);btn.setAttribute('aria-expanded',String(open));}
      btn.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();toggle();});
      menu.addEventListener('click',function(e){if(e.target.closest('a'))close();});
      document.addEventListener('click',function(e){if(!bar.contains(e.target))close();});
      document.addEventListener('keydown',function(e){if(e.key==='Escape')close();});
      window.addEventListener('resize',function(){if(window.innerWidth>820)close();},{passive:true});
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

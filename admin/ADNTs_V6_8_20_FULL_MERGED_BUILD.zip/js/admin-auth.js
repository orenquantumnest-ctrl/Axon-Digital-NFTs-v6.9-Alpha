(function () {
  'use strict';

  var TOKEN_KEY = 'axonAdminSessionToken';
  var META_KEY = 'axonAdminSessionMeta';
  var TIMEOUT_MS = 25000;
  var DEFAULT_WALLET = (window.AXON_CONFIG && window.AXON_CONFIG.adminWalletAddress) || '0x7bbc456c2c34972723cf03b9d44323d2539514de';
  var client = null;

  function cfgUrl() {
    return String(window.AXON_SUPABASE_URL || window.SUPABASE_URL || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseUrl) || '').replace(/\/+$/, '');
  }

  function cfgKey() {
    return String(window.AXON_SUPABASE_ANON_KEY || window.SUPABASE_ANON_KEY || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseAnonKey) || '');
  }

  function hasSdk() {
    return !!(window.supabase && typeof window.supabase.createClient === 'function');
  }

  function getClient() {
    if (window.axonSupabase) return window.axonSupabase;
    if (client) return client;
    if (!hasSdk() || !cfgUrl() || !cfgKey()) return null;
    client = window.supabase.createClient(cfgUrl(), cfgKey(), {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      global: { headers: { 'X-Client-Info': 'axon-admin-swiftui-v6819' } }
    });
    window.axonSupabase = client;
    return client;
  }

  function withTimeout(promise, ms, label) {
    var timer;
    var timeout = new Promise(function (_, reject) {
      timer = setTimeout(function () { reject(new Error(label || 'Supabase request timed out.')); }, ms || TIMEOUT_MS);
    });
    return Promise.race([promise, timeout]).finally(function () { clearTimeout(timer); });
  }

  function restRpc(name, args) {
    var url = cfgUrl();
    var key = cfgKey();
    if (!url || !key) return Promise.reject(new Error('Supabase config missing. Confirm js/config.js and js/supabase-config.js are uploaded.'));
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, TIMEOUT_MS) : null;
    return fetch(url + '/rest/v1/rpc/' + encodeURIComponent(name), {
      method: 'POST',
      headers: {
        apikey: key,
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Client-Info': 'axon-admin-swiftui-rest-v6819'
      },
      body: JSON.stringify(args || {}),
      credentials: 'omit',
      cache: 'no-store',
      mode: 'cors',
      signal: controller ? controller.signal : undefined
    }).then(function (response) {
      if (timer) clearTimeout(timer);
      return response.text().then(function (text) {
        var parsed = null;
        if (text) {
          try { parsed = JSON.parse(text); } catch (_) { parsed = text; }
        }
        if (!response.ok) {
          var message = parsed && parsed.message ? parsed.message : (typeof parsed === 'string' ? parsed : text);
          throw new Error('RPC ' + name + ' failed with HTTP ' + response.status + (message ? ': ' + message : ''));
        }
        return parsed;
      });
    }).catch(function (error) {
      if (timer) clearTimeout(timer);
      throw error;
    });
  }

  async function rpc(name, args) {
    var sb = getClient();
    if (sb) {
      try {
        var res = await withTimeout(sb.rpc(name, args || {}), TIMEOUT_MS, 'Supabase JS RPC ' + name + ' timed out.');
        if (res && res.error) throw res.error;
        return res ? res.data : null;
      } catch (sdkError) {
        try { console.warn('[AXON_ADMIN_RPC_SDK_FALLBACK]', name, sdkError); } catch (_) {}
        return restRpc(name, args || {});
      }
    }
    return restRpc(name, args || {});
  }

  function setCookie(name, value, maxAgeSeconds) {
    try {
      var secure = location.protocol === 'https:' ? '; Secure' : '';
      document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value || '') + '; Path=/; SameSite=Lax' + secure + (maxAgeSeconds ? '; Max-Age=' + String(maxAgeSeconds) : '');
    } catch (_) {}
  }

  function getCookie(name) {
    try {
      var key = encodeURIComponent(name) + '=';
      var parts = (document.cookie || '').split(';');
      for (var i = 0; i < parts.length; i += 1) {
        var part = parts[i].trim();
        if (part.indexOf(key) === 0) return decodeURIComponent(part.slice(key.length));
      }
    } catch (_) {}
    return '';
  }

  function readToken() {
    try { var l = localStorage.getItem(TOKEN_KEY); if (l) return l; } catch (_) {}
    try { var s = sessionStorage.getItem(TOKEN_KEY); if (s) return s; } catch (_) {}
    return getCookie(TOKEN_KEY) || '';
  }

  function storeSession(token, payload) {
    if (!token) throw new Error('Cannot store empty admin session token.');
    var expiresAt = payload && (payload.expires_at || payload.expiresAt) ? (payload.expires_at || payload.expiresAt) : null;
    var maxAge = expiresAt ? Math.max(300, Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000)) : 86400;
    var meta = JSON.stringify({
      createdAt: new Date().toISOString(),
      expiresAt: expiresAt,
      walletAddress: payload && payload.wallet_address ? payload.wallet_address : '',
      username: payload && payload.username ? payload.username : '',
      role: payload && payload.role ? payload.role : 'admin',
      displayName: payload && payload.display_name ? payload.display_name : 'AXON Admin',
      department: payload && payload.department ? payload.department : 'Operations',
      build: 'v6.8.19-admin-auth-merge'
    });
    try { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(META_KEY, meta); } catch (_) {}
    try { sessionStorage.setItem(TOKEN_KEY, token); sessionStorage.setItem(META_KEY, meta); } catch (_) {}
    setCookie(TOKEN_KEY, token, maxAge);
    setCookie(META_KEY, meta, maxAge);
  }

  function readMeta() {
    var raw = '';
    try { raw = localStorage.getItem(META_KEY) || raw; } catch (_) {}
    try { raw = raw || sessionStorage.getItem(META_KEY); } catch (_) {}
    raw = raw || getCookie(META_KEY) || '';
    if (!raw) return {};
    try { return JSON.parse(raw); } catch (_) { return {}; }
  }

  function clearSession() {
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(META_KEY); } catch (_) {}
    try { sessionStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(META_KEY); } catch (_) {}
    setCookie(TOKEN_KEY, '', -1);
    setCookie(META_KEY, '', -1);
  }

  function normalizeLoginPayload(raw) {
    var root = Array.isArray(raw) ? (raw[0] || {}) : (raw || {});
    var nested = root.data || root.result || root.payload || root.session || root.auth || root.admin || root.console || {};
    var merged = Object.assign({}, nested, root);
    return {
      ok: merged.ok !== false,
      admin_session_token: merged.admin_session_token || merged.session_token || merged.token || merged.access_token || merged.jwt || merged.adminSessionToken || merged.sessionToken || '',
      expires_at: merged.expires_at || merged.expiresAt || merged.expires || null,
      wallet_address: merged.wallet_address || merged.wallet || merged.admin_wallet_address || '',
      username: merged.username || merged.user_name || '',
      display_name: merged.display_name || merged.displayName || merged.name || 'AXON Admin',
      role: merged.role || merged.admin_role || 'admin',
      department: merged.department || merged.team || 'Operations'
    };
  }

  async function loginSuperAdmin(wallet, pin) {
    wallet = String(wallet || '').trim();
    pin = String(pin || '');
    if (!/^0x[a-fA-F0-9]{40}$/.test(wallet)) throw new Error('Enter a valid 0x admin wallet address.');
    if (!pin) throw new Error('Enter the admin PIN/password.');

    var data;
    try {
      data = await rpc('axon_admin_login_v6811', {
        p_mode: 'super',
        p_wallet_address: wallet,
        p_username: null,
        p_pin: pin
      });
    } catch (primaryError) {
      try {
        data = await rpc('axon_admin_wallet_login', { p_wallet_address: wallet, p_password: pin });
      } catch (fallbackError) {
        throw primaryError && primaryError.message ? primaryError : fallbackError;
      }
    }

    var normalized = normalizeLoginPayload(data);
    if (!normalized.admin_session_token) throw new Error('Admin login succeeded but no session token was returned. Run the V6.8.19 Supabase admin auth merge patch.');
    storeSession(normalized.admin_session_token, normalized);
    return normalized;
  }

  async function loginSubAdmin(username, pin) {
    username = String(username || '').trim();
    pin = String(pin || '');
    if (!username) throw new Error('Enter the sub-admin username.');
    if (!pin) throw new Error('Enter the sub-admin PIN.');

    var data = await rpc('axon_admin_login_v6811', {
      p_mode: 'sub',
      p_wallet_address: null,
      p_username: username,
      p_pin: pin
    });
    var normalized = normalizeLoginPayload(data);
    if (!normalized.admin_session_token) throw new Error('Sub-admin login succeeded but no session token was returned.');
    storeSession(normalized.admin_session_token, normalized);
    return normalized;
  }

  async function getConsole() {
    var sessionToken = readToken();
    if (!sessionToken) throw new Error('Admin session required. Login first.');
    return rpc('axon_admin_get_console_v6811', { p_admin_session_token: sessionToken });
  }

  window.AXONAdminAuth = {
    defaultWallet: DEFAULT_WALLET,
    rpc: rpc,
    getClient: getClient,
    loginSuperAdmin: loginSuperAdmin,
    loginSubAdmin: loginSubAdmin,
    getConsole: getConsole,
    readToken: readToken,
    readMeta: readMeta,
    storeSession: storeSession,
    clearSession: clearSession,
    config: { url: cfgUrl, key: cfgKey }
  };
})();

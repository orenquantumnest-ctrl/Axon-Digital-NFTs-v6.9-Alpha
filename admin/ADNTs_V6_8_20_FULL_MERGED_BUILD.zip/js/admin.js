(function () {
  'use strict';

  const SUPABASE_URL = window.AXON_SUPABASE_URL || window.SUPABASE_URL || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseUrl) || '';
  const SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY || window.SUPABASE_ANON_KEY || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseAnonKey) || '';
  const TOKEN_KEY = 'axonAdminSessionToken';
  const SESSION_META_KEY = 'axonAdminSessionMeta';
  const LOGIN_TIMEOUT_MS = 25000;
  const ADMIN_WALLET = (window.AXON_CONFIG && window.AXON_CONFIG.adminWalletAddress) || '0x7bbc456C2C34972723cF03b9D44323d2539514dE';
  let supabaseClient = null;

  function safeStorage(type) { try { return window[type]; } catch (_) { return null; } }
  function $(id) { return document.getElementById(id); }
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c]; }); }

  function setCookie(name, value, maxAgeSeconds) {
    try {
      const secure = location.protocol === 'https:' ? '; Secure' : '';
      document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value || '') + '; Path=/; SameSite=Lax' + secure + (maxAgeSeconds ? '; Max-Age=' + String(maxAgeSeconds) : '');
    } catch (_) {}
  }

  function getCookie(name) {
    try {
      const key = encodeURIComponent(name) + '=';
      return (document.cookie || '').split(';').map(function (part) { return part.trim(); }).filter(function (part) { return part.indexOf(key) === 0; }).map(function (part) { return decodeURIComponent(part.slice(key.length)); })[0] || '';
    } catch (_) { return ''; }
  }

  function removeCookie(name) { setCookie(name, '', -1); }

  function storeAdminSession(sessionToken, expiresAt, walletAddress) {
    const metaObject = { expiresAt: expiresAt || null, createdAt: new Date().toISOString(), walletAddress: walletAddress || '', bridge: 'v6.8.8-v67-interface-wallet-login' };
    const meta = JSON.stringify(metaObject);
    const maxAge = expiresAt ? Math.max(300, Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000)) : 86400;
    const ls = safeStorage('localStorage');
    const ss = safeStorage('sessionStorage');
    try { if (ls) { ls.setItem(TOKEN_KEY, sessionToken); ls.setItem(SESSION_META_KEY, meta); } } catch (_) {}
    try { if (ss) { ss.setItem(TOKEN_KEY, sessionToken); ss.setItem(SESSION_META_KEY, meta); } } catch (_) {}
    setCookie(TOKEN_KEY, sessionToken, maxAge);
    setCookie(SESSION_META_KEY, meta, maxAge);
  }

  function readAdminSessionToken() {
    const ls = safeStorage('localStorage');
    const ss = safeStorage('sessionStorage');
    try { const v = ls && ls.getItem(TOKEN_KEY); if (v) return v; } catch (_) {}
    try { const v = ss && ss.getItem(TOKEN_KEY); if (v) return v; } catch (_) {}
    return getCookie(TOKEN_KEY) || '';
  }

  function clearAdminSession() {
    const ls = safeStorage('localStorage');
    const ss = safeStorage('sessionStorage');
    try { if (ls) { ls.removeItem(TOKEN_KEY); ls.removeItem(SESSION_META_KEY); } } catch (_) {}
    try { if (ss) { ss.removeItem(TOKEN_KEY); ss.removeItem(SESSION_META_KEY); } } catch (_) {}
    removeCookie(TOKEN_KEY);
    removeCookie(SESSION_META_KEY);
  }

  function hasSupabaseSdk() { return !!(window.supabase && typeof window.supabase.createClient === 'function'); }

  function getSupabase() {
    if (supabaseClient) return supabaseClient;
    if (window.axonSupabase) { supabaseClient = window.axonSupabase; return supabaseClient; }
    if (!hasSupabaseSdk()) return null;
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return null;
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      global: { headers: { 'X-Client-Info': 'axon-admin-wallet-login-v688' } }
    });
    return supabaseClient;
  }

  function withTimeout(promise, ms, label) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = window.setTimeout(() => reject(new Error(label || 'Request timed out. Check network and Supabase RPC permissions.')), ms);
    });
    return Promise.race([promise, timeout]).finally(() => window.clearTimeout(timer));
  }

  async function rpc(name, args, timeoutMs, timeoutLabel) {
    const client = getSupabase();
    if (!client) {
      if (!hasSupabaseSdk()) throw new Error('Supabase SDK did not load. Check CDN/network or upload a local Supabase JS bundle.');
      throw new Error('Supabase config is missing. Check js/config.js and js/supabase-config.js.');
    }
    const result = await withTimeout(client.rpc(name, args || {}), timeoutMs || LOGIN_TIMEOUT_MS, timeoutLabel || (name + ' timed out.'));
    if (result && result.error) throw result.error;
    return result ? result.data : null;
  }

  function setBusy(el, busy, label) {
    if (!el) return;
    el.disabled = !!busy;
    el.setAttribute('aria-busy', busy ? 'true' : 'false');
    if (busy && label) {
      if (!el.dataset.oldText) el.dataset.oldText = el.textContent;
      el.textContent = label;
    } else if (el.dataset.oldText) {
      el.textContent = el.dataset.oldText;
      delete el.dataset.oldText;
    }
  }

  function showMessage(text, tone) {
    const box = $('adminMessage');
    if (!box) return;
    box.className = 'admin-message show ' + (tone || '');
    box.textContent = text;
  }

  function setPanels(authenticated) {
    const loginPanel = $('adminLoginPanel');
    const consolePanel = $('adminConsolePanel');
    if (loginPanel) loginPanel.style.display = authenticated ? 'none' : 'block';
    if (consolePanel) consolePanel.style.display = authenticated ? 'block' : 'none';
  }

  function normalizeWallet(value) { return String(value || '').trim(); }

  async function login(event) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const walletInput = $('adminWallet');
    const passwordInput = $('adminPassword');
    const wallet = normalizeWallet(walletInput ? walletInput.value : ADMIN_WALLET);
    const password = passwordInput ? passwordInput.value : '';

    if (!wallet || !/^0x[a-fA-F0-9]{40}$/.test(wallet)) {
      showMessage('Enter the exact admin wallet address: ' + ADMIN_WALLET, 'warn');
      return;
    }
    if (!password || password.length < 12) {
      showMessage('Enter the full admin password.', 'warn');
      return;
    }

    const btn = $('adminLoginBtn');
    setBusy(btn, true, 'Verifying…');
    showMessage('Verifying admin wallet and password with Supabase…', 'warn');

    try {
      const data = await rpc('axon_admin_wallet_login', { p_wallet_address: wallet, p_password: password }, LOGIN_TIMEOUT_MS, 'Admin wallet login timed out after 25 seconds.');
      if (!data || !data.admin_session_token) throw new Error('Wallet admin login returned no session token. Run the V6.8.6 wallet patch and V6.8.7 schema patch.');
      storeAdminSession(data.admin_session_token, data.expires_at || null, wallet);
      if (passwordInput) passwordInput.value = '';
      setPanels(true);
      showMessage('Admin login active. Opening dashboard…', 'success');
      window.setTimeout(function () { window.location.href = 'admin-dashboard.html?fresh=688'; }, 450);
    } catch (error) {
      console.error('[AXON ADMIN WALLET LOGIN ERROR]', error);
      showMessage(error.message || 'Admin wallet login failed. Check wallet, password, SQL patch, and Supabase project.', 'error');
    } finally {
      setBusy(btn, false);
    }
  }

  function logout() {
    clearAdminSession();
    setPanels(false);
    showMessage('Admin session cleared from this browser.', 'warn');
  }

  function wire() {
    const form = $('adminLoginForm');
    const walletInput = $('adminWallet');
    if (walletInput && !walletInput.value) walletInput.value = ADMIN_WALLET;
    if (form) form.addEventListener('submit', login);
    document.querySelectorAll('[data-admin-logout]').forEach(function (el) { el.addEventListener('click', logout); });
    if (readAdminSessionToken()) {
      setPanels(true);
      showMessage('Admin session already active in this browser. Open dashboard or clear session.', 'success');
    } else {
      setPanels(false);
    }
  }

  window.AXONAdminLogin = {
    login: login,
    logout: logout,
    readAdminSessionToken: readAdminSessionToken,
    storeAdminSession: storeAdminSession,
    clearAdminSession: clearAdminSession,
    rpc: rpc
  };

  document.addEventListener('DOMContentLoaded', wire);
})();

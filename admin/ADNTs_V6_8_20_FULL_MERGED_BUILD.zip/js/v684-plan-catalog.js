
(function(){
  'use strict';
  var DEFAULT_PLANS = [
    {plan_code:'free-nft', payment_key:'FREE NFT', plan_name:'FREE NFT', plan_price:40, daily_rate:2.5, daily_claim_amount:1, max_claims:40, max_unlocks:1, sort_order:0, badge:'Referral Gate', category:'free', is_visible:true, is_featured:false, status:'active', description:'Free miner entry route. Claim $1 daily for 40 days after activation rules are satisfied.'},
    {plan_code:'lite-20', payment_key:'Lite', plan_name:'Lite', plan_price:20, daily_rate:3, daily_claim_amount:.60, max_claims:40, max_unlocks:10, sort_order:1, badge:'Entry', category:'starter', is_visible:true, is_featured:true, status:'active', description:'Low-entry paid plan for users starting their first paid AXON daily claim cycle.'},
    {plan_code:'starter-50', payment_key:'Starter', plan_name:'Starter', plan_price:50, daily_rate:3, daily_claim_amount:1.50, max_claims:40, max_unlocks:7, sort_order:2, badge:'Popular', category:'starter', is_visible:true, is_featured:true, status:'active', description:'Balanced starter plan with a 40-day claim cycle and dashboard countdown support.'},
    {plan_code:'bronze-100', payment_key:'Bronze', plan_name:'Bronze', plan_price:100, daily_rate:3, daily_claim_amount:3, max_claims:40, max_unlocks:5, sort_order:3, badge:'Growth', category:'growth', is_visible:true, is_featured:false, status:'active', description:'Expanded paid plan cycle for users increasing their claim base.'},
    {plan_code:'silver-200', payment_key:'Silver', plan_name:'Silver', plan_price:200, daily_rate:3, daily_claim_amount:6, max_claims:40, max_unlocks:3, sort_order:4, badge:'Advanced', category:'growth', is_visible:true, is_featured:true, status:'active', description:'Higher-tier paid cycle with clear daily claim progress and plan completion tracking.'},
    {plan_code:'gold-500', payment_key:'Gold', plan_name:'Gold', plan_price:500, daily_rate:3.5, daily_claim_amount:17.50, max_claims:40, max_unlocks:2, sort_order:5, badge:'Premium', category:'premium', is_visible:true, is_featured:true, status:'active', description:'Premium cycle for experienced users who want the highest listed plan tier.'}
  ];
  var client = null;
  if(window.AXON_SUPABASE_URL && window.AXON_SUPABASE_ANON_KEY && window.supabase){
    client = window.supabase.createClient(window.AXON_SUPABASE_URL, window.AXON_SUPABASE_ANON_KEY);
  }
  var page = (document.body && document.body.dataset && document.body.dataset.page) || '';
  var currentFilter = 'all';
  function $(id){ return document.getElementById(id); }
  function esc(value){ return String(value == null ? '' : value).replace(/[&<>'"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]; }); }
  function usd(value){ return '$' + Number(value || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
  function percent(value){ return Number(value || 0).toLocaleString(undefined,{maximumFractionDigits:2}) + '%'; }
  function toBool(v){ return v === true || v === 'true' || v === 1 || v === '1'; }
  function normalizePlan(plan,index){
    var price = Number(plan.plan_price || plan.price || 0);
    var rate = Number(plan.daily_rate || 0);
    var daily = Number(plan.daily_claim_amount || (price && rate ? price * rate / 100 : 0));
    var code = String(plan.plan_code || plan.code || plan.slug || (String(plan.plan_name || 'plan').toLowerCase().replace(/[^a-z0-9]+/g,'-'))).replace(/^-+|-+$/g,'') || ('plan-'+index);
    return {
      id: plan.id || null,
      plan_code: code,
      payment_key: plan.payment_key || paymentKey(plan.plan_name, price),
      plan_name: String(plan.plan_name || plan.name || paymentKey('', price) || 'Plan'),
      plan_price: price,
      daily_rate: rate,
      daily_claim_amount: daily,
      max_claims: Number(plan.max_claims || 40),
      max_unlocks: Number(plan.max_unlocks || 1),
      sort_order: Number(plan.sort_order == null ? index : plan.sort_order),
      badge: plan.badge || (toBool(plan.is_featured) ? 'Featured' : 'Plan'),
      category: plan.category || categoryFor(price),
      is_visible: plan.is_visible !== false,
      is_featured: toBool(plan.is_featured),
      status: plan.status || 'active',
      description: plan.description || 'AXON paid plan cycle with daily claim progress and dashboard tracking.'
    };
  }
  function paymentKey(name,price){
    var n = String(name || '').replace(/ plan$/i,'').trim();
    if(/free/i.test(n)) return 'FREE NFT';
    var map = {20:'Lite',50:'Starter',100:'Bronze',200:'Silver',500:'Gold'};
    return map[Number(price)] || n || 'Lite';
  }
  function categoryFor(price){
    if(Number(price) <= 50) return 'starter';
    if(Number(price) <= 200) return 'growth';
    return 'premium';
  }
  function subscribeHref(plan){
    if(/free/i.test(plan.plan_name) || Number(plan.plan_price) === 0) return 'free-miner.html';
    return 'payment.html?plan=' + encodeURIComponent(plan.payment_key || paymentKey(plan.plan_name, plan.plan_price)) + '&price=' + encodeURIComponent(Number(plan.plan_price || 0));
  }
  function depositHref(plan){
    if(/free/i.test(plan.plan_name) || Number(plan.plan_price) === 0) return 'free-miner.html';
    return 'deposit.html?plan=' + encodeURIComponent(plan.payment_key || paymentKey(plan.plan_name, plan.plan_price)) + '&price=' + encodeURIComponent(Number(plan.plan_price || 0));
  }
  function filterPlans(plans){
    var visible = plans.filter(function(p){ return p.is_visible && String(p.status || 'active').toLowerCase() !== 'hidden'; });
    if(currentFilter === 'all') return visible;
    if(currentFilter === 'featured') return visible.filter(function(p){ return p.is_featured; });
    return visible.filter(function(p){ return p.category === currentFilter; });
  }
  async function getCatalog(){
    if(client){
      try{
        var res = await client.rpc('axon_get_plan_catalog');
        if(res.error) throw res.error;
        var raw = Array.isArray(res.data) ? res.data : (res.data && Array.isArray(res.data.plans) ? res.data.plans : []);
        if(raw.length) return raw.map(normalizePlan).sort(function(a,b){ return a.sort_order - b.sort_order; });
      }catch(error){
        console.warn('[AXON V6.8.4] Plan catalog RPC unavailable, using embedded locked catalog:', error && error.message ? error.message : error);
      }
    }
    return DEFAULT_PLANS.map(normalizePlan);
  }
  function card(plan,mode){
    var featured = plan.is_featured ? ' featured' : '';
    var isFree = /free/i.test(plan.plan_name);
    return ''+
      '<article class="v684-plan-card'+featured+'" data-v684-category="'+esc(plan.category)+'" data-plan-code="'+esc(plan.plan_code)+'">'+
        '<div>'+
          '<div class="v684-plan-top"><div><h3 class="v684-plan-title">'+esc(plan.plan_name)+'</h3><span class="v684-plan-code">'+esc(plan.plan_code)+'</span></div><span class="v684-badge">'+esc(plan.badge || (plan.is_featured?'Featured':'Plan'))+'</span></div>'+
          '<div class="v684-price">'+esc(usd(plan.plan_price))+'</div>'+
          '<p class="v684-desc">'+esc(plan.description)+'</p>'+
        '</div>'+
        '<div class="v684-plan-stats">'+
          '<div><span>Daily claim</span><strong>'+esc(usd(plan.daily_claim_amount))+'</strong></div>'+
          '<div><span>Daily rate</span><strong>'+esc(percent(plan.daily_rate))+'</strong></div>'+
          '<div><span>Duration</span><strong>'+esc(plan.max_claims)+' days</strong></div>'+
          '<div><span>Unlock limit</span><strong>'+esc(plan.max_unlocks)+'</strong></div>'+
        '</div>'+
        '<div class="v684-plan-actions">'+
          '<a class="v68-btn gold" href="'+esc(subscribeHref(plan))+'">'+(isFree?'Open Free Miner':'Subscribe')+'</a>'+
          (isFree ? '<a class="v68-btn ghost" href="free-miner.html">View Rules</a>' : '<a class="v68-btn ghost" href="'+esc(depositHref(plan))+'">Deposit Route</a>')+
        '</div>'+
      '</article>';
  }
  function renderStats(plans){
    var box = $('planCatalogStats');
    if(!box) return;
    var visible = plans.filter(function(p){ return p.is_visible; });
    var paid = visible.filter(function(p){ return !/free/i.test(p.plan_name); });
    var min = paid.reduce(function(a,p){ return Math.min(a, Number(p.plan_price || 0)); }, paid.length ? Number(paid[0].plan_price || 0) : 0);
    var maxDaily = paid.reduce(function(a,p){ return Math.max(a, Number(p.daily_claim_amount || 0)); }, 0);
    box.innerHTML = ''+
      '<div><span>Visible Plans</span><strong>'+esc(visible.length)+'</strong></div>'+
      '<div><span>Entry Price</span><strong>'+esc(usd(min || 0))+'</strong></div>'+
      '<div><span>Max Daily Claim</span><strong>'+esc(usd(maxDaily))+'</strong></div>'+
      '<div><span>Cycle Length</span><strong>40 days</strong></div>';
  }
  function renderDashboard(plans){
    var box = $('availablePlanPreview');
    if(!box) return;
    var selected = plans.filter(function(p){ return p.is_visible && !/free/i.test(p.plan_name); }).sort(function(a,b){ return (b.is_featured?1:0)-(a.is_featured?1:0) || a.sort_order-b.sort_order; }).slice(0,3);
    if(!selected.length){ box.innerHTML = '<div class="v684-plan-empty">No visible paid plans are available yet. Ask admin to enable plans from Admin → Plans.</div>'; return; }
    box.innerHTML = selected.map(function(p){ return card(p,'dashboard'); }).join('');
  }
  function renderPlansPage(plans){
    var box = $('planCatalogGrid');
    if(!box) return;
    renderStats(plans);
    var visible = filterPlans(plans);
    if(!visible.length){ box.innerHTML = '<div class="v684-plan-empty">No plans match this filter. Switch filters or ask admin to make plans visible.</div>'; return; }
    box.innerHTML = visible.map(function(p){ return card(p,'full'); }).join('');
  }
  function bindFilters(plans){
    document.querySelectorAll('[data-v684-filter]').forEach(function(btn){
      btn.addEventListener('click', function(){
        currentFilter = btn.getAttribute('data-v684-filter') || 'all';
        document.querySelectorAll('[data-v684-filter]').forEach(function(x){ x.classList.toggle('active', x === btn); });
        renderPlansPage(plans);
      });
    });
  }
  async function init(){
    if(!/dashboard|plans/.test(page) && !$('availablePlanPreview') && !$('planCatalogGrid')) return;
    var plans = await getCatalog();
    renderDashboard(plans);
    renderPlansPage(plans);
    bindFilters(plans);
  }
  window.AXON_V684_DEFAULT_PLANS = DEFAULT_PLANS.slice();
  document.addEventListener('DOMContentLoaded', init);
})();

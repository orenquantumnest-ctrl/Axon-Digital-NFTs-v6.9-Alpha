(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }
  function text(id, value, tone) {
    var el = $(id);
    if (!el) return;
    el.textContent = value;
    el.style.color = tone === 'success' ? '#00ffb2' : tone === 'error' ? '#ff8e8e' : tone === 'warn' ? '#ffd27d' : '';
  }
  function busy(button, isBusy, label) {
    if (!button) return;
    button.disabled = !!isBusy;
    if (isBusy) {
      button.dataset.oldText = button.textContent;
      button.textContent = label || 'Verifying…';
    } else if (button.dataset.oldText) {
      button.textContent = button.dataset.oldText;
      delete button.dataset.oldText;
    }
  }
  function nextUrl() {
    try {
      var params = new URLSearchParams(location.search);
      return params.get('next') || 'admin-dashboard.html?fresh=6813';
    } catch (_) {
      return 'admin-dashboard.html?fresh=6813';
    }
  }
  async function submitSuper(ev) {
    ev.preventDefault();
    var form = ev.currentTarget;
    var btn = form.querySelector('button[type="submit"]');
    var wallet = $('superWallet') ? $('superWallet').value : '';
    var pin = $('superPin') ? $('superPin').value : '';
    busy(btn, true, 'Opening Console…');
    text('adminLoginMessage', 'Verifying super-admin wallet and password with Supabase…', 'warn');
    try {
      var result = await window.AXONAdminAuth.loginSuperAdmin(wallet, pin);
      text('adminLoginMessage', 'Login approved. Opening admin dashboard for ' + (result.display_name || result.role || 'AXON Admin') + '…', 'success');
      setTimeout(function () { location.href = nextUrl(); }, 500);
    } catch (error) {
      console.error('[AXON SUPER ADMIN LOGIN]', error);
      text('adminLoginMessage', error.message || 'Super-admin login failed.', 'error');
    } finally {
      busy(btn, false);
    }
  }
  async function submitSub(ev) {
    ev.preventDefault();
    var form = ev.currentTarget;
    var btn = form.querySelector('button[type="submit"]');
    var username = $('subUsername') ? $('subUsername').value : '';
    var pin = $('subPin') ? $('subPin').value : '';
    busy(btn, true, 'Opening Console…');
    text('adminLoginMessage', 'Verifying sub-admin username and password with Supabase…', 'warn');
    try {
      var result = await window.AXONAdminAuth.loginSubAdmin(username, pin);
      text('adminLoginMessage', 'Sub-admin login approved. Opening dashboard…', 'success');
      setTimeout(function () { location.href = nextUrl(); }, 500);
    } catch (error) {
      console.error('[AXON SUB ADMIN LOGIN]', error);
      text('adminLoginMessage', error.message || 'Sub-admin login failed.', 'error');
    } finally {
      busy(btn, false);
    }
  }
  function init() {
    if (!window.AXONAdminAuth) {
      text('adminLoginMessage', 'Admin auth script did not load. Check js/admin-auth.js.', 'error');
      return;
    }
    var wallet = $('superWallet');
    if (wallet && !wallet.value) wallet.value = window.AXONAdminAuth.defaultWallet || '';
    var superForm = $('superAdminForm');
    var subForm = $('subAdminForm');
    if (superForm) superForm.addEventListener('submit', submitSuper);
    if (subForm) subForm.addEventListener('submit', submitSub);
    if (window.AXONAdminAuth.readToken()) {
      text('adminLoginMessage', 'Checking existing admin session…', 'warn');
      window.AXONAdminAuth.getConsole().then(function () {
        text('adminLoginMessage', 'Admin session already active. Opening dashboard…', 'success');
        setTimeout(function () { location.href = nextUrl(); }, 650);
      }).catch(function (error) {
        console.warn('[AXON ADMIN SESSION STALE]', error);
        window.AXONAdminAuth.clearSession();
        text('adminLoginMessage', 'Previous admin session expired. Enter wallet and PIN again.', 'warn');
      });
    }
  }
  document.addEventListener('DOMContentLoaded', init);
})();

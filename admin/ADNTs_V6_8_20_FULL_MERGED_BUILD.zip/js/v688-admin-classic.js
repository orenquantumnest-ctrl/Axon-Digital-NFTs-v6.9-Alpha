(function () {
  'use strict';

  var TOKEN_KEY = 'axonAdminSessionToken';
  var META_KEY = 'axonAdminSessionMeta';
  var RPC_TIMEOUT_MS = 25000;
  var ADMIN_WALLET = (window.AXON_CONFIG && window.AXON_CONFIG.adminWalletAddress) || '0x7bbc456C2C34972723cF03b9D44323d2539514dE';
  var page = (document.body && document.body.dataset && document.body.dataset.adminPage) || 'overview';
  var lastConsolePayload = null;

  function $(id) { return document.getElementById(id); }
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]; }); }
  function usd(v) { return '$' + Number(v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function dt(v) { if (!v) return '—'; var d = new Date(v); return isNaN(d.getTime()) ? '—' : d.toLocaleString(); }
  function short(v) { var s = String(v || ''); return s.length > 18 ? s.slice(0, 8) + '…' + s.slice(-6) : (s || '—'); }
  function lower(v) { return String(v || '').toLowerCase(); }

  function setCookie(name, value, maxAgeSeconds) {
    try {
      var secure = location.protocol === 'https:' ? '; Secure' : '';
      document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value || '') + '; Path=/; SameSite=Lax' + secure + (maxAgeSeconds ? '; Max-Age=' + String(maxAgeSeconds) : '');
    } catch (_) {}
  }

  function getCookie(name) {
    try {
      var key = encodeURIComponent(name) + '=';
      var parts = (document.cookie || '').split(';');
      for (var i = 0; i < parts.length; i += 1) {
        var p = parts[i].trim();
        if (p.indexOf(key) === 0) return decodeURIComponent(p.slice(key.length));
      }
    } catch (_) {}
    return '';
  }

  function token() {
    try { var v = localStorage.getItem(TOKEN_KEY); if (v) return v; } catch (_) {}
    try { var s = sessionStorage.getItem(TOKEN_KEY); if (s) return s; } catch (_) {}
    return getCookie(TOKEN_KEY) || '';
  }

  function storeToken(sessionToken, expiresAt, walletAddress) {
    var meta = JSON.stringify({ expiresAt: expiresAt || null, createdAt: new Date().toISOString(), walletAddress: walletAddress || '', bridge: 'v6.8.8-v67-classic-wallet-login' });
    var maxAge = expiresAt ? Math.max(300, Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000)) : 86400;
    try { localStorage.setItem(TOKEN_KEY, sessionToken); localStorage.setItem(META_KEY, meta); } catch (_) {}
    try { sessionStorage.setItem(TOKEN_KEY, sessionToken); sessionStorage.setItem(META_KEY, meta); } catch (_) {}
    setCookie(TOKEN_KEY, sessionToken, maxAge);
    setCookie(META_KEY, meta, maxAge);
  }

  function clearToken() {
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(META_KEY); } catch (_) {}
    try { sessionStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(META_KEY); } catch (_) {}
    setCookie(TOKEN_KEY, '', -1);
    setCookie(META_KEY, '', -1);
  }

  function supabaseUrl() { return String(window.AXON_SUPABASE_URL || window.SUPABASE_URL || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseUrl) || '').replace(/\/+$/, ''); }
  function supabaseAnonKey() { return String(window.AXON_SUPABASE_ANON_KEY || window.SUPABASE_ANON_KEY || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseAnonKey) || ''); }

  function getClient() {
    if (window.axonSupabase) return window.axonSupabase;
    if (window.supabase && typeof window.supabase.createClient === 'function' && supabaseUrl() && supabaseAnonKey()) {
      window.axonSupabase = window.supabase.createClient(supabaseUrl(), supabaseAnonKey(), {
        auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
        global: { headers: { 'X-Client-Info': 'axon-admin-v688-v67-classic' } }
      });
      return window.axonSupabase;
    }
    return null;
  }

  function withTimeout(promise, ms, label) {
    var timer;
    var timeout = new Promise(function (_, reject) { timer = setTimeout(function () { reject(new Error(label || 'Supabase request timed out.')); }, ms || RPC_TIMEOUT_MS); });
    return Promise.race([promise, timeout]).finally(function () { clearTimeout(timer); });
  }

  function restRpc(name, args) {
    var url = supabaseUrl();
    var key = supabaseAnonKey();
    if (!url || !key) return Promise.reject(new Error('Supabase URL/key missing. Check js/config.js.'));
    var endpoint = url + '/rest/v1/rpc/' + encodeURIComponent(name);
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, RPC_TIMEOUT_MS) : null;
    return fetch(endpoint, {
      method: 'POST',
      headers: {
        apikey: key,
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Client-Info': 'axon-admin-rest-v688-v67-classic'
      },
      body: JSON.stringify(args || {}),
      signal: controller ? controller.signal : undefined,
      credentials: 'omit',
      cache: 'no-store',
      mode: 'cors'
    }).then(function (response) {
      if (timer) clearTimeout(timer);
      return response.text().then(function (text) {
        var parsed = null;
        if (text) { try { parsed = JSON.parse(text); } catch (_) { parsed = text; } }
        if (!response.ok) {
          var msg = parsed && parsed.message ? parsed.message : (typeof parsed === 'string' ? parsed : text);
          throw new Error('REST RPC ' + name + ' failed with HTTP ' + response.status + (msg ? ': ' + msg : ''));
        }
        return parsed;
      });
    }).catch(function (error) { if (timer) clearTimeout(timer); throw error; });
  }

  async function rpc(name, args) {
    var client = getClient();
    if (client) {
      try {
        var result = await withTimeout(client.rpc(name, args || {}), RPC_TIMEOUT_MS, 'Supabase JS RPC ' + name + ' timed out.');
        if (result && result.error) throw result.error;
        return result ? result.data : null;
      } catch (sdkError) {
        try { console.warn('[AXON_ADMIN_RPC_FALLBACK]', name, sdkError); } catch (_) {}
        return restRpc(name, args || {});
      }
    }
    return restRpc(name, args || {});
  }

  function setText(id, v) { var e = $(id); if (e) e.textContent = v; }
  function setHtml(id, v) { var e = $(id); if (e) e.innerHTML = v; }
  function pill(status) { var s = lower(status || 'pending').replace(/[^a-z0-9_-]+/g, '-'); return '<span class="admin-pill ' + esc(s) + '">' + esc(status || 'pending') + '</span>'; }
  function empty(text) { return '<div class="admin-empty">' + esc(text) + '</div>'; }

  function numberFrom() {
    for (var i = 0; i < arguments.length; i += 1) {
      var value = arguments[i];
      if (value === null || value === undefined || value === '') continue;
      var n = Number(value);
      if (Number.isFinite(n)) return n;
    }
    return 0;
  }

  function normalizeConsole(raw) {
    var root = Array.isArray(raw) ? (raw[0] || {}) : (raw || {});
    var stats = root.stats || root.metrics || root.counts || root.summary || {};
    var probe = root.data_probe || root.probe || {};
    var normalizedStats = {
      users_count: numberFrom(stats.users_count, stats.total_users, stats.public_users, stats.public_users_count, stats.derived_live_wallets_count, root.users_count, probe.public_users, probe.derived_live_wallets),
      active_plans_count: numberFrom(stats.active_plans_count, stats.active_plans, probe.plan_claim_accounts_active, probe.plan_claim_accounts, probe.user_plans_active, probe.user_plans),
      pending_payments_count: numberFrom(stats.pending_payments_count, stats.pending_deposits, probe.payment_pending, probe.pending_deposits, root.pending_payments_count),
      pending_withdrawals_count: numberFrom(stats.pending_withdrawals_count, stats.pending_withdrawals, probe.withdrawal_pending, probe.pending_withdrawals, root.pending_withdrawals_count),
      transactions_count: numberFrom(stats.transactions_count, stats.transactions, probe.transactions, root.transactions_count),
      catalog_count: numberFrom(stats.catalog_count, stats.catalog_plans, probe.axon_plan_catalog, probe.plan_catalog, root.catalog_count),
      claim_accounts_count: numberFrom(stats.claim_accounts_count, probe.plan_claim_accounts, root.claim_accounts_count),
      free_miner_count: numberFrom(stats.free_miner_count, probe.free_miner_accounts, root.free_miner_count),
      total_claim_earnings: numberFrom(stats.total_claim_earnings, root.total_claim_earnings),
      reserved_withdrawals: numberFrom(stats.reserved_withdrawals, root.reserved_withdrawals)
    };
    return {
      raw: root,
      stats: normalizedStats,
      payments: root.payments || root.deposits || root.payment_submissions || [],
      withdrawals: root.withdrawals || root.withdrawal_requests || [],
      users: root.users || root.recent_users || [],
      transactions: root.transactions || root.transactions_list || root.recent_transactions || [],
      plan_accounts: root.plan_accounts || root.active_plans || root.plans || [],
      free_miner_accounts: root.free_miner_accounts || [],
      audit_logs: root.audit_logs || root.logs || [],
      system_events: root.system_events || root.events || [],
      plan_catalog: root.plan_catalog || root.catalog || [],
      session_expires_at: root.session_expires_at || root.expires_at || null,
      data_probe: probe
    };
  }

  function summarizeStats(d) {
    var s = (d && d.stats) || {};
    setText('adminUsers', s.users_count || 0);
    setText('adminPlans', s.active_plans_count || 0);
    setText('adminPayments', s.pending_payments_count || 0);
    setText('adminWithdrawals', s.pending_withdrawals_count || 0);
    setText('adminEarnings', usd(s.total_claim_earnings || 0));
    setText('adminReserved', usd(s.reserved_withdrawals || 0));
    setText('adminTransactions', s.transactions_count || 0);
    setText('adminCatalog', s.catalog_count || 0);
    setText('adminClaims', s.claim_accounts_count || 0);
    setText('adminFreeMiner', s.free_miner_count || 0);
  }

  function setStatsPending(label) {
    ['adminUsers','adminPlans','adminPayments','adminWithdrawals','adminTransactions','adminCatalog','adminClaims','adminFreeMiner'].forEach(function (id) { setText(id, label || '—'); });
    setText('adminEarnings', label || '—');
    setText('adminReserved', label || '—');
  }

  function moneyFields(item) {
    var fields = ['amount', 'plan_price', 'amount_sent', 'requested_amount', 'daily_claim_amount', 'total_claimed', 'claimed_amount'];
    for (var i = 0; i < fields.length; i += 1) if (item && item[fields[i]] != null) return usd(item[fields[i]]);
    return '';
  }

  function actionButtons(kind) {
    if (kind === 'payment') return '<button data-kind="payment" data-action="approved">Approve</button><button data-kind="payment" data-action="completed">Complete</button><button class="danger" data-kind="payment" data-action="rejected">Reject</button>';
    if (kind === 'withdraw') return '<button data-kind="withdraw" data-action="processing">Processing</button><button data-kind="withdraw" data-action="completed">Completed</button><button class="danger" data-kind="withdraw" data-action="rejected">Reject</button>';
    return '';
  }

  function record(item, kind) {
    item = item || {};
    var title = 'Admin record';
    var meta = [];
    var actions = '';
    if (kind === 'user') {
      title = short(item.wallet_address);
      meta = [item.referral_code ? 'Code ' + item.referral_code : null, item.referred_by ? 'Referred by ' + short(item.referred_by) : null, 'Joined ' + dt(item.created_at), item.active_plans_count != null ? 'Active plans ' + item.active_plans_count : null, item.available_balance != null ? 'Balance ' + usd(item.available_balance) : null, item.payment_count != null ? 'Deposits ' + item.payment_count : null, item.withdrawal_count != null ? 'Withdrawals ' + item.withdrawal_count : null].filter(Boolean);
    } else if (kind === 'payment') {
      title = (item.plan_name || 'Payment') + ' · ' + usd(item.amount_sent || item.plan_price || 0);
      meta = [short(item.wallet_address), 'TX ' + (item.tx_hash || '—'), dt(item.created_at), item.payment_notes || null, item.proof_storage_path ? 'Proof attached' : null].filter(Boolean);
      actions = actionButtons('payment');
    } else if (kind === 'withdraw') {
      title = 'Withdrawal · ' + usd(item.requested_amount || 0);
      meta = ['Owner ' + short(item.wallet_address), 'Payout ' + short(item.payout_wallet), dt(item.created_at), item.user_note || null].filter(Boolean);
      actions = actionButtons('withdraw');
    } else if (kind === 'transaction') {
      title = (item.type || 'Transaction') + ' · ' + moneyFields(item);
      meta = [short(item.wallet_address), item.plan_name || null, item.source || null, dt(item.created_at), item.notes || null].filter(Boolean);
    } else if (kind === 'plan') {
      title = (item.plan_name || item.name || 'Plan') + ' · ' + usd(item.plan_price || item.plan_price_usd || 0);
      meta = [short(item.wallet_address), item.status || null, 'Claims ' + (item.claims_completed || 0) + '/' + (item.max_claims || 40), item.next_claim_at ? 'Next ' + dt(item.next_claim_at) : null, dt(item.created_at)].filter(Boolean);
    } else if (kind === 'catalog') {
      title = (item.plan_name || 'Catalog plan') + ' · ' + usd(item.plan_price || 0);
      meta = [item.plan_code, item.category, item.is_visible ? 'Visible' : 'Hidden', item.is_featured ? 'Featured' : 'Standard', item.status, 'Daily ' + usd(item.daily_claim_amount || 0)].filter(Boolean);
    } else if (kind === 'log') {
      title = item.action_name || item.action || 'Audit event';
      meta = [item.entity_type || item.target_table || null, item.status || null, item.note || (item.details ? JSON.stringify(item.details) : null), dt(item.created_at)].filter(Boolean);
    } else {
      title = item.title || item.action || item.event_type || 'System record';
      meta = [item.status || item.severity || null, item.note || item.message || (item.payload ? JSON.stringify(item.payload) : null), dt(item.created_at)].filter(Boolean);
    }
    return '<article class="admin-record" ' + (item.id ? 'data-id="' + esc(item.id) + '"' : '') + '><div><div class="admin-record-title">' + esc(title) + '</div><div class="admin-record-meta">' + esc(meta.join(' · ') || 'AXON record') + '</div>' + ((kind === 'payment' || kind === 'withdraw') ? '<textarea class="admin-note" placeholder="Admin note"></textarea>' : '') + '</div><div class="admin-record-actions">' + (item.status ? pill(item.status) : '') + actions + '</div></article>';
  }

  function table(items, kind, emptyText) {
    if (!items || !items.length) return empty(emptyText || 'No records found.');
    return '<div class="admin-table">' + items.map(function (x) { return record(x, kind); }).join('') + '</div>';
  }

  function renderOverview(d) {
    setHtml('adminOverviewPayments', table((d.payments || []).slice(0, 6), 'payment', 'No recent payment submissions.'));
    setHtml('adminOverviewWithdrawals', table((d.withdrawals || []).slice(0, 6), 'withdraw', 'No recent withdrawal requests.'));
    setHtml('adminOverviewUsers', table((d.users || []).slice(0, 8), 'user', 'No users found yet.'));
    setHtml('adminOverviewPlans', table((d.plan_accounts || []).slice(0, 6), 'plan', 'No active plan claim accounts found.'));
    var cat = d.plan_catalog || [];
    var visible = cat.filter(function (p) { return p.is_visible !== false; }).length;
    var active = cat.filter(function (p) { return lower(p.status) === 'active'; }).length;
    var suspended = cat.filter(function (p) { return lower(p.status) === 'suspended'; }).length;
    setHtml('adminPlanCatalogSummary', '<div class="v684-catalog-stats"><div><span>Total Catalog</span><strong>' + esc(cat.length) + '</strong></div><div><span>Visible</span><strong>' + esc(visible) + '</strong></div><div><span>Active</span><strong>' + esc(active) + '</strong></div><div><span>Suspended</span><strong>' + esc(suspended) + '</strong></div></div><div class="admin-actions" style="margin-top:14px"><a class="admin-btn gold" href="admin-plans.html">Manage Plans</a><a class="admin-btn" href="plans.html">User Plans</a></div>');
  }

  function renderDiagnostics(d) {
    var probe = d.data_probe || {};
    var keys = Object.keys(probe);
    if (!keys.length) return '';
    return '<details class="admin-diagnostics"><summary>Live data probe</summary><pre>' + esc(JSON.stringify(probe, null, 2)) + '</pre></details>';
  }

  function renderPage(d) {
    summarizeStats(d);
    var map = {
      overview: function () { renderOverview(d); },
      users: function () { setHtml('adminUsersList', table(d.users || [], 'user', 'No users found in the connected Supabase project.') + renderDiagnostics(d)); },
      payments: function () { setHtml('adminPaymentsList', table(d.payments || [], 'payment', 'No payment submissions found.') + renderDiagnostics(d)); },
      withdrawals: function () { setHtml('adminWithdrawalsList', table(d.withdrawals || [], 'withdraw', 'No withdrawal requests found.') + renderDiagnostics(d)); },
      plans: function () { setHtml('adminPlansList', table(d.plan_accounts || [], 'plan', 'No active user plan accounts found yet.') + renderDiagnostics(d)); },
      transactions: function () { setHtml('adminTransactionsList', table(d.transactions || [], 'transaction', 'No transactions found.') + renderDiagnostics(d)); },
      notifications: function () { setHtml('adminNotificationsList', table(d.system_events || [], 'event', 'No system notifications/events found.') + renderDiagnostics(d)); },
      logs: function () { setHtml('adminLogsList', table(d.audit_logs || [], 'log', 'No audit logs found yet.') + renderDiagnostics(d)); },
      roles: function () { setHtml('adminRolesList', '<div class="admin-empty">Master admin access uses the official deposit wallet plus the admin password configured in Supabase. Keep passwords out of frontend files.</div>' + renderDiagnostics(d)); },
      settings: function () { setHtml('adminSettingsList', '<div class="admin-empty">Security settings are Supabase-side. Rotate the admin wallet password with <code>select public.axon_admin_set_wallet_account(\'WALLET\', \'NEW_PASSWORD\', \'Owner\');</code>.</div>' + renderDiagnostics(d)); }
    };
    (map[page] || map.overview)();
    setText('adminSessionMeta', d.session_expires_at ? 'Session expires ' + dt(d.session_expires_at) : 'Admin session active');
  }

  function inlineLoginCard(reason) {
    return '<section class="admin-panel admin-span-12 admin-section"><h2>Admin wallet login required</h2><p class="body-md text-muted">' + esc(reason || 'Login with the official deposit wallet and admin password to load live Supabase records on this page.') + '</p><form id="inlineAdminLoginForm" class="admin-section" autocomplete="off"><label class="admin-field"><span>Admin Wallet</span><input id="inlineAdminWallet" class="admin-input" type="text" value="' + esc(ADMIN_WALLET) + '" required /></label><label class="admin-field"><span>Admin Password</span><input id="inlineAdminPassword" class="admin-input" type="password" autocomplete="current-password" placeholder="Enter admin password" required /></label><div class="admin-actions"><button id="inlineAdminLoginBtn" class="primary" type="submit">Login & Load Records</button><a class="admin-btn" href="admin.html?fresh=688">Open Full Login</a></div></form></section>';
  }

  async function loginInline(ev) {
    if (ev && ev.preventDefault) ev.preventDefault();
    var wallet = String(($('inlineAdminWallet') || {}).value || ADMIN_WALLET).trim();
    var password = String(($('inlineAdminPassword') || {}).value || '');
    var btn = $('inlineAdminLoginBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }
    try {
      var data = await rpc('axon_admin_wallet_login', { p_wallet_address: wallet, p_password: password });
      if (!data || !data.admin_session_token) throw new Error('No admin session token returned. Run the V6.8.6/V6.8.7 Supabase wallet + schema patches.');
      storeToken(data.admin_session_token, data.expires_at || null, wallet);
      await load();
    } catch (error) {
      var main = $('adminMain');
      if (main) main.innerHTML = inlineLoginCard((error && error.message) || 'Admin wallet login failed.');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = 'Login & Load Records'; }
    }
  }

  function statusCard(text, tone) {
    var box = $('adminRuntimeStatus');
    if (!box) {
      var main = $('adminMain');
      if (main && !main.querySelector('#adminRuntimeStatus')) {
        var div = document.createElement('div');
        div.id = 'adminRuntimeStatus';
        div.className = 'admin-span-12';
        main.prepend(div);
        box = div;
      }
    }
    if (box) box.innerHTML = '<div class="admin-runtime-status ' + esc(tone || 'info') + '">' + esc(text) + '</div>';
  }

  async function load() {
    var main = $('adminMain');
    var t = token();
    if (!t) {
      if (main) main.innerHTML = inlineLoginCard('No admin session found for this domain. Enter the wallet and password here; no private admin key is used in V6.8.8.');
      return;
    }
    if (!supabaseUrl() || !supabaseAnonKey()) {
      if (main) main.innerHTML = inlineLoginCard('Supabase config unavailable. Check js/config.js and confirm both deployment domains contain the same Supabase URL and publishable key.');
      return;
    }
    try {
      statusCard('Loading live admin data from Supabase RPC…', 'warn');
      setStatsPending('…');
      var raw = await rpc('axon_admin_get_console', { p_admin_session_token: t });
      var data = normalizeConsole(raw);
      lastConsolePayload = data;
      if (main) main.innerHTML = '<div id="adminRuntimeStatus" class="admin-span-12"></div>';
      renderPage(data);
      statusCard('Live admin data loaded from Supabase. Admin interface: V6.7 classic skin, V6.8.7 schema bridge.', 'success');
      try { console.info('[AXON_ADMIN_CONSOLE_NORMALIZED]', data); } catch (_) {}
    } catch (error) {
      console.error('[AXON ADMIN DATA]', error);
      var m = (error && error.message) || 'Admin data RPC failed.';
      if (/session|expired|invalid/i.test(m)) clearToken();
      if (main) main.innerHTML = inlineLoginCard(m);
    }
  }

  async function update(kind, id, status, note, button) {
    var rpcName = kind === 'payment' ? 'axon_admin_update_payment_status' : 'axon_admin_update_withdrawal_status';
    var args = kind === 'payment' ? { p_admin_session_token: token(), p_payment_id: id, p_status: status, p_admin_note: note || null } : { p_admin_session_token: token(), p_withdrawal_id: id, p_status: status, p_admin_note: note || null };
    if (button) { button.disabled = true; button.textContent = 'Saving…'; }
    try { await rpc(rpcName, args); await load(); }
    catch (error) { alert((error && error.message) || 'Update failed.'); }
    finally { if (button) { button.disabled = false; } }
  }

  function delegate(ev) {
    var target = ev.target;
    if (!target || !target.closest) return;
    if (target.closest('#inlineAdminLoginForm')) return;
    var b = target.closest('button[data-kind]');
    if (!b) return;
    var row = b.closest('[data-id]');
    if (!row) return;
    var noteEl = row.querySelector('.admin-note');
    update(b.dataset.kind, row.dataset.id, b.dataset.action, noteEl ? noteEl.value : '', b);
  }

  function toggleMobileMenu() {
    var menu = $('adminMobileMenu');
    if (menu) menu.classList.toggle('open');
  }

  window.AXONAdminRuntime = {
    load: load,
    rpc: rpc,
    getToken: token,
    clearToken: clearToken,
    getLastConsolePayload: function () { return lastConsolePayload; },
    normalizeConsole: normalizeConsole
  };

  document.addEventListener('DOMContentLoaded', function () {
    document.body.addEventListener('click', delegate);
    document.body.addEventListener('submit', function (ev) { if (ev.target && ev.target.id === 'inlineAdminLoginForm') loginInline(ev); });
    document.querySelectorAll('[data-admin-logout]').forEach(function (el) { el.addEventListener('click', function () { clearToken(); location.href = 'admin.html?fresh=688'; }); });
    document.querySelectorAll('[data-admin-menu-toggle]').forEach(function (el) { el.addEventListener('click', toggleMobileMenu); });
    load();
  });
})();

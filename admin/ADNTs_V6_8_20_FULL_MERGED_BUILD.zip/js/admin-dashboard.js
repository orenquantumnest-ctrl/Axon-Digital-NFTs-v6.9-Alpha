(function () {
  'use strict';

  var lastPayload = null;

  function $(id) { return document.getElementById(id); }
  function esc(value) { return String(value == null ? '' : value).replace(/[&<>'"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c]; }); }
  function money(value) { return '$' + Number(value || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function short(value) { var s = String(value || ''); return s.length > 18 ? s.slice(0, 8) + '…' + s.slice(-6) : (s || '—'); }
  function dateTime(value) { if (!value) return '—'; var d = new Date(value); return isNaN(d.getTime()) ? '—' : d.toLocaleString(); }
  function lower(value) { return String(value || '').trim().toLowerCase(); }
  function setText(id, value) { var el = $(id); if (el) el.textContent = value; }
  function setHtml(id, value) { var el = $(id); if (el) el.innerHTML = value; }
  function status(message, tone) {
    var el = $('adminStatus');
    if (!el) return;
    el.textContent = message;
    el.style.color = tone === 'success' ? '#00ffb2' : tone === 'error' ? '#ff8e8e' : tone === 'warn' ? '#ffd27d' : 'rgba(255,255,255,.78)';
  }
  function num() {
    for (var i = 0; i < arguments.length; i += 1) {
      var v = arguments[i];
      if (v === null || v === undefined || v === '') continue;
      var n = Number(v);
      if (Number.isFinite(n)) return n;
    }
    return 0;
  }

  function normalize(raw) {
    var root = Array.isArray(raw) ? (raw[0] || {}) : (raw || {});
    var stats = root.stats || root.metrics || root.counts || root.summary || {};
    var probe = root.data_probe || root.probe || {};
    var planCatalog = root.plan_catalog || root.catalog || [];
    var auditLogs = root.audit_logs || root.logs || [];
    var users = root.users || root.recent_users || [];
    var payments = root.payments || root.payment_submissions || root.deposits || [];
    var withdrawals = root.withdrawals || root.withdrawal_requests || [];
    var transactions = root.transactions || root.transactions_list || root.recent_transactions || [];
    var planAccounts = root.plan_accounts || root.active_plans || root.user_plans || [];

    return {
      raw: root,
      users: users,
      payments: payments,
      withdrawals: withdrawals,
      transactions: transactions,
      plan_accounts: planAccounts,
      free_miner_accounts: root.free_miner_accounts || [],
      audit_logs: auditLogs,
      system_events: root.system_events || root.events || [],
      plan_catalog: planCatalog,
      admin_accounts: root.admin_accounts || root.accounts || [],
      data_probe: probe,
      session_expires_at: root.session_expires_at || root.expires_at || null,
      stats: {
        users: num(stats.users_count, stats.total_users, stats.public_users, root.users_count, probe.public_users, probe.derived_live_wallets, users.length),
        activePlans: num(stats.active_plans_count, stats.active_plans, root.active_plans_count, probe.user_plans_active, root.user_plans_active, probe.plan_claim_accounts_active, root.plan_claim_accounts_active, probe.plan_claim_accounts, probe.user_plans, planAccounts.length),
        pendingPayments: num(stats.pending_payments_count, stats.pending_deposits, root.pending_payments_count, probe.pending_deposits, payments.filter(function (x) { return lower(x.status || 'pending') === 'pending'; }).length),
        pendingWithdrawals: num(stats.pending_withdrawals_count, stats.pending_withdrawals, root.pending_withdrawals_count, probe.pending_withdrawals, withdrawals.filter(function (x) { return ['pending', 'processing'].indexOf(lower(x.status || 'pending')) >= 0; }).length),
        transactions: num(stats.transactions_count, stats.transactions, probe.transactions, transactions.length),
        catalog: num(stats.catalog_count, stats.catalog_plans, root.catalog_count, probe.axon_plan_catalog, root.axon_plan_catalog, probe.legacy_plan_catalog, root.legacy_plan_catalog, probe.plan_catalog, planCatalog.length),
        audit: num(stats.audit_count, stats.audit_logs, auditLogs.length),
        totalClaims: num(stats.total_claim_earnings, root.total_claim_earnings),
        reservedWithdrawals: num(stats.reserved_withdrawals, root.reserved_withdrawals)
      }
    };
  }

  function pill(statusValue) {
    var s = lower(statusValue || 'pending').replace(/[^a-z0-9_-]+/g, '-');
    return '<span class="withdrawal-pill ' + esc(s) + '">' + esc(statusValue || 'pending') + '</span>';
  }

  function empty(text) {
    return '<div class="detail-item"><strong>' + esc(text) + '</strong><span>No matching live Supabase records were returned for this section.</span></div>';
  }

  function itemTitle(item, fallback) {
    return item.plan_name || item.wallet_address || item.username || item.action_name || item.action || item.type || fallback || 'AXON Record';
  }

  function renderPayments(items) {
    if (!items || !items.length) return empty('No deposit/payment submissions found.');
    return items.map(function (x) {
      var id = esc(x.id || '');
      return '<div class="detail-item" data-kind="payment" data-id="' + id + '">' +
        '<strong>' + esc(itemTitle(x, 'Payment')) + '</strong>' +
        '<span>' + esc(short(x.wallet_address)) + ' · ' + esc(money(x.amount_sent || x.plan_price || 0)) + ' · ' + esc(dateTime(x.created_at)) + '</span>' +
        '<small>TX: ' + esc(x.tx_hash || '—') + '</small>' +
        '<small>Notes: ' + esc(x.payment_notes || x.admin_note || '—') + '</small>' +
        '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">' + pill(x.status || 'pending') +
        '<button class="btn btn-primary" type="button" data-action="approved">Approve</button>' +
        '<button class="btn btn-secondary" type="button" data-action="rejected">Reject</button>' +
        '</div>' +
        '<textarea class="admin-note" placeholder="Admin note" style="width:100%;margin-top:10px;border-radius:12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;padding:10px;min-height:70px;"></textarea>' +
      '</div>';
    }).join('');
  }

  function renderWithdrawals(items) {
    if (!items || !items.length) return empty('No withdrawal requests found.');
    return items.map(function (x) {
      var id = esc(x.id || '');
      return '<div class="detail-item" data-kind="withdrawal" data-id="' + id + '">' +
        '<strong>' + esc(short(x.wallet_address)) + ' requests ' + esc(money(x.requested_amount || x.amount || 0)) + '</strong>' +
        '<span>Payout: ' + esc(short(x.payout_wallet)) + ' · ' + esc(dateTime(x.created_at)) + '</span>' +
        '<small>User note: ' + esc(x.user_note || '—') + '</small>' +
        '<small>Admin note: ' + esc(x.admin_note || '—') + '</small>' +
        '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">' + pill(x.status || 'pending') +
        '<button class="btn btn-secondary" type="button" data-action="processing">Processing</button>' +
        '<button class="btn btn-primary" type="button" data-action="completed">Complete</button>' +
        '<button class="btn btn-secondary" type="button" data-action="rejected">Reject</button>' +
        '</div>' +
        '<textarea class="admin-note" placeholder="Admin note" style="width:100%;margin-top:10px;border-radius:12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;padding:10px;min-height:70px;"></textarea>' +
      '</div>';
    }).join('');
  }

  function renderUsers(items) {
    if (!items || !items.length) return empty('No users found in the connected Supabase project.');
    return items.map(function (x) {
      return '<div class="detail-item"><strong>' + esc(short(x.wallet_address)) + '</strong>' +
        '<span>Joined: ' + esc(dateTime(x.created_at)) + ' · Ref: ' + esc(x.referral_code || '—') + '</span>' +
        '<small>Active Plans: ' + esc(x.active_plans_count || 0) + ' · Payments: ' + esc(x.payment_count || 0) + ' · Withdrawals: ' + esc(x.withdrawal_count || 0) + '</small></div>';
    }).join('');
  }

  function renderAudit(items) {
    if (!items || !items.length) return empty('No audit logs found yet.');
    return items.map(function (x) {
      return '<div class="detail-item"><strong>' + esc(x.action_name || x.action || 'audit') + '</strong>' +
        '<span>' + esc(x.entity_type || x.target_table || 'system') + ' · ' + esc(dateTime(x.created_at)) + '</span>' +
        '<small>' + esc(typeof x.details === 'object' ? JSON.stringify(x.details) : (x.note || x.details || '—')) + '</small></div>';
    }).join('');
  }

  function renderTransactions(items) {
    if (!items || !items.length) return empty('No transactions found.');
    return items.map(function (x) {
      return '<div class="detail-item"><strong>' + esc(x.type || 'transaction') + ' · ' + esc(money(x.amount || 0)) + '</strong>' +
        '<span>' + esc(short(x.wallet_address)) + ' · ' + esc(x.plan_name || x.source || 'AXON') + ' · ' + esc(dateTime(x.created_at)) + '</span>' +
        '<small>Status: ' + esc(x.status || 'completed') + '</small></div>';
    }).join('');
  }

  function planRow(x) {
    var code = x.plan_code || x.plan_key || String(x.plan_name || 'plan').toLowerCase().replace(/[^a-z0-9]+/g, '-');
    return '<div class="detail-item" data-plan-code="' + esc(code) + '"><strong>' + esc(x.plan_name || 'Plan') + ' · ' + esc(money(x.plan_price || 0)) + '</strong>' +
      '<span>Daily: ' + esc(x.daily_rate || 0) + '% · Claims: ' + esc(x.max_claims || 40) + ' · Sort: ' + esc(x.sort_order || 0) + '</span>' +
      '<small>' + esc(x.description || x.category || 'AXON plan catalog') + '</small>' +
      '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">' + pill(x.status || 'active') +
      '<button class="btn btn-secondary" type="button" data-plan-edit="' + esc(code) + '">Edit</button>' +
      '<button class="btn btn-secondary" type="button" data-plan-status="' + esc(code) + '" data-status="' + (lower(x.status) === 'active' ? 'suspended' : 'active') + '">' + (lower(x.status) === 'active' ? 'Suspend' : 'Activate') + '</button>' +
      '<button class="btn btn-secondary" type="button" data-plan-delete="' + esc(code) + '">Delete</button>' +
      '</div></div>';
  }

  function renderPlans(items) {
    if (!items || !items.length) return empty('No plan catalog records found.');
    return items.map(planRow).join('');
  }

  function renderAccounts(items, meta) {
    if (!items || !items.length) {
      return '<div class="detail-item"><strong>Admin controls ready</strong><span>Create sub-admin users from this panel after running the V6.8.9 admin bridge SQL.</span><small>Current session: ' + esc((meta && (meta.displayName || meta.display_name || meta.username || meta.walletAddress)) || 'AXON Admin') + '</small></div>';
    }
    return items.map(function (x) {
      return '<div class="detail-item"><strong>' + esc(x.display_name || x.username || short(x.wallet_address)) + '</strong><span>' + esc(x.role || 'admin') + ' · ' + esc(x.department || 'Operations') + '</span><small>Status: ' + esc(x.is_active === false ? 'inactive' : (x.status || 'active')) + '</small></div>';
    }).join('');
  }

  function renderMarketCards(plans) {
    var source = (plans && plans.length ? plans : [
      { plan_name: 'Lite Plan', plan_price: 20, daily_rate: 3, status: 'active' },
      { plan_name: 'Starter Plan', plan_price: 50, daily_rate: 3, status: 'active' },
      { plan_name: 'Gold Plan', plan_price: 500, daily_rate: 3.5, status: 'active' }
    ]).slice(0, 4);
    setHtml('marketCards', source.map(function (p, i) {
      var icons = ['₿', 'Ξ', 'BNB', '◎'];
      var spark = ['spark-btc', 'spark-eth', 'spark-bnb', 'spark-sol'][i % 4];
      return '<article class="market-card"><div class="market-head"><div class="market-icon">' + esc(icons[i % icons.length]) + '</div><div class="market-title"><strong>' + esc(p.plan_name || 'AXON Plan') + '</strong><span>' + esc(p.status || 'active') + '</span></div></div><div class="market-price-row"><span class="market-price">' + esc(money(p.plan_price || 0)) + '</span><span class="market-change up">' + esc(p.daily_rate || 0) + '%</span></div><div class="market-flow"><span>Max claims: ' + esc(p.max_claims || 40) + '</span><span>Daily claim: ' + esc(money(p.daily_claim_amount || ((p.plan_price || 0) * (p.daily_rate || 0) / 100))) + '</span></div><div class="sparkline ' + spark + '"></div></article>';
    }).join(''));
  }

  function updateOverview(data) {
    var stats = data.stats || {};
    setText('sumActiveUsers', stats.users);
    setText('metaActiveUsers', stats.users ? 'Live records found' : 'No users returned');
    setText('sumPendingWithdrawals', stats.pendingWithdrawals);
    setText('metaPendingWithdrawals', stats.pendingWithdrawals ? 'Requires review' : 'Queue clear');
    setText('sumPlanCount', stats.catalog || stats.activePlans);
    setText('metaPlanCount', (stats.catalog || stats.activePlans) ? 'Catalog online' : 'No plans');
    setText('sumAuditCount', stats.audit);
    setText('metaAuditCount', stats.audit ? 'Logs available' : 'No entries');
    setText('sumPendingPayments', stats.pendingPayments);
    setText('metaPendingPayments', stats.pendingPayments ? 'Payment queue active' : 'Queue clear');
  }

  function renderAll(data) {
    var meta = window.AXONAdminAuth ? window.AXONAdminAuth.readMeta() : {};
    setText('adminIdentity', meta.displayName || meta.display_name || meta.username || 'MasterAdmin');
    setText('heroAdminName', meta.displayName || meta.display_name || meta.username || 'MasterAdmin');
    setText('adminRole', meta.role || 'Super Administrator');
    setText('heroAdminRole', meta.role || 'Super Admin');
    setText('adminDepartment', meta.department || 'Executive Control');
    setText('heroAdminDepartment', meta.department || 'Executive');

    updateOverview(data);
    renderMarketCards(data.plan_catalog);
    setHtml('recentApprovals', renderPayments((data.payments || []).filter(function (x) { return ['approved', 'completed', 'active'].indexOf(lower(x.status)) >= 0; }).slice(0, 5)));
    setHtml('withdrawalHighlights', renderWithdrawals((data.withdrawals || []).slice(0, 5)));
    setHtml('adminActivities', renderAudit((data.audit_logs || []).slice(0, 5)));
    setHtml('adminPayments', renderPayments(data.payments || []));
    setHtml('adminWithdrawals', renderWithdrawals(data.withdrawals || []));
    setHtml('adminPlans', renderPlans(data.plan_catalog || data.plan_accounts || []));
    setHtml('adminUsers', renderUsers(data.users || []));
    setHtml('adminAudit', renderAudit(data.audit_logs || []));
    setHtml('adminAccounts', renderAccounts(data.admin_accounts || [], meta));
    setHtml('cryptoMarqueeTrack', [
      ['Users', data.stats.users, 'up'],
      ['Deposits', data.stats.pendingPayments, data.stats.pendingPayments ? 'up' : 'down'],
      ['Withdrawals', data.stats.pendingWithdrawals, data.stats.pendingWithdrawals ? 'up' : 'down'],
      ['Transactions', data.stats.transactions, 'up']
    ].map(function (x) { return '<div class="crypto-pill"><strong>' + esc(x[0]) + '</strong><span>Live</span><em class="' + esc(x[2]) + '">' + esc(x[1]) + '</em></div>'; }).join(''));
  }

  async function loadDashboard() {
    if (!window.AXONAdminAuth) {
      status('Admin auth module missing. Upload js/admin-auth.js.', 'error');
      return;
    }
    if (!window.AXONAdminAuth.readToken()) {
      status('Admin session required. Redirecting to login…', 'warn');
      setTimeout(function () { location.href = 'admin.html?next=admin-dashboard.html%3Ffresh%3D6811'; }, 700);
      return;
    }
    try {
      status('Loading live Supabase admin records…', 'warn');
      var raw = await window.AXONAdminAuth.getConsole();
      lastPayload = normalize(raw);
      renderAll(lastPayload);
      status('Live admin records loaded. Users, deposits, withdrawals, plans, transactions, and audit panels are synced from Supabase.', 'success');
      try { console.info('[AXON_ADMIN_DASHBOARD_V6811]', lastPayload); } catch (_) {}
    } catch (error) {
      console.error('[AXON ADMIN DASHBOARD]', error);
      if (/session|expired|invalid/i.test(error.message || '')) {
        window.AXONAdminAuth.clearSession();
        status('Session expired. Redirecting to login…', 'warn');
        setTimeout(function () { location.href = 'admin.html?next=admin-dashboard.html%3Ffresh%3D6811'; }, 900);
        return;
      }
      status(error.message || 'Admin dashboard failed to load.', 'error');
    }
  }

  async function updateRecord(kind, id, action, note, button) {
    id = String(id || '').trim();
    if (!id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
      status('Invalid record id. Refresh the page and try again.', 'error');
      return;
    }
    if (!action) return;
    if (button) { button.dataset.originalLabel = button.textContent; button.disabled = true; button.textContent = 'Saving…'; }
    try {
      var token = window.AXONAdminAuth.readToken();
      if (kind === 'payment') {
        await window.AXONAdminAuth.rpc('axon_admin_update_payment_status', {
          p_admin_session_token: token,
          p_payment_id: id,
          p_status: action,
          p_admin_note: note || null
        });
      } else {
        await window.AXONAdminAuth.rpc('axon_admin_update_withdrawal_status', {
          p_admin_session_token: token,
          p_withdrawal_id: id,
          p_status: action,
          p_admin_note: note || null
        });
      }
      await loadDashboard();
    } catch (error) {
      status(error.message || 'Update failed.', 'error');
    } finally {
      if (button) { button.disabled = false; button.textContent = button.dataset.originalLabel || button.textContent.replace('Saving…', action.charAt(0).toUpperCase()+action.slice(1)); }
    }
  }

  function currentPlanByCode(code) {
    var list = lastPayload && lastPayload.plan_catalog ? lastPayload.plan_catalog : [];
    return list.filter(function (x) { return String(x.plan_code || x.plan_key || '').toLowerCase() === String(code || '').toLowerCase(); })[0] || null;
  }

  function fillPlan(plan) {
    if (!plan) return;
    setText('adminStatus', 'Editing plan: ' + (plan.plan_name || plan.plan_code));
    if ($('planName')) $('planName').value = plan.plan_name || '';
    if ($('planPrice')) $('planPrice').value = plan.plan_price || 0;
    if ($('planDailyRate')) $('planDailyRate').value = plan.daily_rate || 0;
    if ($('planMaxClaims')) $('planMaxClaims').value = plan.max_claims || 40;
    if ($('planSort')) $('planSort').value = plan.sort_order || 0;
    if ($('planStatus')) $('planStatus').value = lower(plan.status || 'active') === 'suspended' ? 'inactive' : (plan.status || 'active');
    if ($('planIsFree')) $('planIsFree').checked = Number(plan.plan_price || 0) <= 0 || plan.is_free === true;
    var form = $('planCatalogForm');
    if (form) {
      form.dataset.planCode = plan.plan_code || plan.plan_key || '';
      form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  async function savePlan(ev) {
    ev.preventDefault();
    var form = ev.currentTarget;
    var name = $('planName') ? $('planName').value.trim() : '';
    var price = Number(($('planPrice') || {}).value || 0);
    var rate = Number(($('planDailyRate') || {}).value || 0);
    var maxClaims = Number(($('planMaxClaims') || {}).value || 40);
    var sort = Number(($('planSort') || {}).value || 0);
    var statusValue = $('planStatus') ? $('planStatus').value : 'active';
    var isFree = $('planIsFree') ? $('planIsFree').checked : false;
    if (!name) { status('Enter a plan name first.', 'warn'); return; }
    var code = form.dataset.planCode || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    try {
      status('Saving plan catalog record…', 'warn');
      await window.AXONAdminAuth.rpc('axon_admin_upsert_plan_catalog', {
        p_admin_session_token: window.AXONAdminAuth.readToken(),
        p_plan_code: code,
        p_payment_key: isFree ? 'free_nft' : code,
        p_plan_name: name,
        p_plan_price: price,
        p_daily_rate: rate,
        p_daily_claim_amount: Number(((price * rate) / 100).toFixed(2)),
        p_max_claims: maxClaims,
        p_max_unlocks: isFree ? 1 : 3,
        p_sort_order: sort,
        p_badge: isFree ? 'FREE' : 'AXON',
        p_category: isFree ? 'free' : 'paid',
        p_description: isFree ? 'Free NFT plan' : 'AXON paid NFT plan',
        p_is_visible: true,
        p_is_featured: isFree,
        p_status: statusValue === 'inactive' ? 'suspended' : statusValue
      });
      form.reset();
      delete form.dataset.planCode;
      await loadDashboard();
    } catch (error) {
      status(error.message || 'Plan save failed.', 'error');
    }
  }

  async function setPlanStatus(code, statusValue) {
    try {
      status('Updating plan status…', 'warn');
      await window.AXONAdminAuth.rpc('axon_admin_set_plan_catalog_status', {
        p_admin_session_token: window.AXONAdminAuth.readToken(),
        p_plan_code: code,
        p_status: statusValue
      });
      await loadDashboard();
    } catch (error) { status(error.message || 'Plan status update failed.', 'error'); }
  }

  async function deletePlan(code) {
    if (!confirm('Soft-delete this plan from the marketplace? Existing user plan history remains preserved.')) return;
    try {
      status('Deleting plan from visible catalog…', 'warn');
      await window.AXONAdminAuth.rpc('axon_admin_delete_plan_catalog', {
        p_admin_session_token: window.AXONAdminAuth.readToken(),
        p_plan_code: code
      });
      await loadDashboard();
    } catch (error) { status(error.message || 'Plan delete failed.', 'error'); }
  }

  async function createSubAdmin(ev) {
    ev.preventDefault();
    var username = $('subAdminUsername') ? $('subAdminUsername').value.trim() : '';
    var pin = $('subAdminPin') ? $('subAdminPin').value : '';
    var department = $('subAdminDepartment') ? $('subAdminDepartment').value.trim() : 'operations';
    if (!username || !pin) { status('Enter sub-admin username and PIN.', 'warn'); return; }
    var permissions = {
      users: !!($('permUsers') && $('permUsers').checked),
      payments: !!($('permPayments') && $('permPayments').checked),
      withdrawals: !!($('permWithdrawals') && $('permWithdrawals').checked),
      plans: !!($('permPlans') && $('permPlans').checked),
      admins: !!($('permAdmins') && $('permAdmins').checked),
      audit: !!($('permAudit') && $('permAudit').checked)
    };
    try {
      status('Creating sub-admin account…', 'warn');
      await window.AXONAdminAuth.rpc('axon_admin_create_sub_admin_v689', {
        p_admin_session_token: window.AXONAdminAuth.readToken(),
        p_username: username,
        p_pin: pin,
        p_department: department,
        p_permissions: permissions
      });
      ev.currentTarget.reset();
      await loadDashboard();
    } catch (error) { status(error.message || 'Sub-admin creation failed.', 'error'); }
  }

  function delegate(ev) {
    var target = ev.target;
    if (!target || !target.closest) return;
    var actionButton = target.closest('button[data-action]');
    if (actionButton) {
      var row = actionButton.closest('[data-id]');
      if (!row) return;
      var noteEl = row.querySelector('.admin-note');
      updateRecord(row.dataset.kind, row.dataset.id, actionButton.dataset.action, noteEl ? noteEl.value : '', actionButton);
      return;
    }
    var edit = target.closest('[data-plan-edit]');
    if (edit) { fillPlan(currentPlanByCode(edit.dataset.planEdit)); return; }
    var statusBtn = target.closest('[data-plan-status]');
    if (statusBtn) { setPlanStatus(statusBtn.dataset.planStatus, statusBtn.dataset.status); return; }
    var del = target.closest('[data-plan-delete]');
    if (del) { deletePlan(del.dataset.planDelete); }
  }

  function wire() {
    var toggle = $('adminMenuToggle');
    var sidebar = $('adminSidebar');
    if (toggle && sidebar) toggle.addEventListener('click', function () { sidebar.classList.toggle('open'); });
    var refresh = $('refreshAdminBtn');
    if (refresh) refresh.addEventListener('click', loadDashboard);
    var refreshPay = $('refreshPaymentsBtn');
    if (refreshPay) refreshPay.addEventListener('click', loadDashboard);
    var refreshWithdraw = $('refreshWithdrawalsBtn');
    if (refreshWithdraw) refreshWithdraw.addEventListener('click', loadDashboard);
    var logout = $('logoutAdminBtn');
    if (logout) logout.addEventListener('click', function () { window.AXONAdminAuth.clearSession(); location.href = 'admin.html?fresh=6811'; });
    var planForm = $('planCatalogForm');
    if (planForm) planForm.addEventListener('submit', savePlan);
    var subForm = $('subAdminFormCreate');
    if (subForm) subForm.addEventListener('submit', createSubAdmin);
    document.body.addEventListener('click', delegate);
  }

  document.addEventListener('DOMContentLoaded', function () {
    wire();
    loadDashboard();
  });
})();

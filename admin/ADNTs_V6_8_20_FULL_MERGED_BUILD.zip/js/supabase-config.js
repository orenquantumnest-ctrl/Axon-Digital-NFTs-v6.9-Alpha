/*
  AXON DIGITAL NFTs — Supabase Compatibility Loader
  V6.8.12 Admin RPC Safari Fix
  Public browser config only. Never place service-role keys or admin passwords here.
*/
(function configureSupabaseCompatibility(global) {
  'use strict';

  var DEFAULT_CONFIG = {
    appName: 'AXON DIGITAL NFTs',
    version: '6.8.12',
    buildName: 'ADMIN_NORMALIZE_CONSOLE_CREDENTIALS_LOCKED',
    buildHash: '357f4a7ac29a947bee0a3c94031a7f09a3f0126d4bfdaacfb7de53412fa567bf',
    productionDomains: [
      'https://axondigitalnfts.com',
      'https://axonprime-vault.netlify.app'
    ],
    supabaseUrl: 'https://soulxqkznkzigsvazijp.supabase.co',
    supabaseAnonKey: 'sb_publishable_4Mn99qeGLSLC00IPHutIQQ_yOm22eHl',
    adminKeyPolicy: 'v6812-wallet-password-normalized-console',
    adminWalletAddress: '0x7bbc456c2c34972723cf03b9d44323d2539514de',
    cacheVersion: '6812'
  };

  global.AXON_CONFIG = Object.assign({}, DEFAULT_CONFIG, global.AXON_CONFIG || {});
  global.AXON_SUPABASE_URL = global.AXON_SUPABASE_URL || global.AXON_CONFIG.supabaseUrl;
  global.AXON_SUPABASE_ANON_KEY = global.AXON_SUPABASE_ANON_KEY || global.AXON_CONFIG.supabaseAnonKey;
  global.SUPABASE_URL = global.SUPABASE_URL || global.AXON_SUPABASE_URL;
  global.SUPABASE_ANON_KEY = global.SUPABASE_ANON_KEY || global.AXON_SUPABASE_ANON_KEY;
  global.AXON_PUBLIC_SUPABASE_URL = global.AXON_PUBLIC_SUPABASE_URL || global.AXON_SUPABASE_URL;
  global.AXON_PUBLIC_SUPABASE_ANON_KEY = global.AXON_PUBLIC_SUPABASE_ANON_KEY || global.AXON_SUPABASE_ANON_KEY;
  global.AXON_ENV_READY = Boolean(global.AXON_SUPABASE_URL && global.AXON_SUPABASE_ANON_KEY);

  function fail(message, details) {
    global.AXON_SUPABASE_READY = false;
    global.AXON_SUPABASE_ERROR = { message: message, details: details || null };
    try { console.error('[AXON_SUPABASE_CONFIG_ERROR]', message, details || ''); } catch (_) {}
  }

  if (!global.AXON_ENV_READY) {
    fail('Missing Supabase URL or publishable/anon key. Check js/config.js.');
    return;
  }

  if (!/^https:\/\/[a-zA-Z0-9-]+\.supabase\.co\/?$/.test(String(global.AXON_SUPABASE_URL || ''))) {
    fail('Invalid Supabase URL format.', { url: global.AXON_SUPABASE_URL });
    return;
  }

  if (global.supabase && typeof global.supabase.createClient === 'function') {
    try {
      global.axonSupabase = global.axonSupabase || global.supabase.createClient(
        global.AXON_SUPABASE_URL,
        global.AXON_SUPABASE_ANON_KEY,
        {
          auth: {
            persistSession: false,
            autoRefreshToken: false,
            detectSessionInUrl: false
          },
          global: {
            headers: {
              'X-Client-Info': 'axon-admin-v6812-uploaded-pages'
            }
          }
        }
      );
      global.AXON_SUPABASE_READY = true;
      try { console.info('[AXON_SUPABASE_READY]', global.AXON_SUPABASE_URL); } catch (_) {}
    } catch (error) {
      fail('Supabase createClient failed.', error);
    }
  } else {
    // Direct REST fallback in admin JS can still operate without the UMD SDK.
    global.AXON_SUPABASE_READY = false;
    global.AXON_SUPABASE_ERROR = { message: 'Supabase UMD SDK unavailable; REST fallback will be used where supported.' };
    try { console.warn('[AXON_SUPABASE_SDK_MISSING]', global.AXON_SUPABASE_ERROR.message); } catch (_) {}
  }
})(window);


(function(){
  'use strict';
  function boot(){
    var btn=document.querySelector('[data-admin-menu-toggle]');
    if(btn){ btn.addEventListener('click', function(){ document.body.classList.toggle('admin-pro-open'); }); }
    document.addEventListener('click', function(ev){
      if(!document.body.classList.contains('admin-pro-open')) return;
      if(ev.target.closest('[data-admin-menu-toggle]') || ev.target.closest('.admin-pro-sidebar')) return;
      document.body.classList.remove('admin-pro-open');
    });
    document.addEventListener('keydown', function(ev){ if(ev.key==='Escape') document.body.classList.remove('admin-pro-open'); });
    var logout=document.querySelectorAll('[data-admin-logout]');
    logout.forEach(function(node){ node.addEventListener('click', function(){
      try{ localStorage.removeItem('axonAdminSessionToken'); localStorage.removeItem('axonAdminSessionMeta'); }catch(_){}
      try{ sessionStorage.removeItem('axonAdminSessionToken'); sessionStorage.removeItem('axonAdminSessionMeta'); }catch(_){}
      try{ document.cookie='axonAdminSessionToken=; Path=/; Max-Age=-1; SameSite=Lax'; document.cookie='axonAdminSessionMeta=; Path=/; Max-Age=-1; SameSite=Lax'; }catch(_){}
      location.href='admin.html?logout=1';
    }); });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();

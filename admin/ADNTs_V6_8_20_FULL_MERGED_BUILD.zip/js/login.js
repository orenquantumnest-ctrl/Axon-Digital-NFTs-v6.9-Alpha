(function () {
  const SUPABASE_URL = window.AXON_SUPABASE_URL;
  const SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
  const AXONAuth = window.AXONAuth;

  function normalizeWallet(address) {
    return AXONAuth ? AXONAuth.normalizeWallet(address) : String(address || '').trim().toLowerCase();
  }

  function isValidBep20(address) {
    return AXONAuth ? AXONAuth.isValidWallet(address) : /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
  }

  function getSafeNextPath() {
    const params = new URLSearchParams(window.location.search);
    const raw = String(params.get('next') || '').trim();
    if (!raw) return 'dashboard.html';
    if (/^https?:\/\//i.test(raw) || raw.startsWith('//')) return 'dashboard.html';
    if (!/^[A-Za-z0-9._\-\/\?=&%#]+$/.test(raw)) return 'dashboard.html';
    return raw;
  }

  function showPageHints() {
    const params = new URLSearchParams(window.location.search);
    const msgEl = document.getElementById('loginMessage');
    if (!msgEl) return;
    if (params.get('logged_out') === '1') {
      msgEl.style.color = 'var(--txt2)';
      msgEl.textContent = 'You have been logged out successfully.';
      return;
    }
    if (params.get('next')) {
      msgEl.style.color = 'var(--txt2)';
      msgEl.textContent = 'Log in to continue to the page you were trying to open.';
    }
  }

  window.handleLogin = async function (e) {
    e.preventDefault();

    const walletInput = document.getElementById('wallet').value;
    const wallet = normalizeWallet(walletInput);
    const password = document.getElementById('password').value.trim();
    const msgEl = document.getElementById('loginMessage');
    msgEl.style.color = 'var(--txt2)';
    msgEl.textContent = '';

    if (!isValidBep20(walletInput)) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Invalid wallet address.';
      return;
    }

    if (!password) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Password required.';
      return;
    }

    if (!supabase) {
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = 'Supabase config is missing. Check js/supabase-config.js.';
      return;
    }

    try {
      const { data, error } = await supabase.rpc('axon_login_user', {
        p_wallet: wallet,
        p_password: password
      });

      if (error || !data) {
        console.error(error);
        msgEl.style.color = '#e74c3c';
        msgEl.textContent = error?.message || 'Invalid credentials.';
        return;
      }

      if (AXONAuth) {
        AXONAuth.persistUserSession(data);
      }
      const nextPath = getSafeNextPath();
      msgEl.style.color = 'var(--em)';
      msgEl.textContent = 'Login successful. Redirecting…';
      window.setTimeout(function () {
        window.location.href = nextPath || 'dashboard.html';
      }, 600);
    } catch (err) {
      console.error(err);
      msgEl.style.color = '#e74c3c';
      msgEl.textContent = err.message || 'Unable to log in.';
    }
  };

  document.addEventListener('DOMContentLoaded', showPageHints);
})();

/*
  AXON DIGITAL NFTs — Example Runtime Configuration
  Copy to js/config.js only when starting a new environment.
  Keep service-role keys and admin passwords OUT of browser files.
*/
(function configureAxonRuntimeExample(global) {
  'use strict';
  global.AXON_CONFIG = {
    appName: 'AXON DIGITAL NFTs',
    version: '6.8.7',
    buildName: 'ADMIN_WALLET_LOGIN_LIVE_DATA_LOCKED',
    buildHash: 'REPLACE_WITH_BUILD_HASH',
    productionDomains: [
      'https://axondigitalnfts.com',
      'https://axonprime-vault.netlify.app'
    ],
    supabaseUrl: 'https://YOUR_PROJECT.supabase.co',
    supabaseAnonKey: 'YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY',
    adminKeyPolicy: 'v687-wallet-password-login-no-admin-key',
    adminWalletAddress: '0x7bbc456C2C34972723cF03b9D44323d2539514dE',
    cacheVersion: '686'
  };
  global.AXON_SUPABASE_URL = global.AXON_CONFIG.supabaseUrl;
  global.AXON_SUPABASE_ANON_KEY = global.AXON_CONFIG.supabaseAnonKey;
})(window);

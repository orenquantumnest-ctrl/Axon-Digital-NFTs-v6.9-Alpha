(function () {
  const SUPABASE_URL = window.AXON_SUPABASE_URL;
  const SUPABASE_ANON_KEY = window.AXON_SUPABASE_ANON_KEY;
  const supabase = SUPABASE_URL && SUPABASE_ANON_KEY
    ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : null;

  const PLAN_META = {
    'FREE NFT': { daily: '$1.00 Daily Claim', duration: '40 Days' },
    Lite: { daily: '$0.60 Daily Claim', duration: '40 Days' },
    Starter: { daily: '$1.50 Daily Claim', duration: '40 Days' },
    Bronze: { daily: '$3.00 Daily Claim', duration: '40 Days' },
    Silver: { daily: '$6.00 Daily Claim', duration: '40 Days' },
    Gold: { daily: '$17.50 Daily Claim', duration: '40 Days' }
  };

  const PAYMENT_BUCKET = 'payment-proofs';
  const OFFICIAL_WALLET = '0x7bbc456C2C34972723cF03b9D44323d2539514dE';

  function getParams() {
    const params = new URLSearchParams(window.location.search);
    return {
      plan: params.get('plan') || 'Lite',
      price: Number(params.get('price') || 20)
    };
  }

  function normalizeWallet(address) {
    return String(address || '').trim().toLowerCase();
  }

  function isValidBep20(address) {
    return /^0x[a-fA-F0-9]{40}$/.test(String(address || '').trim());
  }

  function isValidTxHash(hash) {
    return /^0x([A-Fa-f0-9]{64})$/.test(String(hash || '').trim());
  }

  function isFreePlan(plan) {
    return String(plan || '').toLowerCase().includes('free');
  }

  function getUser() {
    return window.AXONAuth ? window.AXONAuth.getUser() : null;
  }

  function hasLiveSession(user) {
    return Boolean(user && user.wallet && user.sessionToken);
  }

  function getLoginHref() {
    const current = 'payment.html' + window.location.search;
    return window.AXONAuth ? window.AXONAuth.getLoginHref(current) : ('login.html?next=' + encodeURIComponent(current));
  }

  function isAuthError(error) {
    const message = String(error && error.message ? error.message : error || '').toLowerCase();
    return /session|log in again|invalid credentials|not authenticated|expired/.test(message);
  }

  async function validateSession(user) {
    if (!user || !user.wallet || !user.sessionToken || !supabase) return { valid: hasLiveSession(user), checked: false };
    try {
      const { data, error } = await supabase.rpc('axon_get_session_status', {
        p_wallet: user.wallet,
        p_session_token: user.sessionToken
      });
      if (error) {
        if (/does not exist/i.test(String(error.message || ''))) return { valid: true, checked: false };
        throw error;
      }
      return { valid: Boolean(data && data.valid), checked: true };
    } catch (error) {
      if (/does not exist/i.test(String(error && error.message ? error.message : ''))) return { valid: true, checked: false };
      return { valid: false, checked: true, error };
    }
  }

  function setActionLink(text, href) {
    const box = document.getElementById('paymentActionHint');
    if (!box) return;
    if (!href) {
      box.innerHTML = '';
      box.style.display = 'none';
      return;
    }
    box.style.display = 'flex';
    box.innerHTML = `<a class="btn btn-primary" href="${href}">${text}</a>`;
  }

  function setFormEnabled(enabled) {
    const form = document.getElementById('paymentForm');
    if (!form) return;
    Array.from(form.querySelectorAll('input, textarea, button[type="submit"]')).forEach(function (field) {
      if (field.id === 'planName' || field.id === 'planAmount') return;
      field.disabled = !enabled;
    });
  }

  function showMessage(text, type) {
    const box = document.getElementById('paymentMessage');
    if (!box) return;
    box.className = 'message-box show ' + (type === 'error' ? 'message-error' : 'message-success');
    box.textContent = text;
  }

  function safeFileName(name) {
    return String(name || '').replace(/[^a-zA-Z0-9._-]/g, '_');
  }

  function setFreePlanMode(plan) {
    const form = document.getElementById('paymentForm');
    const submitButton = form ? form.querySelector('button[type="submit"]') : null;
    const note = document.getElementById('freePlanNotice');
    if (note) {
      note.style.display = 'block';
      note.textContent = 'FREE NFT is unlocked from the dashboard. Claim $1 once every 24 hours for 40 days, then activate the miner after at least 1 confirmed referral.';
    }

    document.getElementById('summaryPlan').textContent = plan + ' Plan';
    document.getElementById('summaryPrice').textContent = '$40';
    document.getElementById('summaryDaily').textContent = '$1.00 Daily Claim';
    document.getElementById('summaryDuration').textContent = '40 Days';
    document.getElementById('planName').value = plan + ' Plan';
    document.getElementById('planAmount').value = '$40';
    document.getElementById('officialWallet').textContent = OFFICIAL_WALLET;

    Array.from(document.querySelectorAll('#paymentForm input, #paymentForm textarea')).forEach(function (field) {
      if (field.id !== 'planName' && field.id !== 'planAmount') {
        field.disabled = true;
      }
    });
    const checkbox = document.getElementById('confirmCheck');
    if (checkbox) checkbox.disabled = true;
    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Free Miner Uses Dashboard Claims';
    }
    setActionLink('Open Free Miner Dashboard', 'dashboard.html#freeMiner');
    showMessage('This plan is unlocked from the dashboard free miner panel and not through direct payment.', 'error');
  }

  function preloadForm() {
    const { plan, price } = getParams();
    const user = getUser();
    const meta = PLAN_META[plan] || PLAN_META.Starter;

    document.getElementById('summaryPlan').textContent = plan + ' Plan';
    document.getElementById('summaryPrice').textContent = '$' + price;
    document.getElementById('summaryDaily').textContent = meta.daily;
    document.getElementById('summaryDuration').textContent = meta.duration;
    document.getElementById('planName').value = plan + ' Plan';
    document.getElementById('planAmount').value = '$' + price;
    document.getElementById('officialWallet').textContent = OFFICIAL_WALLET;

    if (user && user.wallet) {
      document.getElementById('receivingWallet').value = user.wallet;
    }

    document.getElementById('amountSent').value = price;

    if (isFreePlan(plan)) {
      setFreePlanMode(plan);
    }
  }

  function bindCopyWallet() {
    const btn = document.getElementById('copyOfficialWalletBtn');
    if (!btn) return;
    btn.addEventListener('click', function () {
      navigator.clipboard.writeText(document.getElementById('officialWallet').textContent).then(function () {
        showMessage('Official wallet copied.', 'success');
      });
    });
  }

  function saveLocalCache(payload) {
    const transactions = JSON.parse(window.localStorage.getItem('axonTransactions') || '[]');
    transactions.unshift(payload);
    window.localStorage.setItem('axonTransactions', JSON.stringify(transactions));

    window.localStorage.setItem('axonSelectedPlan', JSON.stringify({
      name: payload.plan,
      price: payload.price,
      payoutWallet: payload.receivingWallet,
      status: 'pending',
      submittedAt: payload.createdAt,
      transactionHash: payload.transactionHash,
      amountSent: payload.amountSent,
      proofFileName: payload.proofFileName,
      proofStoragePath: payload.proofStoragePath || null
    }));
  }

  async function uploadProof(file, wallet) {
    const ext = file.name.includes('.') ? file.name.split('.').pop() : 'jpg';
    const path = `${wallet}/${Date.now()}-${safeFileName(file.name || `proof.${ext}`)}`;
    const { error } = await supabase.storage.from(PAYMENT_BUCKET).upload(path, file, {
      cacheControl: '3600',
      upsert: false
    });
    if (error) throw error;
    return path;
  }

  async function insertSupabaseRecords(payload) {
    const { error } = await supabase.rpc('axon_submit_payment', {
      p_wallet: payload.walletAddress,
      p_session_token: payload.sessionToken,
      p_plan_name: payload.plan,
      p_plan_price: payload.price,
      p_tx_hash: payload.transactionHash,
      p_proof_storage_path: payload.proofStoragePath,
      p_amount_sent: payload.amountSent,
      p_payment_notes: payload.paymentNotes
    });
    if (error) throw error;
  }

  async function applySessionGuard() {
    const user = getUser();
    const { plan } = getParams();
    if (isFreePlan(plan)) return;

    if (!user || !user.wallet) {
      setFormEnabled(false);
      setActionLink('Log in to continue', getLoginHref());
      showMessage('Log in first, then return to this page to submit your payment proof.', 'error');
      return;
    }

    if (!user.sessionToken) {
      setFormEnabled(false);
      setActionLink('Refresh login session', getLoginHref());
      showMessage('Your login session needs to be refreshed before this payment proof can be submitted. Log in again, then return here automatically.', 'error');
      return;
    }

    const sessionState = await validateSession(user);
    if (!sessionState.valid) {
      if (window.AXONAuth) window.AXONAuth.clearUser();
      setFormEnabled(false);
      setActionLink('Log in again', getLoginHref());
      showMessage('Your session expired on this browser. Log in again and return to this page automatically.', 'error');
      return;
    }

    setFormEnabled(true);
    setActionLink('', '');
  }

  async function handleSubmit(event) {
    event.preventDefault();

    const { plan, price } = getParams();
    if (isFreePlan(plan)) {
      showMessage('FREE NFT does not use the payment form. Return to the dashboard and use the daily claim button instead.', 'error');
      return;
    }

    const currentUser = getUser();
    const receivingWalletInput = document.getElementById('receivingWallet').value.trim();
    const receivingWallet = normalizeWallet(receivingWalletInput);
    const transactionHash = document.getElementById('transactionHash').value.trim();
    const amountSent = Number(document.getElementById('amountSent').value || 0);
    const proofInput = document.getElementById('proofFile');
    const paymentNotes = document.getElementById('paymentNotes').value.trim();
    const proofFile = proofInput.files && proofInput.files[0] ? proofInput.files[0] : null;
    const submitBtn = event.submitter || document.querySelector('#paymentForm button[type="submit"]');

    if (!hasLiveSession(currentUser)) {
      setFormEnabled(false);
      setActionLink('Log in to continue', getLoginHref());
      showMessage('A current login session is required before payment proof can be submitted. Log in again and return to this page automatically.', 'error');
      return;
    }

    if (!isValidBep20(receivingWalletInput)) {
      showMessage('Enter a valid BEP20 receiving wallet address.', 'error');
      return;
    }

    if (!isValidTxHash(transactionHash)) {
      showMessage('Enter a valid BNB transaction hash.', 'error');
      return;
    }

    if (!amountSent || amountSent <= 0) {
      showMessage('Enter the exact amount that was sent.', 'error');
      return;
    }

    if (!proofFile) {
      showMessage('Upload your proof of payment screenshot.', 'error');
      return;
    }

    const payload = {
      id: 'txn_' + Date.now(),
      type: 'Plan Activation',
      plan,
      price,
      amountSent,
      receivingWallet,
      walletAddress: normalizeWallet(currentUser.wallet),
      sessionToken: currentUser.sessionToken,
      transactionHash,
      proofFileName: proofFile.name,
      paymentNotes,
      status: 'pending',
      createdAt: new Date().toISOString(),
      proofStoragePath: null
    };

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.style.opacity = '0.7';
    }

    try {
      if (!supabase) {
        throw new Error('Supabase config is missing. Check js/supabase-config.js.');
      }

      payload.proofStoragePath = await uploadProof(proofFile, payload.walletAddress);
      await insertSupabaseRecords(payload);

      saveLocalCache(payload);
      setActionLink('', '');
      showMessage('Payment proof submitted successfully. Your dashboard will now show this plan as pending activation.', 'success');

      setTimeout(function () {
        window.location.href = 'dashboard.html';
      }, 1500);
    } catch (error) {
      console.error(error);
      const message = String(error && error.message ? error.message : '');
      if (isAuthError(message)) {
        if (window.AXONAuth) window.AXONAuth.clearUser();
        setFormEnabled(false);
        setActionLink('Log in again', getLoginHref());
      }
      showMessage(error.message || 'Payment proof could not be submitted right now. Confirm the wallet address, transaction hash, screenshot, and login session, then try again.', 'error');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.opacity = '1';
      }
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    preloadForm();
    bindCopyWallet();
    applySessionGuard().catch(function (error) { console.error(error); showMessage('We could not verify your login session on this page. Please log in again.', 'error'); setFormEnabled(false); setActionLink('Log in again', getLoginHref()); });
    document.getElementById('paymentForm').addEventListener('submit', handleSubmit);
  });
})();

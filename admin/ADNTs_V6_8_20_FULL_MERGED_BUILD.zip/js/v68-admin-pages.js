(function () {
  'use strict';

  var TOKEN_KEY = 'axonAdminSessionToken';
  var META_KEY = 'axonAdminSessionMeta';
  var RPC_TIMEOUT_MS = 25000;
  var ADMIN_WALLET = (window.AXON_CONFIG && window.AXON_CONFIG.adminWalletAddress) || '0x7bbc456C2C34972723cF03b9D44323d2539514dE';
  var page = (document.body && document.body.dataset && document.body.dataset.adminPage) || 'overview';
  var lastConsolePayload = null;
  var searchState = {};
  var modalState = { kind: '', id: '', currentStatus: '', nextStatus: '', note: '' };

  function $(id) { return document.getElementById(id); }
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]; }); }
  function usd(v) { return '$' + Number(v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function dt(v) { if (!v) return '—'; var d = new Date(v); return isNaN(d.getTime()) ? '—' : d.toLocaleString(); }
  function short(v) { var s = String(v || ''); return s.length > 18 ? s.slice(0, 8) + '…' + s.slice(-6) : (s || '—'); }
  function lower(v) { return String(v || '').toLowerCase(); }

  function setCookie(name, value, maxAgeSeconds) {
    try {
      var secure = location.protocol === 'https:' ? '; Secure' : '';
      document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value || '') + '; Path=/; SameSite=Lax' + secure + (maxAgeSeconds ? '; Max-Age=' + String(maxAgeSeconds) : '');
    } catch (_) {}
  }

  function getCookie(name) {
    try {
      var key = encodeURIComponent(name) + '=';
      var parts = (document.cookie || '').split(';');
      for (var i = 0; i < parts.length; i += 1) {
        var p = parts[i].trim();
        if (p.indexOf(key) === 0) return decodeURIComponent(p.slice(key.length));
      }
    } catch (_) {}
    return '';
  }

  function token() {
    try { var v = localStorage.getItem(TOKEN_KEY); if (v) return v; } catch (_) {}
    try { var s = sessionStorage.getItem(TOKEN_KEY); if (s) return s; } catch (_) {}
    return getCookie(TOKEN_KEY) || '';
  }

  function storeToken(sessionToken, expiresAt, walletAddress) {
    var meta = JSON.stringify({ expiresAt: expiresAt || null, createdAt: new Date().toISOString(), walletAddress: walletAddress || '', bridge: 'v6.8.18-referral-restoration' });
    var maxAge = expiresAt ? Math.max(300, Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000)) : 86400;
    try { localStorage.setItem(TOKEN_KEY, sessionToken); localStorage.setItem(META_KEY, meta); } catch (_) {}
    try { sessionStorage.setItem(TOKEN_KEY, sessionToken); sessionStorage.setItem(META_KEY, meta); } catch (_) {}
    setCookie(TOKEN_KEY, sessionToken, maxAge);
    setCookie(META_KEY, meta, maxAge);
  }

  function clearToken() {
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(META_KEY); } catch (_) {}
    try { sessionStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(META_KEY); } catch (_) {}
    setCookie(TOKEN_KEY, '', -1);
    setCookie(META_KEY, '', -1);
  }

  function supabaseUrl() { return String(window.AXON_SUPABASE_URL || window.SUPABASE_URL || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseUrl) || '').replace(/\/+$/, ''); }
  function supabaseAnonKey() { return String(window.AXON_SUPABASE_ANON_KEY || window.SUPABASE_ANON_KEY || (window.AXON_CONFIG && window.AXON_CONFIG.supabaseAnonKey) || ''); }

  function getClient() {
    if (window.axonSupabase) return window.axonSupabase;
    if (window.supabase && typeof window.supabase.createClient === 'function' && supabaseUrl() && supabaseAnonKey()) {
      window.axonSupabase = window.supabase.createClient(supabaseUrl(), supabaseAnonKey(), {
        auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
        global: { headers: { 'X-Client-Info': 'axon-admin-pages-v6818' } }
      });
      return window.axonSupabase;
    }
    return null;
  }

  function withTimeout(promise, ms, label) {
    var timer;
    var timeout = new Promise(function (_, reject) {
      timer = setTimeout(function () { reject(new Error(label || 'Supabase request timed out.')); }, ms || RPC_TIMEOUT_MS);
    });
    return Promise.race([promise, timeout]).finally(function () { clearTimeout(timer); });
  }

  function restRpc(name, args) {
    var url = supabaseUrl();
    var key = supabaseAnonKey();
    if (!url || !key) return Promise.reject(new Error('Supabase URL/key missing. Check js/config.js.'));
    var endpoint = url + '/rest/v1/rpc/' + encodeURIComponent(name);
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, RPC_TIMEOUT_MS) : null;
    var body = JSON.stringify(args || {});
    try { console.info('[AXON_ADMIN_REST_RPC_REQUEST]', name, endpoint, args || {}); } catch (_) {}
    return fetch(endpoint, {
      method: 'POST',
      headers: {
        apikey: key,
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Client-Info': 'axon-admin-rest-v6818'
      },
      body: body,
      signal: controller ? controller.signal : undefined,
      credentials: 'omit',
      cache: 'no-store',
      mode: 'cors'
    }).then(function (response) {
      if (timer) clearTimeout(timer);
      return response.text().then(function (text) {
        var parsed = null;
        if (text) {
          try { parsed = JSON.parse(text); } catch (_) { parsed = text; }
        }
        if (!response.ok) {
          var msg = parsed && parsed.message ? parsed.message : (typeof parsed === 'string' ? parsed : text);
          throw new Error('REST RPC ' + name + ' failed with HTTP ' + response.status + (msg ? ': ' + msg : ''));
        }
        return parsed;
      });
    }).catch(function (error) {
      if (timer) clearTimeout(timer);
      throw error;
    });
  }

  async function rpc(name, args) {
    var client = getClient();
    if (client) {
      try {
        var result = await withTimeout(client.rpc(name, args || {}), RPC_TIMEOUT_MS, 'Supabase JS RPC ' + name + ' timed out.');
        if (result && result.error) throw result.error;
        try { console.info('[AXON_ADMIN_SUPABASE_RPC_RESULT]', name, result && result.status, result && result.data); } catch (_) {}
        return result ? result.data : null;
      } catch (sdkError) {
        console.warn('[AXON_ADMIN_SUPABASE_RPC_FALLBACK]', name, sdkError);
        return restRpc(name, args || {});
      }
    }
    return restRpc(name, args || {});
  }

  function setText(id, v) { var e = $(id); if (e) e.textContent = v; }
  function setHtml(id, v) { var e = $(id); if (e) e.innerHTML = v; }
  function empty(text) { return '<div class="admin-empty">' + esc(text) + '</div>'; }


  function recordSearchBlob(item, kind) {
    item = item || {};
    var fields = [kind];
    Object.keys(item).forEach(function (key) {
      var value = item[key];
      if (value === null || value === undefined) return;
      if (typeof value === 'object') {
        try { fields.push(JSON.stringify(value)); } catch (_) {}
      } else {
        fields.push(String(value));
      }
    });
    return fields.join(' ').replace(/\s+/g, ' ').trim();
  }

  function searchNeedle(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9.]+/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function rowTitle(item, kind) {
    item = item || {};
    if (kind === 'user') return short(item.wallet_address || item.username || item.id);
    if (kind === 'payment') return (item.plan_name || 'Deposit') + ' · ' + usd(item.amount_sent || item.plan_price || item.amount || 0);
    if (kind === 'withdraw') return 'Withdrawal · ' + usd(item.requested_amount || item.amount || 0);
    if (kind === 'transaction') return (item.type || item.source || 'Transaction') + ' · ' + moneyFields(item);
    if (kind === 'plan') return (item.plan_name || item.name || 'Plan') + ' · ' + usd(item.plan_price || item.plan_price_usd || 0);
    if (kind === 'catalog') return (item.plan_name || item.plan_code || 'Catalog item') + ' · ' + usd(item.plan_price || 0);
    if (kind === 'log') return item.action || item.action_name || 'Audit event';
    return item.title || item.event_type || item.action || 'System record';
  }

  function rowSub(item, kind) {
    item = item || {};
    var parts = [];
    if (item.wallet_address) parts.push('Wallet ' + short(item.wallet_address));
    if (item.payout_wallet) parts.push('Payout ' + short(item.payout_wallet));
    if (item.tx_hash) parts.push('TX ' + short(item.tx_hash));
    if (item.status) parts.push('Status ' + item.status);
    if (item.created_at) parts.push(dt(item.created_at));
    if (item.plan_name) parts.push('Plan ' + item.plan_name);
    if (item.amount_sent != null) parts.push('Sent ' + usd(item.amount_sent));
    if (item.requested_amount != null) parts.push('Requested ' + usd(item.requested_amount));
    return parts.filter(Boolean).join(' · ') || 'AXON record';
  }

  function matchesQuery(item, kind, query) {
    var q = searchNeedle(query);
    if (!q) return true;
    var blob = searchNeedle(recordSearchBlob(item, kind));
    return q.split(' ').every(function (part) { return !part || blob.indexOf(part) !== -1; });
  }

  function statusOptions(kind) {
    if (kind === 'payment') return ['pending', 'approved', 'completed', 'rejected'];
    if (kind === 'withdraw') return ['pending', 'processing', 'completed', 'rejected'];
    return ['pending', 'active', 'approved', 'completed', 'suspended', 'rejected'];
  }

  function statusTone(status) {
    var s = lower(status || 'pending');
    if (/approved|active|completed|paid|success/.test(s)) return 'success';
    if (/reject|failed|cancel|deleted/.test(s)) return 'danger';
    if (/process|review/.test(s)) return 'info';
    return 'warn';
  }

  function pill(status) {
    var s = lower(status || 'pending').replace(/[^a-z0-9_-]+/g, '-');
    var tone = statusTone(s);
    return '<span class="admin-pill admin-status-pill ' + esc(s) + ' ' + tone + '">' + esc(status || 'pending') + '</span>';
  }

  function changeButton(kind, status) {
    if (kind !== 'payment' && kind !== 'withdraw') return '';
    var tone = statusTone(status);
    return '<button class="admin-btn admin-change-btn ' + esc(tone) + '" type="button" data-status-change="1" data-kind="' + esc(kind) + '" data-current-status="' + esc(status || 'pending') + '">Change</button>';
  }

  function searchShell(id, title, placeholder) {
    return '' +
      '<section class="admin-live-search" data-search-shell="' + esc(id) + '">' +
        '<div class="admin-search-head"><div><span>Live filter</span><strong>' + esc(title) + '</strong></div><button class="admin-search-clear" type="button" data-search-clear="' + esc(id) + '">Clear</button></div>' +
        '<div class="admin-search-box"><input type="search" autocomplete="off" spellcheck="false" data-admin-search-input="' + esc(id) + '" placeholder="' + esc(placeholder || 'Search wallet, hash, amount, status, plan, date…') + '"/><button type="button" class="admin-btn ghost" data-search-submit="' + esc(id) + '">Search</button></div>' +
        '<div class="admin-search-suggestions" id="' + esc(id) + '__suggestions" aria-live="polite"></div>' +
      '</section>' +
      '<div id="' + esc(id) + '__records"></div>';
  }

  function renderListRecords(id, items, kind, emptyText, query) {
    var target = $(id + '__records') || $(id);
    if (!target) return;
    var filtered = (items || []).filter(function (item) { return matchesQuery(item, kind, query); });
    if (!filtered.length) {
      target.innerHTML = empty(query ? 'No exact or similar records matched “' + query + '”.' : (emptyText || 'No records found.'));
      return;
    }
    target.innerHTML = '<div class="admin-pro-table admin-filtered-table" data-filtered-count="' + esc(filtered.length) + '">' + filtered.map(function (x) { return record(x, kind); }).join('') + '</div>';
  }

  function renderSuggestions(id, items, kind, query) {
    var box = $(id + '__suggestions');
    if (!box) return;
    var q = String(query || '').trim();
    if (!q) { box.innerHTML = ''; return; }
    var found = (items || []).filter(function (item) { return matchesQuery(item, kind, q); }).slice(0, 8);
    if (!found.length) { box.innerHTML = '<div class="admin-suggestion-empty">No live suggestions yet.</div>'; return; }
    box.innerHTML = found.map(function (item, index) {
      var label = rowTitle(item, kind);
      var sub = rowSub(item, kind);
      var pick = item.tx_hash || item.wallet_address || item.payout_wallet || item.plan_name || label;
      return '<button type="button" class="admin-suggestion" data-search-pick="' + esc(id) + '" data-search-query="' + esc(pick) + '"><strong>' + esc(label) + '</strong><span>' + esc(sub) + '</span></button>';
    }).join('');
  }

  function renderSearchPage(id, items, kind, emptyText, title, placeholder) {
    items = Array.isArray(items) ? items.slice() : [];
    searchState[id] = { items: items, kind: kind, emptyText: emptyText || 'No records found.', title: title || 'Records', query: '' };
    setHtml(id, searchShell(id, title || 'Records', placeholder));
    renderListRecords(id, items, kind, emptyText, '');
  }

  function applySearch(id, query) {
    var state = searchState[id];
    if (!state) return;
    state.query = query || '';
    renderSuggestions(id, state.items, state.kind, state.query);
    renderListRecords(id, state.items, state.kind, state.emptyText, state.query);
  }

  function ensureModalRoot() {
    var root = $('axonAdminModalRoot');
    if (root) return root;
    root = document.createElement('div');
    root.id = 'axonAdminModalRoot';
    root.className = 'axon-admin-modal-root';
    root.innerHTML = '';
    document.body.appendChild(root);
    return root;
  }

  function closeModal() {
    var root = $('axonAdminModalRoot');
    if (root) root.innerHTML = '';
    modalState = { kind: '', id: '', currentStatus: '', nextStatus: '', note: '' };
  }

  function showNotice(title, message, tone, okHandler) {
    var root = ensureModalRoot();
    root.innerHTML = '<div class="axon-admin-modal-backdrop" role="presentation"></div><section class="axon-admin-modal ' + esc(tone || 'success') + '" role="dialog" aria-modal="true" aria-label="' + esc(title || 'Status notice') + '"><div class="axon-modal-orb"></div><h2>' + esc(title || 'Done') + '</h2><p>' + esc(message || '') + '</p><div class="axon-modal-actions"><button class="admin-btn gold" type="button" data-modal-ok="1">OK</button></div></section>';
    var ok = root.querySelector('[data-modal-ok]');
    if (ok) ok.addEventListener('click', function () { closeModal(); if (typeof okHandler === 'function') okHandler(); });
  }

  function openStatusModal(kind, id, currentStatus, note) {
    if (!kind || !id) return;
    var options = statusOptions(kind);
    modalState = { kind: kind, id: id, currentStatus: currentStatus || 'pending', nextStatus: currentStatus || options[0], note: note || '' };
    var root = ensureModalRoot();
    root.innerHTML = '' +
      '<div class="axon-admin-modal-backdrop" role="presentation" data-modal-close="1"></div>' +
      '<section class="axon-admin-modal" role="dialog" aria-modal="true" aria-label="Change record status">' +
        '<div class="axon-modal-orb"></div>' +
        '<button class="axon-modal-x" type="button" data-modal-close="1" aria-label="Close">×</button>' +
        '<span class="axon-modal-kicker">Status control</span>' +
        '<h2>Change ' + esc(kind === 'payment' ? 'deposit' : 'withdrawal') + ' status</h2>' +
        '<p>Select one new status. The backend RPC will update the record, sync ledger tables, and then reload this page after confirmation.</p>' +
        '<div class="axon-status-options">' + options.map(function (s) {
          var checked = lower(s) === lower(currentStatus || '') ? ' checked' : '';
          return '<label class="axon-status-option ' + esc(statusTone(s)) + '"><input type="radio" name="axonNextStatus" value="' + esc(s) + '"' + checked + '/><span>' + esc(s) + '</span></label>';
        }).join('') + '</div>' +
        '<label class="axon-modal-note"><span>Admin note</span><textarea id="axonModalAdminNote" placeholder="Optional admin note">' + esc(note || '') + '</textarea></label>' +
        '<div class="axon-modal-actions"><button class="admin-btn ghost" type="button" data-modal-close="1">Cancel</button><button class="admin-btn gold" type="button" data-modal-continue="1">Continue</button></div>' +
      '</section>';
  }

  function numberFrom() {
    for (var i = 0; i < arguments.length; i += 1) {
      var value = arguments[i];
      if (value === null || value === undefined || value === '') continue;
      var n = Number(value);
      if (Number.isFinite(n)) return n;
    }
    return 0;
  }

  function normalizeConsole(raw) {
    var root = Array.isArray(raw) ? (raw[0] || {}) : (raw || {});
    var stats = root.stats || root.metrics || root.counts || root.summary || root || {};
    var probe = root.data_probe || root.probe || root || {};
    function pick() {
      for (var i = 0; i < arguments.length; i += 1) {
        var v = arguments[i];
        if (v === null || v === undefined || v === '') continue;
        var n = Number(v);
        if (Number.isFinite(n)) return n;
      }
      return 0;
    }
    var normalizedStats = {
      users_count: pick(stats.users_count, stats.total_users, root.public_users, probe.public_users, root.users_count, probe.users_count, probe.derived_live_wallets),
      active_plans_count: pick(stats.active_plans_count, stats.active_plans, root.user_plans_active, probe.user_plans_active, root.plan_claim_accounts_active, probe.plan_claim_accounts_active),
      pending_payments_count: pick(stats.pending_payments_count, stats.pending_deposits, root.payment_pending, probe.payment_pending),
      pending_withdrawals_count: pick(stats.pending_withdrawals_count, stats.pending_withdrawal, root.withdrawal_pending, probe.withdrawal_pending),
      transactions_count: pick(stats.transactions_count, stats.transactions, root.transactions, probe.transactions),
      catalog_count: pick(stats.catalog_count, stats.catalog_plans, root.axon_plan_catalog, probe.axon_plan_catalog, root.legacy_plan_catalog, probe.legacy_plan_catalog),
      claim_accounts_count: pick(stats.claim_accounts_count, probe.plan_claim_accounts_active, root.plan_claim_accounts_active, root.plan_claim_accounts, probe.plan_claim_accounts),
      free_miner_count: pick(stats.free_miner_count, probe.free_miner_accounts, root.free_miner_accounts, root.free_miner_claims, probe.free_miner_claims),
      total_claim_earnings: pick(stats.total_claim_earnings, root.total_claim_earnings, probe.total_claim_earnings),
      reserved_withdrawals: pick(stats.reserved_withdrawals, root.reserved_withdrawals, probe.reserved_withdrawals),
      referrals_count: pick(stats.referrals_count, stats.referrals, root.referrals_count, root.referrals, probe.referrals),
      referral_visits_count: pick(stats.referral_visits_count, root.referral_visits_count, root.referral_visits, probe.referral_visits),
      referral_earnings_total: pick(stats.referral_earnings_total, root.referral_earnings_total, probe.referral_earnings_total)
    };
    return {
      raw: root,
      stats: normalizedStats,
      payments: root.payments || root.deposits || root.payment_submissions || root.pending_payments || [],
      withdrawals: root.withdrawals || root.withdrawal_requests || root.withdrawal_pending_list || [],
      users: root.users || root.recent_users || [],
      transactions: root.transactions || root.transactions_list || root.recent_transactions || [],
      plan_accounts: root.plan_accounts || root.active_plans || root.user_plans || [],
      free_miner_accounts: root.free_miner_accounts || [],
      audit_logs: root.audit_logs || root.logs || [],
      system_events: root.system_events || root.events || [],
      plan_catalog: root.plan_catalog || root.catalog || [],
      referrals: root.referrals || root.referral_edges || root.admin_referrals || [],
      referral_leaders: root.referral_leaders || root.top_referrers || [],
      session_expires_at: root.session_expires_at || root.expires_at || null,
      data_probe: probe
    };
  }

  function statsTotal(d) {
    var s = (d && d.stats) || {};
    return Number(s.users_count || 0) + Number(s.active_plans_count || 0) + Number(s.pending_payments_count || 0) + Number(s.pending_withdrawals_count || 0) + Number(s.transactions_count || 0) + Number(s.catalog_count || 0) + Number(s.claim_accounts_count || 0) + Number(s.free_miner_count || 0) + Number(s.referrals_count || 0) + Number(s.referral_visits_count || 0);
  }

  async function tryProbeFallback(baseRaw) {
    var root = Array.isArray(baseRaw) ? (baseRaw[0] || {}) : (baseRaw || {});
    var probe = null;
    try { probe = await rpc('axon_admin_live_data_probe_v6811', {}); }
    catch (_) {
      try { probe = await rpc('axon_admin_live_data_probe', {}); }
      catch (error) { try { console.warn('[AXON_ADMIN_PROBE_FALLBACK_FAILED]', error); } catch (_) {} }
    }
    if (!probe) return normalizeConsole(baseRaw);
    var probeRoot = Array.isArray(probe) ? (probe[0] || {}) : (probe || {});
    return normalizeConsole(Object.assign({}, root, { data_probe: probeRoot, probe: probeRoot }));
  }

  function summarizeStats(d) {
    var s = (d && d.stats) || {};
    setText('adminUsers', s.users_count || 0);
    setText('adminPlans', s.active_plans_count || 0);
    setText('adminPayments', s.pending_payments_count || 0);
    setText('adminWithdrawals', s.pending_withdrawals_count || 0);
    setText('adminEarnings', usd(s.total_claim_earnings || 0));
    setText('adminReserved', usd(s.reserved_withdrawals || 0));
    setText('adminTransactions', s.transactions_count || 0);
    setText('adminCatalog', s.catalog_count || 0);
    setText('adminClaims', s.claim_accounts_count || 0);
    setText('adminFreeMiner', s.free_miner_count || 0);
    setText('adminReferrals', s.referrals_count || 0);
    setText('adminReferralVisits', s.referral_visits_count || 0);
    setText('adminReferralEarnings', usd(s.referral_earnings_total || 0));
  }

  function setStatsPending(label) {
    ['adminUsers','adminPlans','adminPayments','adminWithdrawals','adminTransactions','adminCatalog','adminClaims','adminFreeMiner','adminReferrals','adminReferralVisits','adminReferralEarnings'].forEach(function (id) { setText(id, label || '—'); });
    setText('adminEarnings', label || '—');
    setText('adminReserved', label || '—');
  }

  function moneyFields(item) {
    var fields = ['amount', 'plan_price', 'amount_sent', 'requested_amount', 'daily_claim_amount', 'total_claimed', 'claimed_amount'];
    for (var i = 0; i < fields.length; i += 1) if (item && item[fields[i]] != null) return usd(item[fields[i]]);
    return '';
  }

  function actionButtons(kind, status) {
    return changeButton(kind, status || 'pending');
  }

  function record(item, kind) {
    item = item || {};
    var title = 'Admin record';
    var meta = [];
    var purpose = '';
    var actions = '';
    if (kind === 'user') {
      title = short(item.wallet_address);
      purpose = 'Registered user identity and wallet activity summary.';
      meta = [item.referral_code ? 'Code ' + item.referral_code : null, item.referred_by ? 'Referred by ' + short(item.referred_by) : null, 'Joined ' + dt(item.created_at), item.active_plans_count != null ? 'Active plans ' + item.active_plans_count : null, item.available_balance != null ? 'Balance ' + usd(item.available_balance) : null].filter(Boolean);
    } else if (kind === 'payment') {
      title = (item.plan_name || 'Deposit') + ' · ' + usd(item.amount_sent || item.plan_price || 0);
      purpose = 'Deposit proof order. Change status to approve, complete, or reject this payment submission.';
      meta = [short(item.wallet_address), 'TX ' + (item.tx_hash || '—'), dt(item.created_at), item.payment_notes || null].filter(Boolean);
      actions = actionButtons('payment', item.status || 'pending');
    } else if (kind === 'withdraw') {
      title = 'Withdrawal · ' + usd(item.requested_amount || 0);
      purpose = 'Payout order. Move request through pending, processing, completed, or rejected states.';
      meta = ['Owner ' + short(item.wallet_address), 'Payout ' + short(item.payout_wallet), dt(item.created_at), item.user_note || null].filter(Boolean);
      actions = actionButtons('withdraw', item.status || 'pending');
    } else if (kind === 'transaction') {
      title = (item.type || 'Transaction') + ' · ' + moneyFields(item);
      purpose = 'Ledger entry used for account history and reconciliation.';
      meta = [short(item.wallet_address), item.plan_name || null, item.source || null, item.status ? 'Status ' + item.status : null, dt(item.created_at), item.notes || null].filter(Boolean);
    } else if (kind === 'plan') {
      title = (item.plan_name || item.name || 'Plan') + ' · ' + usd(item.plan_price || item.plan_price_usd || 0);
      purpose = 'Active user plan or claim account used for daily claim cycles.';
      meta = [short(item.wallet_address), item.status || null, 'Claims ' + (item.claims_completed || 0) + '/' + (item.max_claims || 40), item.next_claim_at ? 'Next ' + dt(item.next_claim_at) : null, dt(item.created_at)].filter(Boolean);
    } else if (kind === 'catalog') {
      title = (item.plan_name || 'Catalog plan') + ' · ' + usd(item.plan_price || 0);
      purpose = 'Plan catalog item controlling what users can subscribe to.';
      meta = [item.plan_code, item.category, item.is_visible ? 'Visible' : 'Hidden', item.is_featured ? 'Featured' : 'Standard', item.status, 'Daily ' + usd(item.daily_claim_amount || 0)].filter(Boolean);
    } else if (kind === 'referral') {
      title = 'Referral · ' + short(item.referrer_wallet) + ' → ' + short(item.referred_wallet);
      purpose = 'Referral relationship, earnings projection, approved deposits, and account-growth tracking.';
      meta = ['Referrer ' + short(item.referrer_wallet), 'Referred ' + short(item.referred_wallet), item.level ? 'Level ' + item.level : 'Level 1', item.approved_deposit_total != null ? 'Approved deposits ' + usd(item.approved_deposit_total) : null, item.referral_earnings != null ? 'Earnings ' + usd(item.referral_earnings) : null, dt(item.created_at)].filter(Boolean);
    } else if (kind === 'log') {
      title = item.action || item.action_name || 'Audit event';
      purpose = 'Administrative audit trail for governance and accountability.';
      meta = [item.target_table || item.entity_type || null, item.status || null, item.note || null, dt(item.created_at)].filter(Boolean);
    } else {
      title = item.title || item.event_type || item.action || 'System record';
      purpose = 'System event, signal, or notification record.';
      meta = [item.status || item.severity || null, item.note || item.message || null, dt(item.created_at)].filter(Boolean);
    }
    var statusHtml = item.status ? pill(item.status) : '';
    var search = recordSearchBlob(item, kind);
    return '<article class="admin-record axon-status-record ' + esc(statusTone(item.status || 'pending')) + '" ' + (item.id ? 'data-id="' + esc(item.id) + '"' : '') + ' data-record-kind="' + esc(kind) + '" data-record-search="' + esc(search) + '"><div class="admin-record-copy"><div class="admin-record-title">' + esc(title) + '</div><div class="admin-record-purpose">' + esc(purpose) + '</div><div class="admin-record-meta">' + esc(meta.join(' · ') || 'AXON record') + '</div>' + ((kind === 'payment' || kind === 'withdraw') ? '<textarea class="admin-note" placeholder="Admin note"></textarea>' : '') + '</div><div class="admin-record-actions">' + statusHtml + actions + '</div></article>';
  }

  function table(items, kind, emptyText) {
    if (!items || !items.length) return empty(emptyText || 'No records found.');
    return '<div class="admin-pro-table">' + items.map(function (x) { return record(x, kind); }).join('') + '</div>';
  }

  function renderOverview(d) {
    setHtml('adminOverviewPayments', table((d.payments || []).slice(0, 5), 'payment', 'No recent payment submissions.'));
    setHtml('adminOverviewWithdrawals', table((d.withdrawals || []).slice(0, 5), 'withdraw', 'No recent withdrawal requests.'));
    setHtml('adminOverviewUsers', table((d.users || []).slice(0, 6), 'user', 'No users found yet.'));
    setHtml('adminOverviewPlans', table((d.plan_accounts || []).slice(0, 5), 'plan', 'No active plan claim accounts found.'));
    var cat = d.plan_catalog || [];
    var visible = cat.filter(function (p) { return p.is_visible !== false; }).length;
    var active = cat.filter(function (p) { return lower(p.status) === 'active'; }).length;
    setHtml('adminPlanCatalogSummary', '<div class="v684-catalog-stats"><div><span>Total Catalog</span><strong>' + esc(cat.length) + '</strong></div><div><span>Visible</span><strong>' + esc(visible) + '</strong></div><div><span>Active</span><strong>' + esc(active) + '</strong></div><div><span>Mode</span><strong>V6.8.18</strong></div></div><div class="admin-pro-actions"><a class="admin-btn gold" href="admin-plans.html?fresh=6818">Manage Plans</a><a class="admin-btn ghost" href="plans.html">User Plans</a></div>');
  }

  function renderDiagnostics(d) {
    var probe = d.data_probe || {};
    var keys = Object.keys(probe);
    if (!keys.length) return '';
    return '<details class="admin-diagnostics" open><summary>Live data probe</summary><pre>' + esc(JSON.stringify(probe, null, 2)) + '</pre></details>';
  }

  function renderPage(d) {
    summarizeStats(d);
    var map = {
      overview: function () { renderOverview(d); },
      users: function () { renderSearchPage('adminUsersList', d.users || [], 'user', 'No users found in the connected Supabase project.', 'Users', 'Search wallet, referral code, referrer, balance, join date…'); },
      payments: function () { renderSearchPage('adminPaymentsList', d.payments || [], 'payment', 'No payment submissions found.', 'Deposits / payment submissions', 'Search transaction hash, wallet address, amount, plan, status, date…'); },
      withdrawals: function () { renderSearchPage('adminWithdrawalsList', d.withdrawals || [], 'withdraw', 'No withdrawal requests found.', 'Withdrawal requests', 'Search wallet, payout wallet, amount, status, note, date…'); },
      plans: function () { renderSearchPage('adminPlansList', d.plan_accounts || [], 'plan', 'No active user plan accounts found yet. Plan catalog controls are above.', 'Active user plans', 'Search wallet, plan name, price, claim status, next claim date…'); },
      transactions: function () { renderSearchPage('adminTransactionsList', d.transactions || [], 'transaction', 'No transactions found.', 'Transactions', 'Search wallet, amount, plan, source, status, notes, reference…'); },
      notifications: function () { renderSearchPage('adminNotificationsList', d.system_events || [], 'event', 'No system notifications/events found.', 'Signals / system events', 'Search event type, wallet, severity, message, date…'); },
      referrals: function () { renderSearchPage('adminReferralsList', d.referrals || [], 'referral', 'No referral relationships found yet.', 'Referral network', 'Search referrer wallet, referred wallet, earnings, deposit amount, level, date…'); },
      logs: function () { renderSearchPage('adminLogsList', d.audit_logs || [], 'log', 'No audit logs found yet.', 'Audit logs', 'Search action, target table, status, admin, date…'); },
      roles: function () { setHtml('adminRolesList', '<div class="admin-empty">Master admin access now uses the official deposit wallet plus the V6.8.18 admin password. Keep passwords out of frontend files.</div>' + renderDiagnostics(d)); },
      settings: function () { setHtml('adminSettingsList', '<div class="admin-empty">Security settings are Supabase-side. Rotate the admin wallet password with <code>select public.axon_admin_set_wallet_account(\'WALLET\', \'NEW_PASSWORD\', \'Owner\');</code>.</div>' + renderDiagnostics(d)); }
    };
    (map[page] || map.overview)();
    setText('adminSessionMeta', d.session_expires_at ? 'Session expires ' + dt(d.session_expires_at) : 'Admin session active');
  }

  function inlineLoginCard(reason) {
    return '<article class="admin-pro-card admin-span-12 admin-runtime-message warn">' +
      '<div class="admin-pro-section-head"><div><h2>Admin wallet login required</h2><p>' + esc(reason || 'Login with the official deposit wallet and admin password to load live Supabase records on this page.') + '</p></div></div>' +
      '<form id="inlineAdminLoginForm" class="admin-pro-field" autocomplete="off">' +
      '<label for="inlineAdminWallet">Admin Wallet</label><input id="inlineAdminWallet" type="text" value="' + esc(ADMIN_WALLET) + '" required />' +
      '<label for="inlineAdminPassword">Admin Password</label><input id="inlineAdminPassword" type="password" autocomplete="current-password" placeholder="Enter admin password" required />' +
      '<div class="admin-pro-actions"><button id="inlineAdminLoginBtn" class="admin-btn gold" type="submit">Login & Load Records</button><a class="admin-btn ghost" href="admin.html?fresh=6818">Open Full Login</a></div>' +
      '</form></article>';
  }

  async function loginInline(ev) {
    if (ev && ev.preventDefault) ev.preventDefault();
    var wallet = String(($('inlineAdminWallet') || {}).value || ADMIN_WALLET).trim();
    var password = String(($('inlineAdminPassword') || {}).value || '');
    var btn = $('inlineAdminLoginBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }
    try {
      var data = await rpc('axon_admin_wallet_login', { p_wallet_address: wallet, p_password: password });
      if (!data || !data.admin_session_token) throw new Error('No admin session token returned. Run the V6.8.18 Supabase payment approval patch.');
      storeToken(data.admin_session_token, data.expires_at || null, wallet);
      await load();
    } catch (error) {
      var main = $('adminMain');
      if (main) main.innerHTML = inlineLoginCard((error && error.message) || 'Admin wallet login failed.');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = 'Login & Load Records'; }
    }
  }

  function statusCard(text, tone) {
    var box = $('adminRuntimeStatus');
    if (!box) {
      var main = $('adminMain');
      if (main && !main.querySelector('#adminRuntimeStatus')) {
        var div = document.createElement('div');
        div.id = 'adminRuntimeStatus';
        div.className = 'admin-span-12';
        main.prepend(div);
        box = div;
      }
    }
    if (box) box.innerHTML = '<article class="admin-pro-card admin-runtime-status ' + esc(tone || 'info') + '"><p>' + esc(text) + '</p></article>';
  }

  async function load() {
    var main = $('adminMain');
    var t = token();
    if (!t) {
      if (main) main.innerHTML = inlineLoginCard('No admin session found for this domain. Enter the wallet and password here; no private admin key is used in V6.8.12.');
      return;
    }
    if (!supabaseUrl() || !supabaseAnonKey()) {
      if (main) main.innerHTML = inlineLoginCard('Supabase config unavailable. Check js/config.js and confirm both deployment domains contain the same Supabase URL and publishable key.');
      return;
    }
    try {
      statusCard('Loading live admin data from Supabase RPC…', 'loading');
      setStatsPending('…');
      if (main) main.innerHTML = '<article class="admin-pro-card admin-span-12"><div class="admin-empty">Loading live admin data from Supabase…</div></article>';
      var raw = await rpc('axon_admin_get_console', { p_admin_session_token: t });
      var data = normalizeConsole(raw);
      if (statsTotal(data) === 0) {
        data = await tryProbeFallback(raw);
      }
      lastConsolePayload = data;
      if (main) main.innerHTML = '<div id="adminRuntimeStatus" class="admin-span-12"></div>';
      renderPage(data);
      statusCard('Live admin data loaded from Supabase. Admin session mode: wallet + password.', 'success');
      try { console.info('[AXON_ADMIN_CONSOLE_NORMALIZED]', data); } catch (_) {}
    } catch (error) {
      console.error('[AXON ADMIN DATA]', error);
      var m = (error && error.message) || 'Admin data RPC failed.';
      if (/session|expired|invalid/i.test(m)) clearToken();
      if (main) main.innerHTML = inlineLoginCard(m);
    }
  }

  async function update(kind, id, status, note, button) {
    id = String(id || '').trim();
    if (!id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) { showNotice('Invalid record', 'The selected record id is not a valid UUID. Refresh the page and try again.', 'danger'); return; }
    var rpcName = kind === 'payment' ? 'axon_admin_update_payment_status' : 'axon_admin_update_withdrawal_status';
    var args = kind === 'payment' ? { p_admin_session_token: token(), p_payment_id: id, p_status: status, p_admin_note: note || null } : { p_admin_session_token: token(), p_withdrawal_id: id, p_status: status, p_admin_note: note || null };
    if (button) { button.dataset.originalLabel = button.textContent; button.disabled = true; button.textContent = 'Saving…'; }
    try {
      statusCard((kind === 'payment' ? 'Updating payment and activating plan…' : 'Updating withdrawal status…'), 'loading');
      var result = await rpc(rpcName, args);
      try { console.info('[AXON_ADMIN_STATUS_UPDATE_RESULT]', result); } catch (_) {}
      showNotice('Status updated', (kind === 'payment' ? 'Deposit/payment order status was changed to ' : 'Withdrawal request status was changed to ') + String(status || '').toUpperCase() + '. Click OK to reload this page and display the new status beside the record.', 'success', function () { location.reload(); });
    }
    catch (error) { showNotice('Update failed', (error && error.message) || 'The status change did not complete. Confirm the V6.8.16 SQL action patch is installed.', 'danger'); }
    finally { if (button) { button.disabled = false; button.textContent = button.dataset.originalLabel || button.textContent; } }
  }

  function confirmStatusModal(button) {
    var root = $('axonAdminModalRoot');
    var checked = root ? root.querySelector('input[name="axonNextStatus"]:checked') : null;
    var note = root && root.querySelector('#axonModalAdminNote') ? root.querySelector('#axonModalAdminNote').value : '';
    var next = checked ? checked.value : modalState.currentStatus;
    if (!next) { showNotice('Select a status', 'Choose one status before continuing.', 'warn'); return; }
    if (button) { button.disabled = true; button.textContent = 'Saving…'; }
    update(modalState.kind, modalState.id, next, note, button);
  }

  function delegate(ev) {
    var target = ev.target;
    if (!target || !target.closest) return;
    if (target.closest('#inlineAdminLoginForm')) return;
    var close = target.closest('[data-modal-close]');
    if (close) { closeModal(); return; }
    var cont = target.closest('[data-modal-continue]');
    if (cont) { confirmStatusModal(cont); return; }
    var searchClear = target.closest('[data-search-clear]');
    if (searchClear) {
      var clearId = searchClear.getAttribute('data-search-clear');
      var input = document.querySelector('[data-admin-search-input="' + clearId + '"]');
      if (input) input.value = '';
      applySearch(clearId, '');
      return;
    }
    var pick = target.closest('[data-search-pick]');
    if (pick) {
      var pickId = pick.getAttribute('data-search-pick');
      var pickQuery = pick.getAttribute('data-search-query') || '';
      var pickInput = document.querySelector('[data-admin-search-input="' + pickId + '"]');
      if (pickInput) { pickInput.value = pickQuery; pickInput.focus(); }
      applySearch(pickId, pickQuery);
      return;
    }
    var submit = target.closest('[data-search-submit]');
    if (submit) {
      var submitId = submit.getAttribute('data-search-submit');
      var submitInput = document.querySelector('[data-admin-search-input="' + submitId + '"]');
      applySearch(submitId, submitInput ? submitInput.value : '');
      return;
    }
    var change = target.closest('[data-status-change]');
    if (change) {
      var row = change.closest('[data-id]');
      if (!row) return;
      var noteEl = row.querySelector('.admin-note');
      openStatusModal(change.dataset.kind || row.getAttribute('data-record-kind') || '', row.dataset.id, change.getAttribute('data-current-status') || '', noteEl ? noteEl.value : '');
      return;
    }
  }

  function inputDelegate(ev) {
    var target = ev.target;
    if (!target || !target.matches || !target.matches('[data-admin-search-input]')) return;
    applySearch(target.getAttribute('data-admin-search-input'), target.value || '');
  }

  window.AXONAdminRuntime = {
    load: load,
    rpc: rpc,
    getToken: token,
    clearToken: clearToken,
    getLastConsolePayload: function () { return lastConsolePayload; },
    normalizeConsole: normalizeConsole,
    applySearch: applySearch
  };

  document.addEventListener('DOMContentLoaded', function () {
    document.body.addEventListener('click', delegate);
    document.body.addEventListener('input', inputDelegate);
    document.body.addEventListener('submit', function (ev) {
      if (ev.target && ev.target.id === 'inlineAdminLoginForm') loginInline(ev);
    });
    document.querySelectorAll('[data-admin-logout]').forEach(function (el) {
      el.addEventListener('click', function () { clearToken(); location.href = 'admin.html?fresh=6818'; });
    });
    load();
  });
})();

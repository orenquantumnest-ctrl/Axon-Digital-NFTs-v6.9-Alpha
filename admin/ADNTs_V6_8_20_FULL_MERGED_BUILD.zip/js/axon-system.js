(function () {
  const OVERLAY_ID = 'axonFailureOverlay';
  const EVENT_KEY = 'axonSystemEvents';

  function nowIso() {
    return new Date().toISOString();
  }

  function readEvents() {
    try { return JSON.parse(window.localStorage.getItem(EVENT_KEY) || '[]'); } catch (_) { return []; }
  }

  function writeEvent(type, payload) {
    const events = readEvents();
    events.unshift({ type, payload: payload || {}, createdAt: nowIso(), path: window.location.pathname });
    window.localStorage.setItem(EVENT_KEY, JSON.stringify(events.slice(0, 80)));
  }

  function haptic(pattern) {
    try {
      if (navigator && typeof navigator.vibrate === 'function') navigator.vibrate(pattern || 12);
    } catch (_) {}
  }

  function ensureOverlay() {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.setAttribute('role', 'alertdialog');
    overlay.setAttribute('aria-live', 'assertive');
    overlay.style.cssText = [
      'position:fixed','inset:0','z-index:999999','display:none','align-items:center','justify-content:center',
      'padding:24px','background:rgba(2,4,8,.78)','backdrop-filter:blur(28px) saturate(180%)','-webkit-backdrop-filter:blur(28px) saturate(180%)'
    ].join(';');
    overlay.innerHTML = '<div style="width:min(92vw,560px);border:1px solid rgba(0,255,178,.18);background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035));border-radius:28px;padding:26px;box-shadow:0 28px 80px rgba(0,0,0,.52), inset 0 1px 0 rgba(255,255,255,.08);color:#f2f2f8;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;"><div style="display:inline-flex;align-items:center;gap:10px;padding:8px 12px;border:1px solid rgba(212,175,55,.18);border-radius:999px;color:#f0cc55;font-size:12px;letter-spacing:.12em;text-transform:uppercase;">AetherRa.IXV Protocol</div><h2 style="margin:16px 0 8px;font-size:26px;line-height:1.12;">System protection engaged</h2><p id="axonFailureText" style="margin:0 0 18px;color:rgba(242,242,248,.72);line-height:1.7;">A critical workflow returned an unsafe or incomplete result. The interface is paused until the action is corrected.</p><div style="display:flex;gap:10px;flex-wrap:wrap;"><button id="axonFailureRetry" type="button" style="border:0;border-radius:999px;padding:12px 18px;background:#00ffb2;color:#060608;font-weight:800;cursor:pointer;">Retry Action</button><button id="axonFailureRelease" type="button" style="border:1px solid rgba(255,255,255,.12);border-radius:999px;padding:12px 18px;background:rgba(255,255,255,.04);color:#f2f2f8;font-weight:700;cursor:pointer;">Release UI</button></div></div>';
    document.body.appendChild(overlay);
    overlay.querySelector('#axonFailureRelease').addEventListener('click', releaseUI);
    overlay.querySelector('#axonFailureRetry').addEventListener('click', function () {
      releaseUI();
      window.dispatchEvent(new CustomEvent('axon:failure-retry'));
    });
    return overlay;
  }

  function freezeUI(message, payload) {
    const overlay = ensureOverlay();
    const text = overlay.querySelector('#axonFailureText');
    if (text) text.textContent = message || 'A protected operation failed validation. Review the action and try again.';
    overlay.style.display = 'flex';
    document.documentElement.style.overflow = 'hidden';
    haptic([18, 40, 18]);
    writeEvent('failure_intercept_freeze', { message, payload });
  }

  function releaseUI() {
    const overlay = document.getElementById(OVERLAY_ID);
    if (overlay) overlay.style.display = 'none';
    document.documentElement.style.overflow = '';
    haptic(8);
    writeEvent('failure_intercept_release', {});
  }

  function useFailureIntercept(options) {
    const config = options || {};
    const threshold = typeof config.threshold === 'number' ? config.threshold : 100;
    return {
      verify: function (score, message, payload) {
        const numericScore = Number(score || 0);
        if (numericScore < threshold) {
          freezeUI(message || 'Goal quality is below the locked execution threshold.', { score: numericScore, threshold, payload });
          return false;
        }
        return true;
      },
      guard: async function (operation, message) {
        try {
          const result = await operation();
          return result;
        } catch (error) {
          freezeUI(message || (error && error.message) || 'Operation failed and was intercepted.', { error: String(error && error.message ? error.message : error) });
          throw error;
        }
      },
      freeze: freezeUI,
      release: releaseUI
    };
  }

  function markInteractiveMotion() {
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;
    document.querySelectorAll('button, .btn, a, input, textarea, .glass-card, .plan-card').forEach(function (el) {
      el.addEventListener('pointerdown', function () { haptic(7); }, { passive: true });
    });
  }

  function installUnhandledGuards() {
    window.addEventListener('unhandledrejection', function (event) {
      const message = event && event.reason && event.reason.message ? event.reason.message : String(event.reason || 'Unhandled async failure');
      writeEvent('unhandledrejection', { message });
    });
    window.addEventListener('error', function (event) {
      writeEvent('error', { message: event.message, filename: event.filename, line: event.lineno });
    });
  }

  window.useFailureIntercept = useFailureIntercept;
  window.AXONSystem = {
    haptic,
    freezeUI,
    releaseUI,
    eventLog: readEvents,
    writeEvent,
    version: '6.7.0'
  };

  document.addEventListener('DOMContentLoaded', function () {
    ensureOverlay();
    markInteractiveMotion();
    installUnhandledGuards();
  });
})();

-- AXON DIGITAL NFTs V6.7 FULL CONSOLIDATED SUPABASE MIGRATION
-- Contains V6.5 fixed baseline, V6.6 withdrawals, and V6.7 admin/security additions.
-- Designed to be additive/idempotent and preserve existing data.

-- AXON DIGITAL NFTs v6.5 consolidated Supabase PostgreSQL migration
-- IMPORTANT: Supabase uses PostgreSQL, not MySQL.
-- This migration is additive/idempotent and is designed to preserve existing data.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- Core tables
-- -----------------------------------------------------------------------------
create table if not exists public.users (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text unique not null,
  password_hash text,
  referral_code text unique,
  referred_by text,
  created_at timestamptz not null default now()
);

alter table public.users add column if not exists password_hash text;
alter table public.users add column if not exists referral_code text;
alter table public.users add column if not exists referred_by text;
alter table public.users add column if not exists created_at timestamptz not null default now();

create table if not exists public.user_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.payment_submissions (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  plan_name text not null,
  plan_price numeric(12,2) not null default 0,
  amount_sent numeric(12,2) not null default 0,
  tx_hash text not null,
  proof_storage_path text,
  payment_notes text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

alter table public.payment_submissions add column if not exists plan_price numeric(12,2) not null default 0;
alter table public.payment_submissions add column if not exists amount_sent numeric(12,2) not null default 0;
alter table public.payment_submissions add column if not exists proof_storage_path text;
alter table public.payment_submissions add column if not exists payment_notes text;
alter table public.payment_submissions add column if not exists status text not null default 'pending';
alter table public.payment_submissions add column if not exists created_at timestamptz not null default now();

create table if not exists public.user_plans (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  plan_name text not null,
  plan_price numeric(12,2) not null default 0,
  status text not null default 'pending',
  activated_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.user_plans add column if not exists activated_at timestamptz;
alter table public.user_plans add column if not exists created_at timestamptz not null default now();

create table if not exists public.transactions (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  type text not null,
  plan_name text,
  amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  source text,
  reference_id uuid,
  notes text,
  created_at timestamptz not null default now()
);

alter table public.transactions add column if not exists plan_name text;
alter table public.transactions add column if not exists source text;
alter table public.transactions add column if not exists reference_id uuid;
alter table public.transactions add column if not exists notes text;
alter table public.transactions add column if not exists created_at timestamptz not null default now();

create table if not exists public.referrals (
  id uuid primary key default extensions.gen_random_uuid(),
  referrer_wallet text not null,
  referred_wallet text not null,
  created_at timestamptz not null default now(),
  constraint referrals_no_self_ref check (lower(trim(referrer_wallet)) <> lower(trim(referred_wallet)))
);

create table if not exists public.referral_visits (
  id uuid primary key default extensions.gen_random_uuid(),
  referrer_wallet text not null,
  visitor_key text,
  landing_path text,
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- FREE miner tables
-- -----------------------------------------------------------------------------
create table if not exists public.free_miner_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null unique,
  status text not null default 'claiming',
  claims_completed integer not null default 0,
  claimed_amount numeric(12,2) not null default 0,
  last_claim_at timestamptz,
  next_claim_at timestamptz,
  activated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.free_miner_claims (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  claim_number integer not null,
  claim_amount numeric(12,2) not null default 1,
  claimed_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- Paid plan timed-claim tables
-- -----------------------------------------------------------------------------
create table if not exists public.plan_claim_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  user_plan_id uuid not null references public.user_plans(id) on delete cascade,
  plan_name text not null,
  plan_price numeric(12,2) not null default 0,
  daily_rate numeric(12,4) not null default 0,
  daily_claim_amount numeric(12,2) not null default 0,
  max_claims integer not null default 40,
  claims_completed integer not null default 0,
  total_claimed numeric(12,2) not null default 0,
  last_claim_at timestamptz,
  next_claim_at timestamptz,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint plan_claim_accounts_user_plan_unique unique (user_plan_id)
);

create table if not exists public.plan_claim_history (
  id uuid primary key default extensions.gen_random_uuid(),
  claim_account_id uuid not null references public.plan_claim_accounts(id) on delete cascade,
  wallet_address text not null,
  plan_name text not null,
  claim_number integer not null,
  claim_amount numeric(12,2) not null default 0,
  claimed_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);



-- -----------------------------------------------------------------------------
-- Compatibility column upgrades for existing live tables
-- -----------------------------------------------------------------------------
alter table if exists public.referral_visits add column if not exists visitor_key text;
alter table if exists public.referral_visits add column if not exists landing_path text;
alter table if exists public.referral_visits add column if not exists created_at timestamptz not null default now();

alter table if exists public.free_miner_accounts add column if not exists status text not null default 'claiming';
alter table if exists public.free_miner_accounts add column if not exists claims_completed integer not null default 0;
alter table if exists public.free_miner_accounts add column if not exists claimed_amount numeric(12,2) not null default 0;
alter table if exists public.free_miner_accounts add column if not exists last_claim_at timestamptz;
alter table if exists public.free_miner_accounts add column if not exists next_claim_at timestamptz;
alter table if exists public.free_miner_accounts add column if not exists activated_at timestamptz;
alter table if exists public.free_miner_accounts add column if not exists created_at timestamptz not null default now();
alter table if exists public.free_miner_accounts add column if not exists updated_at timestamptz not null default now();

alter table if exists public.free_miner_claims add column if not exists wallet_address text;
alter table if exists public.free_miner_claims add column if not exists claim_number integer;
alter table if exists public.free_miner_claims add column if not exists claim_amount numeric(12,2) not null default 1;
alter table if exists public.free_miner_claims add column if not exists claimed_at timestamptz not null default now();
alter table if exists public.free_miner_claims add column if not exists created_at timestamptz not null default now();

alter table if exists public.plan_claim_accounts add column if not exists wallet_address text;
alter table if exists public.plan_claim_accounts add column if not exists user_plan_id uuid;
alter table if exists public.plan_claim_accounts add column if not exists plan_name text;
alter table if exists public.plan_claim_accounts add column if not exists plan_price numeric(12,2) not null default 0;
alter table if exists public.plan_claim_accounts add column if not exists daily_rate numeric(12,4) not null default 0;
alter table if exists public.plan_claim_accounts add column if not exists daily_claim_amount numeric(12,2) not null default 0;
alter table if exists public.plan_claim_accounts add column if not exists max_claims integer not null default 40;
alter table if exists public.plan_claim_accounts add column if not exists claims_completed integer not null default 0;
alter table if exists public.plan_claim_accounts add column if not exists total_claimed numeric(12,2) not null default 0;
alter table if exists public.plan_claim_accounts add column if not exists last_claim_at timestamptz;
alter table if exists public.plan_claim_accounts add column if not exists next_claim_at timestamptz;
alter table if exists public.plan_claim_accounts add column if not exists status text not null default 'active';
alter table if exists public.plan_claim_accounts add column if not exists created_at timestamptz not null default now();
alter table if exists public.plan_claim_accounts add column if not exists updated_at timestamptz not null default now();

alter table if exists public.plan_claim_history add column if not exists claim_account_id uuid;
alter table if exists public.plan_claim_history add column if not exists wallet_address text;
alter table if exists public.plan_claim_history add column if not exists plan_name text;
alter table if exists public.plan_claim_history add column if not exists claim_number integer;
alter table if exists public.plan_claim_history add column if not exists claim_amount numeric(12,2) not null default 0;
alter table if exists public.plan_claim_history add column if not exists claimed_at timestamptz not null default now();
alter table if exists public.plan_claim_history add column if not exists created_at timestamptz not null default now();

-- -----------------------------------------------------------------------------
-- Helpful indexes
-- -----------------------------------------------------------------------------
create unique index if not exists users_wallet_address_idx on public.users (wallet_address);
create unique index if not exists referrals_referred_wallet_unique on public.referrals (referred_wallet);
create index if not exists referrals_referrer_wallet_idx on public.referrals (referrer_wallet, created_at desc);
create index if not exists user_sessions_wallet_idx on public.user_sessions (wallet_address, created_at desc);
create unique index if not exists user_sessions_token_idx on public.user_sessions (session_token);
create index if not exists payment_submissions_wallet_idx on public.payment_submissions (wallet_address, created_at desc);
create index if not exists user_plans_wallet_idx on public.user_plans (wallet_address, created_at desc);
create index if not exists transactions_wallet_idx on public.transactions (wallet_address, created_at desc);
create index if not exists referral_visits_referrer_idx on public.referral_visits (referrer_wallet, created_at desc);
create unique index if not exists free_miner_accounts_wallet_idx on public.free_miner_accounts (wallet_address);
create unique index if not exists free_miner_claims_wallet_number_idx on public.free_miner_claims (wallet_address, claim_number);
create index if not exists free_miner_claims_wallet_claimed_idx on public.free_miner_claims (wallet_address, claimed_at desc);
create index if not exists plan_claim_accounts_wallet_idx on public.plan_claim_accounts (wallet_address, updated_at desc);
create index if not exists plan_claim_accounts_status_idx on public.plan_claim_accounts (status);
create index if not exists plan_claim_history_wallet_idx on public.plan_claim_history (wallet_address, claimed_at desc);
create index if not exists plan_claim_history_account_idx on public.plan_claim_history (claim_account_id, claimed_at desc);

-- -----------------------------------------------------------------------------
-- RLS and revoke raw table access
-- -----------------------------------------------------------------------------
alter table public.users enable row level security;
alter table public.user_sessions enable row level security;
alter table public.payment_submissions enable row level security;
alter table public.user_plans enable row level security;
alter table public.transactions enable row level security;
alter table public.referrals enable row level security;
alter table public.referral_visits enable row level security;
alter table public.free_miner_accounts enable row level security;
alter table public.free_miner_claims enable row level security;
alter table public.plan_claim_accounts enable row level security;
alter table public.plan_claim_history enable row level security;

revoke all on table public.users from anon, authenticated;
revoke all on table public.user_sessions from anon, authenticated;
revoke all on table public.payment_submissions from anon, authenticated;
revoke all on table public.user_plans from anon, authenticated;
revoke all on table public.transactions from anon, authenticated;
revoke all on table public.referrals from anon, authenticated;
revoke all on table public.referral_visits from anon, authenticated;
revoke all on table public.free_miner_accounts from anon, authenticated;
revoke all on table public.free_miner_claims from anon, authenticated;
revoke all on table public.plan_claim_accounts from anon, authenticated;
revoke all on table public.plan_claim_history from anon, authenticated;

-- Remove old/public policies if they exist.
do $cleanup$
begin
  execute 'drop policy if exists public_users_select on public.users';
  execute 'drop policy if exists public_users_insert on public.users';
  execute 'drop policy if exists public_payment_select on public.payment_submissions';
  execute 'drop policy if exists public_payment_insert on public.payment_submissions';
  execute 'drop policy if exists public_user_plans_select on public.user_plans';
  execute 'drop policy if exists public_user_plans_insert on public.user_plans';
  execute 'drop policy if exists public_transactions_select on public.transactions';
  execute 'drop policy if exists public_transactions_insert on public.transactions';
  execute 'drop policy if exists public_referrals_select on public.referrals';
  execute 'drop policy if exists public_referrals_insert on public.referrals';
  execute 'drop policy if exists public_referral_visits_select on public.referral_visits';
  execute 'drop policy if exists public_plan_claim_accounts_select on public.plan_claim_accounts';
  execute 'drop policy if exists public_plan_claim_history_select on public.plan_claim_history';
exception
  when undefined_object then null;
end
$cleanup$;

-- -----------------------------------------------------------------------------
-- Storage bucket (private payment proofs)
-- -----------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('payment-proofs', 'payment-proofs', false)
on conflict (id) do update set public = excluded.public;

drop policy if exists public_payment_proofs_read on storage.objects;
drop policy if exists public_payment_proofs_insert on storage.objects;
drop policy if exists payment_proofs_insert_only on storage.objects;

do $$
begin
  if not exists (
    select 1
    from pg_policies
    where schemaname = 'storage' and tablename = 'objects' and policyname = 'payment_proofs_insert_only'
  ) then
    create policy payment_proofs_insert_only
    on storage.objects
    for insert
    to public
    with check (bucket_id = 'payment-proofs');
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- One-time data migrations from older AXON builds
-- -----------------------------------------------------------------------------
do $migrate$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'users' and column_name = 'password'
  ) then
    execute $sql$
      update public.users
      set password_hash = extensions.crypt(password, extensions.gen_salt('bf'))
      where coalesce(password_hash, '') = ''
        and coalesce(password, '') <> ''
    $sql$;

    execute 'alter table public.users drop column if exists password';
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'payment_submissions' and column_name = 'proof_image_url'
  ) then
    execute $sql$
      update public.payment_submissions
      set proof_storage_path = coalesce(proof_storage_path, proof_image_url)
      where proof_storage_path is null
    $sql$;

    execute 'alter table public.payment_submissions drop column if exists proof_image_url';
  end if;
end
$migrate$;

-- -----------------------------------------------------------------------------
-- Helper functions
-- -----------------------------------------------------------------------------
create or replace function public.axon_normalize_wallet(p_value text)
returns text
language sql
immutable
as $$
  select lower(trim(coalesce(p_value, '')))
$$;

create or replace function public.axon_touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_free_miner_accounts_touch on public.free_miner_accounts;
create trigger trg_free_miner_accounts_touch
before update on public.free_miner_accounts
for each row execute function public.axon_touch_updated_at();

drop trigger if exists trg_plan_claim_accounts_touch on public.plan_claim_accounts;
create trigger trg_plan_claim_accounts_touch
before update on public.plan_claim_accounts
for each row execute function public.axon_touch_updated_at();

create or replace function public.axon_issue_session(p_wallet text)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_token text;
begin
  update public.user_sessions
  set revoked_at = now()
  where wallet_address = v_wallet
    and revoked_at is null;

  v_token := encode(extensions.gen_random_bytes(32), 'hex');

  insert into public.user_sessions (wallet_address, session_token, expires_at)
  values (v_wallet, v_token, now() + interval '30 days');

  return v_token;
end;
$$;

create or replace function public.axon_assert_session(p_wallet text, p_session_token text)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
begin
  perform 1
  from public.user_sessions
  where wallet_address = v_wallet
    and session_token = p_session_token
    and revoked_at is null
    and expires_at > now();

  if not found then
    raise exception 'Session expired. Please log in again.';
  end if;
end;
$$;

create or replace function public.axon_get_session_status(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_session record;
begin
  select wallet_address, session_token, expires_at, revoked_at
  into v_session
  from public.user_sessions
  where wallet_address = v_wallet
    and session_token = p_session_token
  order by created_at desc
  limit 1;

  if not found then
    return jsonb_build_object('valid', false, 'wallet_address', v_wallet, 'reason', 'Session not found.');
  end if;

  if v_session.revoked_at is not null then
    return jsonb_build_object('valid', false, 'wallet_address', v_wallet, 'reason', 'Session revoked.', 'expires_at', v_session.expires_at);
  end if;

  if v_session.expires_at <= now() then
    return jsonb_build_object('valid', false, 'wallet_address', v_wallet, 'reason', 'Session expired.', 'expires_at', v_session.expires_at);
  end if;

  return jsonb_build_object('valid', true, 'wallet_address', v_wallet, 'expires_at', v_session.expires_at);
end;
$$;

create or replace function public.axon_logout_user(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_updated integer := 0;
begin
  update public.user_sessions
  set revoked_at = now()
  where wallet_address = v_wallet
    and session_token = p_session_token
    and revoked_at is null;

  get diagnostics v_updated = row_count;

  return jsonb_build_object('ok', true, 'wallet_address', v_wallet, 'revoked_sessions', v_updated);
end;
$$;

create or replace function public.axon_init_free_miner_account(p_wallet text)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  insert into public.free_miner_accounts (
    wallet_address,
    status,
    claims_completed,
    claimed_amount,
    last_claim_at,
    next_claim_at,
    activated_at,
    updated_at
  ) values (
    public.axon_normalize_wallet(p_wallet),
    'claiming',
    0,
    0,
    null,
    null,
    null,
    now()
  )
  on conflict (wallet_address) do nothing;
end;
$$;

create or replace function public.axon_plan_daily_rate(p_plan_name text, p_plan_price numeric)
returns numeric
language plpgsql
immutable
as $$
declare
  v_name text := lower(trim(coalesce(p_plan_name, '')));
begin
  if v_name like 'gold%' or coalesce(p_plan_price, 0) >= 500 then
    return 0.035;
  end if;
  return 0.03;
end;
$$;

create or replace function public.axon_plan_max_claims(p_plan_name text, p_plan_price numeric)
returns integer
language plpgsql
immutable
as $$
begin
  return 40;
end;
$$;

create or replace function public.axon_init_plan_claim_account(
  p_wallet text,
  p_user_plan_id uuid,
  p_plan_name text,
  p_plan_price numeric
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_rate numeric := public.axon_plan_daily_rate(p_plan_name, p_plan_price);
  v_amount numeric := round(coalesce(p_plan_price, 0) * v_rate, 2);
  v_max_claims integer := public.axon_plan_max_claims(p_plan_name, p_plan_price);
begin
  if lower(trim(coalesce(p_plan_name, ''))) like 'free%' then
    return;
  end if;

  insert into public.plan_claim_accounts (
    wallet_address,
    user_plan_id,
    plan_name,
    plan_price,
    daily_rate,
    daily_claim_amount,
    max_claims,
    claims_completed,
    total_claimed,
    status,
    next_claim_at
  )
  values (
    v_wallet,
    p_user_plan_id,
    p_plan_name,
    coalesce(p_plan_price, 0),
    v_rate,
    v_amount,
    v_max_claims,
    0,
    0,
    'active',
    null
  )
  on conflict (user_plan_id) do update
    set wallet_address = excluded.wallet_address,
        plan_name = excluded.plan_name,
        plan_price = excluded.plan_price,
        daily_rate = excluded.daily_rate,
        daily_claim_amount = excluded.daily_claim_amount,
        max_claims = excluded.max_claims;
end;
$$;

create or replace function public.axon_sync_plan_claim_account()
returns trigger
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if lower(trim(coalesce(new.plan_name, ''))) not like 'free%'
     and new.status = 'active' then
    perform public.axon_init_plan_claim_account(new.wallet_address, new.id, new.plan_name, new.plan_price);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_user_plans_sync_claim_account on public.user_plans;
create trigger trg_user_plans_sync_claim_account
after insert or update of status, plan_name, plan_price on public.user_plans
for each row execute function public.axon_sync_plan_claim_account();

-- -----------------------------------------------------------------------------
-- Auth / registration / login / referral tracking
-- -----------------------------------------------------------------------------
create or replace function public.axon_register_user(p_wallet text, p_password text, p_referred_by text default null)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_referred_by text := nullif(public.axon_normalize_wallet(p_referred_by), '');
  v_token text;
begin
  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid wallet address.';
  end if;

  if char_length(coalesce(p_password, '')) < 8 then
    raise exception 'Password must be at least 8 characters.';
  end if;

  insert into public.users (wallet_address, password_hash, referral_code, referred_by)
  values (
    v_wallet,
    extensions.crypt(p_password, extensions.gen_salt('bf')),
    v_wallet,
    case when v_referred_by = v_wallet then null else v_referred_by end
  );

  if v_referred_by is not null and v_referred_by <> v_wallet then
    insert into public.referrals (referrer_wallet, referred_wallet)
    values (v_referred_by, v_wallet)
    on conflict (referred_wallet)
    do update set referrer_wallet = excluded.referrer_wallet;
  end if;

  perform public.axon_init_free_miner_account(v_wallet);

  v_token := public.axon_issue_session(v_wallet);

  return jsonb_build_object(
    'wallet_address', v_wallet,
    'session_token', v_token,
    'referral_link', format('https://axondigitalnfts.com/signup.html?ref=%s', v_wallet)
  );
exception
  when unique_violation then
    raise exception 'This wallet is already registered. Use the Login page instead.';
end;
$$;

create or replace function public.axon_login_user(p_wallet text, p_password text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_hash text;
  v_token text;
begin
  select password_hash
  into v_hash
  from public.users
  where wallet_address = v_wallet
  limit 1;

  if v_hash is null or extensions.crypt(p_password, v_hash) <> v_hash then
    raise exception 'Invalid credentials.';
  end if;

  perform public.axon_init_free_miner_account(v_wallet);
  v_token := public.axon_issue_session(v_wallet);

  return jsonb_build_object(
    'wallet_address', v_wallet,
    'session_token', v_token,
    'referral_link', format('https://axondigitalnfts.com/signup.html?ref=%s', v_wallet)
  );
end;
$$;

create or replace function public.axon_track_referral_visit(
  p_referrer_wallet text,
  p_visitor_key text default null,
  p_landing_path text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_referrer_wallet);
  v_total integer := 0;
begin
  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid referral wallet.';
  end if;

  insert into public.referral_visits (referrer_wallet, visitor_key, landing_path)
  values (v_wallet, nullif(trim(coalesce(p_visitor_key, '')), ''), nullif(trim(coalesce(p_landing_path, '')), ''));

  select count(*)::integer into v_total
  from public.referral_visits
  where referrer_wallet = v_wallet;

  return jsonb_build_object('referrer_wallet', v_wallet, 'referral_visits_count', v_total);
end;
$$;

-- -----------------------------------------------------------------------------
-- Payments
-- -----------------------------------------------------------------------------
create or replace function public.axon_submit_payment(
  p_wallet text,
  p_session_token text,
  p_plan_name text,
  p_plan_price numeric,
  p_tx_hash text,
  p_proof_storage_path text,
  p_amount_sent numeric,
  p_payment_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_submission_id uuid;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid wallet address.';
  end if;

  if lower(trim(coalesce(p_plan_name, ''))) like 'free%' then
    raise exception 'FREE NFT uses the dashboard daily claim flow and does not accept payment proof uploads.';
  end if;

  if coalesce(p_tx_hash, '') !~ '^0x[a-fA-F0-9]{64}$' then
    raise exception 'Invalid transaction hash.';
  end if;

  if coalesce(p_amount_sent, 0) <= 0 then
    raise exception 'Invalid payment amount.';
  end if;

  insert into public.payment_submissions (
    wallet_address,
    plan_name,
    plan_price,
    amount_sent,
    tx_hash,
    proof_storage_path,
    payment_notes,
    status
  ) values (
    v_wallet,
    p_plan_name,
    coalesce(p_plan_price, 0),
    coalesce(p_amount_sent, 0),
    p_tx_hash,
    p_proof_storage_path,
    p_payment_notes,
    'pending'
  )
  returning id into v_submission_id;

  insert into public.user_plans (
    wallet_address,
    plan_name,
    plan_price,
    status
  )
  select v_wallet, p_plan_name, coalesce(p_plan_price, 0), 'pending'
  where not exists (
    select 1
    from public.user_plans
    where wallet_address = v_wallet
      and plan_name = p_plan_name
      and status in ('pending', 'active')
  );

  insert into public.transactions (
    wallet_address,
    type,
    plan_name,
    amount,
    status,
    source,
    reference_id,
    notes
  ) values (
    v_wallet,
    'Payment Submission',
    p_plan_name,
    coalesce(p_amount_sent, 0),
    'pending',
    'payment_submission',
    v_submission_id,
    p_payment_notes
  );

  return jsonb_build_object('ok', true, 'wallet_address', v_wallet, 'status', 'pending', 'payment_submission_id', v_submission_id);
end;
$$;

-- -----------------------------------------------------------------------------
-- FREE miner
-- -----------------------------------------------------------------------------
create or replace function public.axon_get_free_miner_status(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_account public.free_miner_accounts%rowtype;
  v_referral_count integer := 0;
  v_seconds_remaining integer := 0;
  v_can_claim boolean := false;
  v_can_activate boolean := false;
  v_reason text := '';
  v_recent_claims jsonb := '[]'::jsonb;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);
  perform public.axon_init_free_miner_account(v_wallet);

  select * into v_account
  from public.free_miner_accounts
  where wallet_address = v_wallet;

  select count(*)::integer into v_referral_count
  from public.referrals
  where referrer_wallet = v_wallet;

  if v_account.next_claim_at is not null and now() < v_account.next_claim_at then
    v_seconds_remaining := greatest(0, floor(extract(epoch from (v_account.next_claim_at - now())))::integer);
  end if;

  v_can_claim := v_account.status <> 'active'
    and v_account.claims_completed < 40
    and (v_account.next_claim_at is null or now() >= v_account.next_claim_at);

  v_can_activate := v_account.status <> 'active'
    and v_account.claims_completed >= 40
    and v_account.claimed_amount >= 40
    and v_referral_count >= 1;

  if v_account.status = 'active' then
    v_reason := 'FREE NFT miner is already active.';
  elsif v_account.claims_completed < 40 then
    v_reason := 'Complete 40 daily claims before activation becomes available.';
  elsif v_referral_count < 1 then
    v_reason := 'Refer at least 1 person to activate the FREE NFT miner.';
  else
    v_reason := 'Miner ready for activation.';
  end if;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.claimed_at desc), '[]'::jsonb)
  into v_recent_claims
  from (
    select claim_number, claim_amount, claimed_at
    from public.free_miner_claims
    where wallet_address = v_wallet
    order by claimed_at desc
    limit 10
  ) t;

  return jsonb_build_object(
    'wallet_address', v_wallet,
    'status', v_account.status,
    'claims_completed', v_account.claims_completed,
    'max_claims', 40,
    'claimed_amount', v_account.claimed_amount,
    'last_claim_at', v_account.last_claim_at,
    'next_claim_at', v_account.next_claim_at,
    'seconds_remaining', v_seconds_remaining,
    'cycle_progress_percent', case
      when v_account.status = 'active' then 100
      when v_account.next_claim_at is null or v_account.next_claim_at <= now() then 100
      else greatest(0, least(100, round(((86400 - greatest(0, extract(epoch from (v_account.next_claim_at - now())))) / 86400.0) * 100, 2)))
    end,
    'referral_count', v_referral_count,
    'can_claim', v_can_claim,
    'can_activate', v_can_activate,
    'activation_locked_reason', v_reason,
    'recent_claims', v_recent_claims
  );
end;
$$;

create or replace function public.axon_claim_free_miner(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_account public.free_miner_accounts%rowtype;
  v_claim_number integer;
  v_now timestamptz := now();
  v_tx_id uuid;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);
  perform public.axon_init_free_miner_account(v_wallet);

  select * into v_account
  from public.free_miner_accounts
  where wallet_address = v_wallet
  for update;

  if v_account.status = 'active' then
    raise exception 'FREE NFT miner is already active.';
  end if;

  if v_account.claims_completed >= 40 then
    raise exception 'All 40 daily claims are already complete. Activate the miner from the dashboard.';
  end if;

  if v_account.next_claim_at is not null and v_now < v_account.next_claim_at then
    raise exception 'Daily claim is still on cooldown. Wait until the next 24-hour window opens.';
  end if;

  v_claim_number := v_account.claims_completed + 1;

  insert into public.free_miner_claims (
    wallet_address,
    claim_number,
    claim_amount,
    claimed_at
  ) values (
    v_wallet,
    v_claim_number,
    1,
    v_now
  );

  update public.free_miner_accounts
  set claims_completed = v_claim_number,
      claimed_amount = v_claim_number,
      last_claim_at = v_now,
      next_claim_at = case when v_claim_number >= 40 then null else v_now + interval '24 hours' end,
      status = case when v_claim_number >= 40 then 'ready_to_activate' else 'claiming' end,
      updated_at = v_now
  where wallet_address = v_wallet;

  insert into public.transactions (
    wallet_address,
    type,
    plan_name,
    amount,
    status,
    source,
    notes,
    created_at
  ) values (
    v_wallet,
    'Free Miner Claim',
    'FREE NFT',
    1,
    'completed',
    'free_miner_claim',
    format('Claim %s of 40', v_claim_number),
    v_now
  )
  returning id into v_tx_id;

  return public.axon_get_free_miner_status(v_wallet, p_session_token);
end;
$$;

create or replace function public.axon_activate_free_miner(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_account public.free_miner_accounts%rowtype;
  v_referral_count integer := 0;
  v_now timestamptz := now();
begin
  perform public.axon_assert_session(v_wallet, p_session_token);
  perform public.axon_init_free_miner_account(v_wallet);

  select * into v_account
  from public.free_miner_accounts
  where wallet_address = v_wallet
  for update;

  if v_account.status = 'active' then
    return public.axon_get_free_miner_status(v_wallet, p_session_token);
  end if;

  if v_account.claims_completed < 40 or v_account.claimed_amount < 40 then
    raise exception 'Complete all 40 daily claims before activating the FREE NFT miner.';
  end if;

  select count(*)::integer into v_referral_count
  from public.referrals
  where referrer_wallet = v_wallet;

  if v_referral_count < 1 then
    raise exception 'Refer at least 1 person before activating the FREE NFT miner.';
  end if;

  update public.free_miner_accounts
  set status = 'active',
      activated_at = v_now,
      updated_at = v_now,
      next_claim_at = null
  where wallet_address = v_wallet;

  if exists (
    select 1 from public.user_plans
    where wallet_address = v_wallet
      and plan_name = 'FREE NFT'
  ) then
    update public.user_plans
    set status = 'active',
        activated_at = v_now,
        plan_price = 40
    where wallet_address = v_wallet
      and plan_name = 'FREE NFT';
  else
    insert into public.user_plans (
      wallet_address,
      plan_name,
      plan_price,
      status,
      activated_at,
      created_at
    ) values (
      v_wallet,
      'FREE NFT',
      40,
      'active',
      v_now,
      v_now
    );
  end if;

  insert into public.transactions (
    wallet_address,
    type,
    plan_name,
    amount,
    status,
    source,
    notes,
    created_at
  ) values (
    v_wallet,
    'Free Miner Activation',
    'FREE NFT',
    40,
    'completed',
    'free_miner_activation',
    'FREE NFT miner activated',
    v_now
  );

  return public.axon_get_free_miner_status(v_wallet, p_session_token);
end;
$$;

-- -----------------------------------------------------------------------------
-- Paid plan timed claims
-- -----------------------------------------------------------------------------
create or replace function public.axon_get_plan_claim_statuses(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_items jsonb := '[]'::jsonb;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  select coalesce(jsonb_agg(item order by sort_created_at desc), '[]'::jsonb)
  into v_items
  from (
    select
      jsonb_build_object(
        'claim_account_id', pca.id,
        'user_plan_id', pca.user_plan_id,
        'plan_name', pca.plan_name,
        'plan_price', pca.plan_price,
        'daily_rate', pca.daily_rate,
        'daily_claim_amount', pca.daily_claim_amount,
        'max_claims', pca.max_claims,
        'claims_completed', pca.claims_completed,
        'total_claimed', pca.total_claimed,
        'status', pca.status,
        'last_claim_at', pca.last_claim_at,
        'next_claim_at', pca.next_claim_at,
        'seconds_remaining',
          case
            when pca.status = 'completed' then 0
            when pca.next_claim_at is null or pca.next_claim_at <= now() then 0
            else greatest(0, floor(extract(epoch from (pca.next_claim_at - now())))::integer)
          end,
        'can_claim',
          case
            when pca.status = 'completed' then false
            when pca.claims_completed >= pca.max_claims then false
            when pca.next_claim_at is null or pca.next_claim_at <= now() then true
            else false
          end,
        'cycle_progress_percent',
          case
            when pca.status = 'completed' then 100
            when pca.next_claim_at is null or pca.next_claim_at <= now() then 100
            else greatest(0, least(100, round(((86400 - greatest(0, extract(epoch from (pca.next_claim_at - now())))) / 86400.0) * 100, 2)))
          end
      ) as item,
      coalesce(pca.updated_at, pca.created_at) as sort_created_at
    from public.plan_claim_accounts pca
    where pca.wallet_address = v_wallet
    order by coalesce(pca.updated_at, pca.created_at) desc
  ) q;

  return v_items;
end;
$$;

create or replace function public.axon_claim_plan_reward(
  p_wallet text,
  p_session_token text,
  p_claim_account_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_account public.plan_claim_accounts%rowtype;
  v_now timestamptz := now();
  v_claim_number integer;
  v_recent_claims jsonb := '[]'::jsonb;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  select *
  into v_account
  from public.plan_claim_accounts
  where id = p_claim_account_id
    and wallet_address = v_wallet
  for update;

  if not found then
    raise exception 'Plan claim account was not found.';
  end if;

  if v_account.status = 'completed' or v_account.claims_completed >= v_account.max_claims then
    raise exception 'This plan reward cycle is already complete.';
  end if;

  if v_account.next_claim_at is not null and v_account.next_claim_at > v_now then
    raise exception 'This plan is still on cooldown. Please wait until the next 24-hour window opens.';
  end if;

  v_claim_number := v_account.claims_completed + 1;

  insert into public.plan_claim_history (
    claim_account_id,
    wallet_address,
    plan_name,
    claim_number,
    claim_amount,
    claimed_at
  ) values (
    v_account.id,
    v_wallet,
    v_account.plan_name,
    v_claim_number,
    v_account.daily_claim_amount,
    v_now
  );

  update public.plan_claim_accounts
  set claims_completed = v_claim_number,
      total_claimed = total_claimed + v_account.daily_claim_amount,
      last_claim_at = v_now,
      next_claim_at = case when v_claim_number >= max_claims then null else v_now + interval '24 hours' end,
      status = case when v_claim_number >= max_claims then 'completed' else 'active' end,
      updated_at = v_now
  where id = v_account.id
  returning * into v_account;

  insert into public.transactions (
    wallet_address,
    type,
    plan_name,
    amount,
    status,
    source,
    notes,
    created_at
  ) values (
    v_wallet,
    'Paid Plan Claim',
    v_account.plan_name,
    v_account.daily_claim_amount,
    'completed',
    'plan_claim',
    format('Claim %s of %s', v_claim_number, v_account.max_claims),
    v_now
  );

  select coalesce(jsonb_agg(jsonb_build_object(
    'id', pch.id,
    'plan_name', pch.plan_name,
    'claim_number', pch.claim_number,
    'claim_amount', pch.claim_amount,
    'claimed_at', pch.claimed_at
  ) order by pch.claimed_at desc), '[]'::jsonb)
  into v_recent_claims
  from (
    select *
    from public.plan_claim_history
    where claim_account_id = v_account.id
    order by claimed_at desc
    limit 10
  ) pch;

  return jsonb_build_object(
    'claim_account_id', v_account.id,
    'plan_name', v_account.plan_name,
    'plan_price', v_account.plan_price,
    'daily_rate', v_account.daily_rate,
    'daily_claim_amount', v_account.daily_claim_amount,
    'max_claims', v_account.max_claims,
    'claims_completed', v_account.claims_completed,
    'total_claimed', v_account.total_claimed,
    'status', v_account.status,
    'last_claim_at', v_account.last_claim_at,
    'next_claim_at', v_account.next_claim_at,
    'seconds_remaining', case when v_account.next_claim_at is null then 0 else greatest(0, floor(extract(epoch from (v_account.next_claim_at - now())))::integer) end,
    'can_claim', case when v_account.status = 'completed' then false when v_account.next_claim_at is null or v_account.next_claim_at <= now() then true else false end,
    'cycle_progress_percent', case
      when v_account.status = 'completed' then 100
      when v_account.next_claim_at is null or v_account.next_claim_at <= now() then 100
      else greatest(0, least(100, round(((86400 - greatest(0, extract(epoch from (v_account.next_claim_at - now())))) / 86400.0) * 100, 2)))
    end,
    'recent_claims', v_recent_claims
  );
end;
$$;

-- -----------------------------------------------------------------------------
-- Unified dashboard payload
-- -----------------------------------------------------------------------------
create or replace function public.axon_get_dashboard(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_latest_plan jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_referrals_count integer := 0;
  v_referral_visits_count integer := 0;
  v_active_nfts integer := 0;
  v_recent_referrals jsonb := '[]'::jsonb;
  v_referred_by text := '';
  v_active_plans jsonb := '[]'::jsonb;
  v_total_earnings numeric := 0;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);
  perform public.axon_init_free_miner_account(v_wallet);

  select to_jsonb(t)
  into v_latest_plan
  from (
    select plan_name, plan_price, status, created_at, activated_at
    from public.user_plans
    where wallet_address = v_wallet
    order by coalesce(activated_at, created_at) desc
    limit 1
  ) t;

  select public.axon_get_plan_claim_statuses(v_wallet, p_session_token)
  into v_active_plans;

  select coalesce(sum(amount), 0)
  into v_total_earnings
  from (
    select coalesce(fm.claim_amount, 0)::numeric as amount
    from public.free_miner_claims fm
    where fm.wallet_address = v_wallet
    union all
    select coalesce(pch.claim_amount, 0)::numeric as amount
    from public.plan_claim_history pch
    where pch.wallet_address = v_wallet
  ) earnings;

  select count(*)::integer into v_referrals_count
  from public.referrals
  where referrer_wallet = v_wallet;

  select count(*)::integer into v_referral_visits_count
  from public.referral_visits
  where referrer_wallet = v_wallet;

  select count(*)::integer into v_active_nfts
  from public.user_plans
  where wallet_address = v_wallet
    and status = 'active';

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb)
  into v_recent_referrals
  from (
    select referred_wallet, created_at
    from public.referrals
    where referrer_wallet = v_wallet
    order by created_at desc
    limit 10
  ) t;

  select coalesce(referred_by, '') into v_referred_by
  from public.users
  where wallet_address = v_wallet
  limit 1;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb)
  into v_transactions
  from (
    select type, plan_name, amount, status, source, notes, created_at
    from public.transactions
    where wallet_address = v_wallet
    order by created_at desc
    limit 50
  ) t;

  return jsonb_build_object(
    'latest_plan', v_latest_plan,
    'active_plans', v_active_plans,
    'transactions', v_transactions,
    'referrals_count', v_referrals_count,
    'referral_visits_count', v_referral_visits_count,
    'recent_referrals', v_recent_referrals,
    'referred_by', v_referred_by,
    'active_nfts', v_active_nfts,
    'total_earnings', v_total_earnings,
    'free_miner', public.axon_get_free_miner_status(v_wallet, p_session_token)
  );
end;
$$;

-- -----------------------------------------------------------------------------
-- Backfills to preserve/enable existing live users
-- -----------------------------------------------------------------------------
-- Ensure all existing users have a FREE miner account.
insert into public.free_miner_accounts (
  wallet_address,
  status,
  claims_completed,
  claimed_amount,
  created_at,
  updated_at
)
select lower(trim(u.wallet_address)), 'claiming', 0, 0, now(), now()
from public.users u
left join public.free_miner_accounts fma on fma.wallet_address = lower(trim(u.wallet_address))
where fma.id is null;

-- Ensure currently active paid plans have timed-claim accounts.
insert into public.plan_claim_accounts (
  wallet_address,
  user_plan_id,
  plan_name,
  plan_price,
  daily_rate,
  daily_claim_amount,
  max_claims,
  claims_completed,
  total_claimed,
  status,
  next_claim_at
)
select
  lower(trim(up.wallet_address)),
  up.id,
  up.plan_name,
  up.plan_price,
  public.axon_plan_daily_rate(up.plan_name, up.plan_price),
  round(coalesce(up.plan_price, 0) * public.axon_plan_daily_rate(up.plan_name, up.plan_price), 2),
  public.axon_plan_max_claims(up.plan_name, up.plan_price),
  0,
  0,
  'active',
  null
from public.user_plans up
left join public.plan_claim_accounts pca on pca.user_plan_id = up.id
where up.status = 'active'
  and lower(trim(coalesce(up.plan_name, ''))) not like 'free%'
  and pca.id is null;



-- Backfill missing user_plans rows from historical payment submissions.
insert into public.user_plans (
  wallet_address,
  plan_name,
  plan_price,
  status,
  created_at
)
select
  lower(trim(ps.wallet_address)) as wallet_address,
  ps.plan_name,
  coalesce(ps.plan_price, 0) as plan_price,
  case
    when lower(coalesce(ps.status, 'pending')) in ('completed', 'approved') then 'active'
    else 'pending'
  end as status,
  coalesce(ps.created_at, now()) as created_at
from public.payment_submissions ps
left join public.user_plans up
  on lower(trim(up.wallet_address)) = lower(trim(ps.wallet_address))
 and lower(trim(coalesce(up.plan_name, ''))) = lower(trim(coalesce(ps.plan_name, '')))
where up.id is null;

-- Keep user_plans status aligned with reviewed payment submissions.
update public.user_plans up
set status = case
  when lower(coalesce(ps.status, 'pending')) in ('completed', 'approved') then 'active'
  when lower(coalesce(ps.status, 'pending')) = 'rejected' then up.status
  else 'pending'
end
from public.payment_submissions ps
where lower(trim(up.wallet_address)) = lower(trim(ps.wallet_address))
  and lower(trim(coalesce(up.plan_name, ''))) = lower(trim(coalesce(ps.plan_name, '')));

-- -----------------------------------------------------------------------------
-- Grants
-- -----------------------------------------------------------------------------
grant execute on function public.axon_normalize_wallet(text) to anon, authenticated;
grant execute on function public.axon_issue_session(text) to anon, authenticated;
grant execute on function public.axon_assert_session(text, text) to anon, authenticated;
grant execute on function public.axon_get_session_status(text, text) to anon, authenticated;
grant execute on function public.axon_logout_user(text, text) to anon, authenticated;
grant execute on function public.axon_init_free_miner_account(text) to anon, authenticated;
grant execute on function public.axon_register_user(text, text, text) to anon, authenticated;
grant execute on function public.axon_login_user(text, text) to anon, authenticated;
grant execute on function public.axon_track_referral_visit(text, text, text) to anon, authenticated;
grant execute on function public.axon_submit_payment(text, text, text, numeric, text, text, numeric, text) to anon, authenticated;
grant execute on function public.axon_get_free_miner_status(text, text) to anon, authenticated;
grant execute on function public.axon_claim_free_miner(text, text) to anon, authenticated;
grant execute on function public.axon_activate_free_miner(text, text) to anon, authenticated;
grant execute on function public.axon_plan_daily_rate(text, numeric) to anon, authenticated;
grant execute on function public.axon_plan_max_claims(text, numeric) to anon, authenticated;
grant execute on function public.axon_init_plan_claim_account(text, uuid, text, numeric) to anon, authenticated;
grant execute on function public.axon_get_plan_claim_statuses(text, text) to anon, authenticated;
grant execute on function public.axon_claim_plan_reward(text, text, uuid) to anon, authenticated;
grant execute on function public.axon_get_dashboard(text, text) to anon, authenticated;


-- ===== V6.6 WITHDRAWALS PATCH =====

-- AXON DIGITAL NFTs V6.6 additive patch
-- Adds the $20 Lite paid plan compatibility and user-side withdrawals.
-- No admin portal is included in this release.

create table if not exists public.withdrawal_requests (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text not null,
  payout_wallet text not null,
  requested_amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  user_note text,
  admin_note text,
  created_at timestamptz not null default now(),
  processed_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table if exists public.withdrawal_requests add column if not exists wallet_address text;
alter table if exists public.withdrawal_requests add column if not exists payout_wallet text;
alter table if exists public.withdrawal_requests add column if not exists requested_amount numeric(12,2) not null default 0;
alter table if exists public.withdrawal_requests add column if not exists status text not null default 'pending';
alter table if exists public.withdrawal_requests add column if not exists user_note text;
alter table if exists public.withdrawal_requests add column if not exists admin_note text;
alter table if exists public.withdrawal_requests add column if not exists created_at timestamptz not null default now();
alter table if exists public.withdrawal_requests add column if not exists processed_at timestamptz;
alter table if exists public.withdrawal_requests add column if not exists updated_at timestamptz not null default now();

create index if not exists withdrawal_requests_wallet_idx on public.withdrawal_requests (wallet_address, created_at desc);
create index if not exists withdrawal_requests_status_idx on public.withdrawal_requests (status, created_at desc);

alter table public.withdrawal_requests enable row level security;
revoke all on table public.withdrawal_requests from anon, authenticated;

do $cleanup$
begin
  execute 'drop policy if exists public_withdrawal_requests_select on public.withdrawal_requests';
  execute 'drop policy if exists public_withdrawal_requests_insert on public.withdrawal_requests';
exception
  when undefined_object then null;
end
$cleanup$;

drop trigger if exists trg_withdrawal_requests_touch on public.withdrawal_requests;
create trigger trg_withdrawal_requests_touch
before update on public.withdrawal_requests
for each row execute function public.axon_touch_updated_at();

create or replace function public.axon_total_claim_earnings(p_wallet text)
returns numeric
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(sum(amount), 0)::numeric
  from (
    select coalesce(fm.claim_amount, 0)::numeric as amount
    from public.free_miner_claims fm
    where lower(trim(fm.wallet_address)) = public.axon_normalize_wallet(p_wallet)

    union all

    select coalesce(pch.claim_amount, 0)::numeric as amount
    from public.plan_claim_history pch
    where lower(trim(pch.wallet_address)) = public.axon_normalize_wallet(p_wallet)
  ) q
$$;

create or replace function public.axon_reserved_withdrawal_total(p_wallet text)
returns numeric
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(sum(coalesce(wr.requested_amount, 0)), 0)::numeric
  from public.withdrawal_requests wr
  where lower(trim(wr.wallet_address)) = public.axon_normalize_wallet(p_wallet)
    and lower(trim(coalesce(wr.status, 'pending'))) in ('pending', 'processing', 'completed')
$$;

create or replace function public.axon_sync_withdrawal_transaction()
returns trigger
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_notes text;
begin
  v_notes := concat_ws(' • ',
    nullif(trim(coalesce(new.user_note, '')), ''),
    case when nullif(trim(coalesce(new.admin_note, '')), '') is not null then 'Admin: ' || trim(new.admin_note) else null end,
    'Payout: ' || new.payout_wallet
  );

  update public.transactions
  set amount = -1 * coalesce(new.requested_amount, 0),
      status = coalesce(new.status, 'pending'),
      notes = nullif(v_notes, ''),
      created_at = coalesce(transactions.created_at, new.created_at)
  where source = 'withdrawal_request'
    and reference_id = new.id;

  if not found then
    insert into public.transactions (
      wallet_address,
      type,
      plan_name,
      amount,
      status,
      source,
      reference_id,
      notes,
      created_at
    ) values (
      public.axon_normalize_wallet(new.wallet_address),
      'Withdrawal Request',
      'Withdrawals',
      -1 * coalesce(new.requested_amount, 0),
      coalesce(new.status, 'pending'),
      'withdrawal_request',
      new.id,
      nullif(v_notes, ''),
      coalesce(new.created_at, now())
    );
  end if;

  return new;
end;
$$;

drop trigger if exists trg_withdrawal_requests_sync_transaction on public.withdrawal_requests;
create trigger trg_withdrawal_requests_sync_transaction
after insert or update of requested_amount, status, payout_wallet, user_note, admin_note on public.withdrawal_requests
for each row execute function public.axon_sync_withdrawal_transaction();

create or replace function public.axon_get_withdrawal_summary(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_minimum numeric := 10;
  v_total_earnings numeric := 0;
  v_reserved numeric := 0;
  v_available numeric := 0;
  v_history jsonb := '[]'::jsonb;
  v_latest_status text := 'minimum not reached';
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  v_total_earnings := public.axon_total_claim_earnings(v_wallet);
  v_reserved := public.axon_reserved_withdrawal_total(v_wallet);
  v_available := greatest(0, v_total_earnings - v_reserved);

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb)
  into v_history
  from (
    select id, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at
    from public.withdrawal_requests
    where lower(trim(wallet_address)) = v_wallet
    order by created_at desc
    limit 20
  ) t;

  select coalesce(status, 'minimum not reached')
  into v_latest_status
  from public.withdrawal_requests
  where lower(trim(wallet_address)) = v_wallet
  order by created_at desc
  limit 1;

  if v_available >= v_minimum then
    v_latest_status := case when v_latest_status is null or v_latest_status = '' then 'available' else v_latest_status end;
  end if;

  return jsonb_build_object(
    'wallet_address', v_wallet,
    'minimum_withdrawal', v_minimum,
    'total_earnings', v_total_earnings,
    'reserved_amount', v_reserved,
    'available_balance', v_available,
    'can_request', (v_available >= v_minimum),
    'latest_status', v_latest_status,
    'recent_requests', v_history
  );
end;
$$;

create or replace function public.axon_request_withdrawal(
  p_wallet text,
  p_session_token text,
  p_amount numeric,
  p_payout_wallet text,
  p_user_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_wallet(p_wallet);
  v_payout_wallet text := public.axon_normalize_wallet(p_payout_wallet);
  v_amount numeric := round(coalesce(p_amount, 0), 2);
  v_minimum numeric := 10;
  v_available numeric := 0;
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid wallet address.';
  end if;

  if v_payout_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Enter a valid BEP20 receiving wallet.';
  end if;

  if v_amount < v_minimum then
    raise exception 'Minimum withdrawal is $10.00.';
  end if;

  v_available := greatest(0, public.axon_total_claim_earnings(v_wallet) - public.axon_reserved_withdrawal_total(v_wallet));

  if v_amount > v_available then
    raise exception 'Requested amount is above the available withdrawal balance.';
  end if;

  insert into public.withdrawal_requests (
    wallet_address,
    payout_wallet,
    requested_amount,
    status,
    user_note,
    created_at,
    updated_at
  ) values (
    v_wallet,
    v_payout_wallet,
    v_amount,
    'pending',
    nullif(trim(coalesce(p_user_note, '')), ''),
    now(),
    now()
  );

  return public.axon_get_withdrawal_summary(v_wallet, p_session_token);
end;
$$;

grant execute on function public.axon_total_claim_earnings(text) to anon, authenticated;
grant execute on function public.axon_reserved_withdrawal_total(text) to anon, authenticated;
grant execute on function public.axon_get_withdrawal_summary(text, text) to anon, authenticated;
grant execute on function public.axon_request_withdrawal(text, text, numeric, text, text) to anon, authenticated;


-- ===== V6.7 ADMIN / SECURITY PATCH =====

-- AXON DIGITAL NFTs V6.7 additive admin/security patch
-- Run after the V6.5 baseline and V6.6 withdrawals patch, or run the consolidated supabase_v6_7_full.sql.
-- This patch is idempotent and preserves existing data.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- Operational metadata / audit tables
-- -----------------------------------------------------------------------------
alter table if exists public.payment_submissions add column if not exists admin_note text;
alter table if exists public.payment_submissions add column if not exists processed_at timestamptz;
alter table if exists public.payment_submissions add column if not exists updated_at timestamptz not null default now();

create table if not exists public.axon_admin_config (
  key text primary key,
  value_hash text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.axon_admin_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.axon_admin_audit_log (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_id uuid,
  action text not null,
  target_table text,
  target_id uuid,
  status text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.axon_system_events (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text,
  event_type text not null,
  severity text not null default 'info',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists axon_admin_sessions_token_idx on public.axon_admin_sessions (admin_session_token, expires_at desc);
create index if not exists axon_admin_audit_log_created_idx on public.axon_admin_audit_log (created_at desc);
create index if not exists axon_system_events_created_idx on public.axon_system_events (created_at desc);
create index if not exists payment_submissions_status_idx on public.payment_submissions (status, created_at desc);
create index if not exists user_plans_wallet_status_idx on public.user_plans (wallet_address, status, created_at desc);

alter table public.axon_admin_config enable row level security;
alter table public.axon_admin_sessions enable row level security;
alter table public.axon_admin_audit_log enable row level security;
alter table public.axon_system_events enable row level security;
revoke all on table public.axon_admin_config from public, anon, authenticated;
revoke all on table public.axon_admin_sessions from public, anon, authenticated;
revoke all on table public.axon_admin_audit_log from public, anon, authenticated;
revoke all on table public.axon_system_events from public, anon, authenticated;

-- Keep payment review timestamps current.
drop trigger if exists trg_payment_submissions_touch on public.payment_submissions;
create trigger trg_payment_submissions_touch
before update on public.payment_submissions
for each row execute function public.axon_touch_updated_at();

-- -----------------------------------------------------------------------------
-- Admin key setup. Run from Supabase SQL editor only:
-- select public.axon_admin_set_key('REPLACE_WITH_A_LONG_PRIVATE_ADMIN_KEY');
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_set_key(p_admin_key text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if char_length(coalesce(p_admin_key, '')) < 12 then
    raise exception 'Admin key must be at least 12 characters.';
  end if;

  insert into public.axon_admin_config (key, value_hash, updated_at)
  values ('primary_admin_key', extensions.crypt(p_admin_key, extensions.gen_salt('bf')), now())
  on conflict (key) do update
    set value_hash = excluded.value_hash,
        updated_at = now();

  insert into public.axon_admin_audit_log (action, target_table, status, note)
  values ('admin_key_rotated', 'axon_admin_config', 'completed', 'Primary admin key was updated from Supabase SQL editor.');

  return jsonb_build_object('ok', true, 'message', 'Admin key configured.');
end;
$$;

create or replace function public.axon_admin_login(p_admin_key text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_hash text;
  v_token text;
  v_expires timestamptz := now() + interval '8 hours';
  v_session_id uuid;
begin
  select value_hash into v_hash
  from public.axon_admin_config
  where key = 'primary_admin_key'
  limit 1;

  if v_hash is null then
    raise exception 'Admin key is not configured. Run select public.axon_admin_set_key(''YOUR_STRONG_ADMIN_KEY'') in the Supabase SQL editor.';
  end if;

  if extensions.crypt(coalesce(p_admin_key, ''), v_hash) <> v_hash then
    raise exception 'Invalid admin key.';
  end if;

  delete from public.axon_admin_sessions where expires_at < now() - interval '1 day';

  v_token := encode(extensions.gen_random_bytes(32), 'hex');

  insert into public.axon_admin_sessions (admin_session_token, expires_at)
  values (v_token, v_expires)
  returning id into v_session_id;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, status, note)
  values (v_session_id, 'admin_login', 'axon_admin_sessions', 'completed', 'Admin console session opened.');

  return jsonb_build_object(
    'admin_session_token', v_token,
    'expires_at', v_expires
  );
end;
$$;

create or replace function public.axon_admin_assert_session(p_admin_session_token text)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
begin
  select id into v_session_id
  from public.axon_admin_sessions
  where admin_session_token = coalesce(p_admin_session_token, '')
    and revoked_at is null
    and expires_at > now()
  limit 1;

  if v_session_id is null then
    raise exception 'Admin session expired or invalid.';
  end if;

  return v_session_id;
end;
$$;

create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires
  from public.axon_admin_sessions
  where id = v_session_id;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing', 'completed');

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.users),
    'active_plans_count', (select count(*) from public.user_plans where status = 'active'),
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 30
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 30
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select wallet_address, referred_by, created_at
    from public.users
    order by created_at desc
    limit 30
  ) t;

  return jsonb_build_object(
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'session_expires_at', v_expires
  );
end;
$$;

create or replace function public.axon_admin_update_payment_status(
  p_admin_session_token text,
  p_payment_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_payment public.payment_submissions%rowtype;
  v_plan_id uuid;
  v_plan_status text;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  if v_status not in ('pending', 'processing', 'approved', 'completed', 'rejected') then
    raise exception 'Invalid payment status.';
  end if;

  select * into v_payment
  from public.payment_submissions
  where id = p_payment_id
  for update;

  if not found then
    raise exception 'Payment submission not found.';
  end if;

  update public.payment_submissions
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else processed_at end
  where id = p_payment_id
  returning * into v_payment;

  update public.transactions
  set status = v_status,
      notes = concat_ws(' • ', nullif(notes, ''), case when nullif(trim(coalesce(p_admin_note, '')), '') is not null then 'Admin: ' || trim(p_admin_note) else null end)
  where source = 'payment_submission'
    and reference_id = p_payment_id;

  if v_status in ('approved', 'completed') then
    v_plan_status := 'active';
  elsif v_status = 'rejected' then
    v_plan_status := 'rejected';
  else
    v_plan_status := 'pending';
  end if;

  select id into v_plan_id
  from public.user_plans
  where lower(trim(wallet_address)) = public.axon_normalize_wallet(v_payment.wallet_address)
    and lower(trim(coalesce(plan_name, ''))) = lower(trim(coalesce(v_payment.plan_name, '')))
  order by created_at desc
  limit 1;

  if v_plan_id is null then
    insert into public.user_plans (wallet_address, plan_name, plan_price, status, activated_at, created_at)
    values (
      public.axon_normalize_wallet(v_payment.wallet_address),
      v_payment.plan_name,
      coalesce(v_payment.plan_price, 0),
      v_plan_status,
      case when v_plan_status = 'active' then now() else null end,
      now()
    ) returning id into v_plan_id;
  else
    update public.user_plans
    set status = v_plan_status,
        plan_price = coalesce(v_payment.plan_price, plan_price),
        activated_at = case when v_plan_status = 'active' then coalesce(activated_at, now()) else activated_at end
    where id = v_plan_id;
  end if;

  if v_plan_status = 'active' then
    perform public.axon_init_plan_claim_account(v_payment.wallet_address, v_plan_id, v_payment.plan_name, v_payment.plan_price);
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'payment_status_update', 'payment_submissions', p_payment_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'payment_id', p_payment_id, 'status', v_status, 'user_plan_id', v_plan_id);
end;
$$;

create or replace function public.axon_admin_update_withdrawal_status(
  p_admin_session_token text,
  p_withdrawal_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  if v_status not in ('pending', 'processing', 'completed', 'rejected') then
    raise exception 'Invalid withdrawal status.';
  end if;

  update public.withdrawal_requests
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_withdrawal_id;

  if not found then
    raise exception 'Withdrawal request not found.';
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'withdrawal_status_update', 'withdrawal_requests', p_withdrawal_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'withdrawal_id', p_withdrawal_id, 'status', v_status);
end;
$$;

-- Keep direct table access closed; expose only guarded RPC functions.
revoke all on function public.axon_admin_set_key(text) from public, anon, authenticated;
revoke all on function public.axon_admin_assert_session(text) from public, anon, authenticated;
revoke all on function public.axon_admin_login(text) from public, anon, authenticated;
revoke all on function public.axon_admin_get_console(text) from public, anon, authenticated;
revoke all on function public.axon_admin_update_payment_status(text, uuid, text, text) from public, anon, authenticated;
revoke all on function public.axon_admin_update_withdrawal_status(text, uuid, text, text) from public, anon, authenticated;

grant execute on function public.axon_admin_login(text) to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;
grant execute on function public.axon_admin_update_payment_status(text, uuid, text, text) to anon, authenticated;
grant execute on function public.axon_admin_update_withdrawal_status(text, uuid, text, text) to anon, authenticated;

-- V6.7 hardening: helper functions used internally by SECURITY DEFINER RPCs should not be callable directly from browsers.
revoke all on function public.axon_issue_session(text) from public, anon, authenticated;
revoke all on function public.axon_assert_session(text, text) from public, anon, authenticated;
revoke all on function public.axon_init_free_miner_account(text) from public, anon, authenticated;
revoke all on function public.axon_init_plan_claim_account(text, uuid, text, numeric) from public, anon, authenticated;

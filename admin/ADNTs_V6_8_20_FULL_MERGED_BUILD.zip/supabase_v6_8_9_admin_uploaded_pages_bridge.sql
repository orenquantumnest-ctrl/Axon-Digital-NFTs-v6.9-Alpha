-- AXON DIGITAL NFTs V6.8.9 — Admin Uploaded Pages Bridge
-- Purpose:
--   Connect the uploaded admin-login.html/admin-dashboard.html pages to the live V6.8.7 schema.
--   Adds wallet+PIN and username+PIN compatibility using admin_accounts while preserving
--   existing V6.8.6 wallet/password login and V6.8.7 live-data admin console RPC.
-- Run after:
--   1) supabase_v6_8_6_admin_wallet_login_patch.sql
--   2) supabase_v6_8_7_schema_aligned_admin_console_patch.sql

create extension if not exists pgcrypto with schema extensions;

-- Ensure admin_accounts/admin_sessions have defaults expected by the uploaded admin pages.
create table if not exists public.admin_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  role text not null default 'sub_admin',
  wallet_address text,
  username text,
  pin_hash text not null,
  department text,
  permission_bundle jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  last_login_at timestamptz,
  created_by_admin_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  display_name text,
  wallet_modal_label text,
  account_number text,
  admin_tag text
);

alter table public.admin_accounts alter column id set default extensions.gen_random_uuid();
alter table public.admin_accounts alter column permission_bundle set default '{}'::jsonb;
alter table public.admin_accounts alter column is_active set default true;
alter table public.admin_accounts alter column created_at set default now();
alter table public.admin_accounts alter column updated_at set default now();

create table if not exists public.admin_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_id uuid not null,
  session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_id uuid,
  action_name text not null,
  entity_type text,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.admin_accounts enable row level security;
alter table public.admin_sessions enable row level security;
alter table public.admin_audit_logs enable row level security;
revoke all on table public.admin_accounts from public, anon, authenticated;
revoke all on table public.admin_sessions from public, anon, authenticated;
revoke all on table public.admin_audit_logs from public, anon, authenticated;

create or replace function public.axon_admin_pin_matches(p_pin text, p_hash text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if coalesce(p_pin, '') = '' or coalesce(p_hash, '') = '' then
    return false;
  end if;

  begin
    if extensions.crypt(p_pin, p_hash) = p_hash then
      return true;
    end if;
  exception when others then
    null;
  end;

  -- Legacy fallback only. Allows old seeded PIN rows to work, but all new writes use bcrypt.
  return p_hash = p_pin;
end;
$$;

create or replace function public.axon_admin_login_v689(
  p_mode text,
  p_wallet_address text,
  p_username text,
  p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_mode text := lower(trim(coalesce(p_mode, 'super')));
  v_wallet text := lower(trim(coalesce(p_wallet_address, '')));
  v_username text := lower(trim(coalesce(p_username, '')));
  v_pin text := coalesce(p_pin, '');
  v_account public.admin_accounts%rowtype;
  v_wallet_account record;
  v_token text := encode(extensions.gen_random_bytes(32), 'hex');
  v_expires timestamptz := now() + interval '8 hours';
  v_axon_session_id uuid;
  v_admin_session_id uuid;
begin
  if v_pin = '' then
    raise exception 'Admin PIN/password is required.';
  end if;

  if v_mode = 'sub' then
    if v_username = '' then
      raise exception 'Sub-admin username is required.';
    end if;

    select * into v_account
    from public.admin_accounts
    where lower(trim(coalesce(username, ''))) = v_username
      and coalesce(is_active, false) = true
    order by created_at desc
    limit 1;
  else
    if v_wallet !~ '^0x[a-f0-9]{40}$' then
      raise exception 'Valid super-admin wallet address is required.';
    end if;

    select * into v_account
    from public.admin_accounts
    where lower(trim(coalesce(wallet_address, ''))) = v_wallet
      and coalesce(is_active, false) = true
    order by created_at desc
    limit 1;
  end if;

  if v_account.id is not null then
    if not public.axon_admin_pin_matches(v_pin, v_account.pin_hash) then
      raise exception 'Invalid admin credentials.';
    end if;

    insert into public.axon_admin_sessions (admin_session_token, expires_at)
    values (v_token, v_expires)
    returning id into v_axon_session_id;

    insert into public.admin_sessions (admin_id, session_token, expires_at)
    values (v_account.id, v_token, v_expires)
    returning id into v_admin_session_id;

    update public.admin_accounts
    set last_login_at = now(), updated_at = now()
    where id = v_account.id;

    insert into public.admin_audit_logs (admin_id, action_name, entity_type, entity_id, details)
    values (v_account.id, 'admin_login_v689', 'admin_accounts', v_account.id::text, jsonb_build_object('mode', v_mode, 'source', 'uploaded_admin_pages'));

    return jsonb_build_object(
      'ok', true,
      'admin_session_token', v_token,
      'session_token', v_token,
      'expires_at', v_expires,
      'admin_id', v_account.id,
      'wallet_address', v_account.wallet_address,
      'username', v_account.username,
      'display_name', coalesce(v_account.display_name, v_account.username, 'AXON Admin'),
      'role', coalesce(v_account.role, 'admin'),
      'department', coalesce(v_account.department, 'Operations'),
      'permission_bundle', coalesce(v_account.permission_bundle, '{}'::jsonb)
    );
  end if;

  -- Fallback for V6.8.6 wallet/password admin account if admin_accounts has not been seeded yet.
  if v_mode <> 'sub' and v_wallet ~ '^0x[a-f0-9]{40}$' then
    select id, wallet_address, password_hash, display_name, role, status
    into v_wallet_account
    from public.axon_admin_wallet_accounts
    where wallet_address = v_wallet
    limit 1;

    if v_wallet_account.id is not null then
      if lower(coalesce(v_wallet_account.status, 'suspended')) <> 'active' then
        raise exception 'Admin wallet account is not active.';
      end if;
      if not public.axon_admin_pin_matches(v_pin, v_wallet_account.password_hash) then
        raise exception 'Invalid admin wallet or password.';
      end if;

      insert into public.axon_admin_sessions (admin_session_token, expires_at)
      values (v_token, v_expires)
      returning id into v_axon_session_id;

      update public.axon_admin_wallet_accounts
      set last_login_at = now(), updated_at = now()
      where id = v_wallet_account.id;

      insert into public.axon_admin_audit_log (admin_session_id, action, target_table, status, note)
      values (v_axon_session_id, 'admin_login_v689_wallet_fallback', 'axon_admin_wallet_accounts', 'completed', 'Uploaded admin page wallet/password login opened.');

      return jsonb_build_object(
        'ok', true,
        'admin_session_token', v_token,
        'session_token', v_token,
        'expires_at', v_expires,
        'wallet_address', v_wallet_account.wallet_address,
        'display_name', v_wallet_account.display_name,
        'role', v_wallet_account.role,
        'department', 'Executive Control',
        'permission_bundle', jsonb_build_object('users', true, 'payments', true, 'withdrawals', true, 'plans', true, 'admins', true, 'audit', true)
      );
    end if;
  end if;

  raise exception 'Admin account not found. Seed admin_accounts or run the V6.8.6 wallet account setup.';
end;
$$;

create or replace function public.axon_admin_create_sub_admin_v689(
  p_admin_session_token text,
  p_username text,
  p_pin text,
  p_department text,
  p_permissions jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_username text := lower(trim(coalesce(p_username, '')));
  v_existing_id uuid;
  v_id uuid;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  if v_username = '' then
    raise exception 'Sub-admin username is required.';
  end if;

  if char_length(coalesce(p_pin, '')) < 6 then
    raise exception 'Sub-admin PIN must be at least 6 characters.';
  end if;

  select id into v_existing_id
  from public.admin_accounts
  where lower(trim(coalesce(username, ''))) = v_username
  order by created_at desc
  limit 1;

  if v_existing_id is null then
    insert into public.admin_accounts (
      role,
      username,
      pin_hash,
      department,
      permission_bundle,
      is_active,
      display_name,
      admin_tag
    ) values (
      'sub_admin',
      v_username,
      extensions.crypt(p_pin, extensions.gen_salt('bf')),
      coalesce(nullif(trim(p_department), ''), 'operations'),
      coalesce(p_permissions, '{}'::jsonb),
      true,
      v_username,
      'V6.8.9_SUB_ADMIN'
    ) returning id into v_id;
  else
    update public.admin_accounts
    set pin_hash = extensions.crypt(p_pin, extensions.gen_salt('bf')),
        department = coalesce(nullif(trim(p_department), ''), department, 'operations'),
        permission_bundle = coalesce(p_permissions, permission_bundle, '{}'::jsonb),
        is_active = true,
        updated_at = now()
    where id = v_existing_id
    returning id into v_id;
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'create_or_update_sub_admin_v689', 'admin_accounts', v_id, 'completed', 'Sub-admin account created/updated from uploaded admin dashboard.');

  return jsonb_build_object('ok', true, 'admin_id', v_id, 'username', v_username, 'message', 'Sub-admin account saved.');
end;
$$;

create or replace function public.axon_admin_uploaded_pages_health()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'ok', true,
    'version', '6.8.9',
    'admin_accounts', (select count(*) from public.admin_accounts),
    'active_admin_accounts', (select count(*) from public.admin_accounts where coalesce(is_active,false) = true),
    'axon_wallet_accounts', (select count(*) from public.axon_admin_wallet_accounts),
    'admin_sessions', (select count(*) from public.admin_sessions where revoked_at is null and expires_at > now()),
    'axon_admin_sessions', (select count(*) from public.axon_admin_sessions where revoked_at is null and expires_at > now()),
    'live_data_probe', public.axon_admin_live_data_probe()
  );
$$;

revoke all on function public.axon_admin_pin_matches(text,text) from public;
revoke all on function public.axon_admin_login_v689(text,text,text,text) from public;
revoke all on function public.axon_admin_create_sub_admin_v689(text,text,text,text,jsonb) from public;
revoke all on function public.axon_admin_uploaded_pages_health() from public;

grant execute on function public.axon_admin_login_v689(text,text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_create_sub_admin_v689(text,text,text,text,jsonb) to anon, authenticated;
grant execute on function public.axon_admin_uploaded_pages_health() to anon, authenticated;

select public.axon_admin_uploaded_pages_health() as axon_v689_admin_uploaded_pages_health;

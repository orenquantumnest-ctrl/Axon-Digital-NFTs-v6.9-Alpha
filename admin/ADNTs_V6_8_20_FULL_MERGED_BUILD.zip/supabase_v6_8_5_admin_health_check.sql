-- AXON V6.8.5 Admin Health Check
select 'admin_key_row' as check_name, count(*)::text as result from public.axon_admin_config where key='primary_admin_key'
union all select 'admin_sessions', count(*)::text from public.axon_admin_sessions
union all select 'users', count(*)::text from public.users
union all select 'payment_submissions', count(*)::text from public.payment_submissions
union all select 'withdrawal_requests', count(*)::text from public.withdrawal_requests
union all select 'transactions', count(*)::text from public.transactions
union all select 'plan_claim_accounts', count(*)::text from public.plan_claim_accounts
union all select 'free_miner_accounts', count(*)::text from public.free_miner_accounts
union all select 'axon_plan_catalog', count(*)::text from public.axon_plan_catalog
union all select 'audit_logs', count(*)::text from public.axon_admin_audit_log;

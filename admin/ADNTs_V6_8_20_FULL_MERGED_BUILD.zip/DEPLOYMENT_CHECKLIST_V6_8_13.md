# AXON DIGITAL NFTs V6.8.13 — Admin SwiftUI Pages Deployment

## Upload
Upload the contents of `build_v6813/` to both production roots:

- `axondigitalnfts.com`
- `axonprime-vault.netlify.app`

## Keep user side
The user-side files are preserved from V6.8.12. This build changes the admin UI/pages only.

## Supabase
Keep the Supabase fixes already run:

- `supabase_v6_8_12_role_safe_admin_login_console_patch.sql`
- `supabase_v6_8_12_pgcrypto_crypt_login_fix_DO_NOT_UPLOAD.sql`

## Test links
- `/admin.html?fresh=6813`
- `/admin-dashboard.html?fresh=6813`
- `/admin-users.html?fresh=6813`
- `/admin-deposits.html?fresh=6813`
- `/admin-withdrawals.html?fresh=6813`
- `/admin-plans.html?fresh=6813`
- `/admin-transactions.html?fresh=6813`
- `/admin-audit-logs.html?fresh=6813`

## Build hash
`91465d78925a794021c91214650922f790113dd472918bdd62259b6529f961cd`

# AXON DIGITAL NFTs V6.8.5 Deployment Checklist

1. Keep V6.8.4.2 as the rollback package.
2. Upload the full contents of this package directly into `public_html`.
3. Run `supabase_v6_8_5_admin_console_live_data_patch.sql` in Supabase SQL Editor.
4. Do not place the private admin key inside `admin.html` or any frontend file.
5. Open `https://axondigitalnfts.com/admin.html?fresh=6853` in a normal browser tab.
6. Enter the private admin key and open the dashboard.
7. Test `admin-dashboard.html`, `admin-users.html`, `admin-plans.html`, `admin-deposits.html`, `admin-withdrawals.html`, `admin-transactions.html`, and `admin-audit-logs.html`.
8. On `admin-plans.html`, test create/edit/suspend/activate/hide/delete.
9. Run `supabase_v6_8_5_admin_health_check.sql` only if admin counts still appear empty.
10. Hard refresh the website or clear site data if old CSS/JS continues to display.

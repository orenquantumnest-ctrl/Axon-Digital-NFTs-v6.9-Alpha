# AXON DIGITAL NFTs V6.8.5 Technical Blueprint

## Base
V6.8.4.2 Admin Session Bridge is preserved as the locked baseline.

## Admin UI
- Responsive sidebar + mobile glass drawer.
- Liquid Glass-style admin cards, hero panels, metric cards, list cells, and footer.
- Lottie JSON animation asset with lottie-web CDN support and CSS fallback.
- Dedicated admin pages remain standalone.

## Admin Data
`axon_admin_get_console` now returns live records for:
- users
- payment submissions
- withdrawal requests
- transactions
- plan claim accounts
- free miner accounts
- audit logs
- system events
- plan catalog

## Plan Governance
V6.8.5 adds:
- create plan
- edit plan
- hide/show plan
- suspend/reactivate plan
- safe soft-delete plan

Deleted plans are not destroyed from historical records. They are set to `status='deleted'`, `is_visible=false`, and `deleted_at=now()`.

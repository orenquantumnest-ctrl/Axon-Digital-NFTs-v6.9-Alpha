# AXON DIGITAL NFTs V6.8.2 Technical Blueprint

## Scope
V6.8.2 is a dashboard-focused patch release built from V6.8.1.

## Preserved
- V6.8 standalone authenticated user pages
- V6.8 admin standalone pages
- V6.8.1 responsive Liquid Glass navigation
- V6.7 Supabase security/admin/payment/withdrawal/claim RPC foundation

## Added
### Files
- `css/v682-dashboard-claims.css`
- `js/v682-dashboard-claims.js`
- `BUILD_HASH_V6_8_2.txt`
- `DEPLOYMENT_CHECKLIST_V6_8_2.md`
- `TECHNICAL_BLUEPRINT_V6_8_2.md`

### Dashboard HTML
- Added dashboard-specific stylesheet.
- Added paid plan claim center.
- Added live feedback region.
- Added plan claim card container.
- Added V6.8.2 dashboard-specific script.

## Paid Claim Logic
The dashboard script uses:

```js
supabase.rpc('axon_get_dashboard', {
  p_wallet: user.wallet,
  p_session_token: user.sessionToken
})
```

to load active paid plan claim accounts.

To claim a subscribed paid plan reward, it calls:

```js
supabase.rpc('axon_claim_plan_reward', {
  p_wallet: user.wallet,
  p_session_token: user.sessionToken,
  p_claim_account_id: claimId
})
```

## UI Behavior
Each subscribed paid plan card displays:
- plan name
- plan price
- daily claim amount
- daily rate
- claims completed / max claims
- 24-hour claim-window progress
- total plan completion progress
- next claim window
- one-tap claim button

## Responsive Design
The V6.8.2 dashboard layer is mobile-first and inherits the V6.8.1 topbar drawer.

Small screens use:
- stacked plan claim cards
- full-width claim buttons
- reduced hero height
- safer text scaling
- tighter glass card radii

Desktop and tablet screens use:
- two-column claim cards
- wide dashboard shell
- large Liquid Glass hero
- larger metric-card rhythm

## Database Migration
No destructive SQL migration is required.

## Build Hash
The non-secret V6.8.2 build hash is stored in:

- `BUILD_HASH_V6_8_2.txt`
- `VERSION.json`
- `admin.html` security marker

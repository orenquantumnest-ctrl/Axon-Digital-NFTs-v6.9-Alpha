# AXON DIGITAL NFTs V6.8.5.3 — Config Sync Patch

## Added
- `js/config.js` as the primary runtime configuration file.
- `js/config.example.js` as the safe starter template for future environments.
- Updated `js/supabase-config.js` into a backward-compatible bridge.
- Updated HTML files to load `js/config.js?v=6853` before `js/supabase-config.js?v=6853`.
- Added `supabase_v6_8_5_1_admin_live_data_backfill_patch.sql` into the package root so the admin live-data backfill patch is part of the deployable project archive.

## Important
- Both `axondigitalnfts.com` and `axonprime-vault.netlify.app` must use the same `js/config.js` values.
- The browser config only contains the public Supabase URL and public anon/publishable key.
- Never place the Supabase service-role key or private admin key in `js/config.js`, `admin.html`, or any frontend file.

## Live database visibility
After deploying this ZIP, run:

```sql
select public.axon_admin_live_data_probe();
```

If the probe returns zeros, the connected Supabase database is empty or not the same project that contains the live AXON users.

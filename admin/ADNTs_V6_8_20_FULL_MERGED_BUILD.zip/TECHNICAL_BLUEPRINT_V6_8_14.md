# V6.8.14 Technical Blueprint

This build fixes two live issues:

- Admin payment approval now synchronizes `payment_submissions`, `transactions`, `user_plans`, `plan_claim_accounts`, and `user_notifications`.
- Mobile card geometry was tightened for user ledgers and admin records to prevent overlap and bad rectangular widget stacking.

No user-side logic was removed.

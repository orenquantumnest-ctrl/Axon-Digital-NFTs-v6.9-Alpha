# AXON DIGITAL NFTs V6.8.16.1 Deployment Checklist

- User-side files are preserved from V6.8.16.
- Admin UI is locked to the V6.8.13 SwiftUI/Liquid Glass design layer.
- Admin action/list fixes from V6.8.16 remain active.
- No new SQL is required if `supabase_v6_8_16_admin_action_list_fix.sql` is already installed.

Upload the contents of `build_v6816_1/` directly to the website root.

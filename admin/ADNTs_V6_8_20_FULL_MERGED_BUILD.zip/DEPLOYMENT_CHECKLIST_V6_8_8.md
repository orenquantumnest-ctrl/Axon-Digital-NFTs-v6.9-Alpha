# AXON DIGITAL NFTs V6.8.8 Deployment Checklist

## Scope
- User frontend remains the current V6.8.7 structure/design.
- Admin frontend uses V6.7-style interface ethics.
- Admin data uses V6.8.7 schema-aligned Supabase RPC.
- Admin login uses official wallet + Supabase-hashed password. No private admin key flow.

## Upload
Upload the extracted ZIP contents to both domains:
- axondigitalnfts.com
- axonprime-vault.netlify.app

Files must sit at the web root, not inside a nested folder.

## Supabase
If already on V6.8.7, no new destructive database migration is required. Ensure this SQL has been run in the connected Supabase project:
- supabase_v6_8_6_admin_wallet_login_patch.sql
- supabase_v6_8_7_schema_aligned_admin_console_patch.sql

## Test
Open:
- /admin.html?fresh=688
- /admin-dashboard.html?fresh=688
- /admin-users.html?fresh=688
- /admin-deposits.html?fresh=688
- /admin-withdrawals.html?fresh=688
- /admin-plans.html?fresh=688

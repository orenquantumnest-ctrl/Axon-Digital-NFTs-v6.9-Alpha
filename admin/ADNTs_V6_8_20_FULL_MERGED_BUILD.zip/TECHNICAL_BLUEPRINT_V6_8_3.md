# AXON DIGITAL NFTs V6.8.3 Technical Blueprint

Build hash: `88a1bdcbcd515c967a82817579a2bb8b143b258d8ff36c37fa5f4cee11ac7126`

## Base
V6.8.3 is built from V6.8.2 and preserves the standalone Liquid Glass structure.

## Files added
- `js/v683-paid-claim-live.js`
- `css/v683-paid-claim-live.css`
- `BUILD_HASH_V6_8_3.txt`
- `DEPLOYMENT_CHECKLIST_V6_8_3.md`
- `TECHNICAL_BLUEPRINT_V6_8_3.md`
- `supabase_v6_8_3_notes.sql`

## Files updated
- `dashboard.html`
- `VERSION.json`
- `admin.html` build marker only

## User dashboard behavior
The paid-plan dashboard now includes two surfaces:

1. Active Plan Preview
   - Plan name
   - Status
   - Plan price
   - Daily claim amount
   - Days claimed
   - Days remaining
   - Dashboard route button: `Go to this plan`

2. 24-Hour Paid Claim Countdown
   - 24-hour live countdown
   - 24-hour progress bar
   - Plan completion bar
   - Days claimed
   - Days remaining
   - Claim button

## Timer logic
The browser calculates live countdown values from `next_claim_at` when available, falling back to `seconds_remaining`. When the countdown reaches zero, V6.8.3 silently refreshes dashboard RPC data so server-side claim eligibility becomes authoritative.

## Security
No private admin key is embedded into frontend files. `admin.html` only carries a non-secret build hash marker.

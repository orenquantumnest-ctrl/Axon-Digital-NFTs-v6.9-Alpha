# AXON DIGITAL NFTs V6.8.17 Technical Blueprint

V6.8.17 preserves the V6.8.16.1 UI lock and V6.8.16 backend action fix, then adds admin interaction UX.

## Main frontend changes

- Generic live search/filter engine in `js/v68-admin-pages.js`.
- Search suggestions for wallet address, transaction hash, amount, status, plan, date, notes, and record payload values.
- Status-change modal for payment and withdrawal records.
- Success/error modal notice system replacing browser alert dialog boxes.
- Record cards now expose purpose text and status-aware transparent outline controls.

## Backend

No new backend migration. The status updates still use:

- `axon_admin_update_payment_status`
- `axon_admin_update_withdrawal_status`

These are provided by the V6.8.16 SQL action/list fix.

Build hash: `5539cc5b0c6be64c1d91c60a702a07929b5266c0694091893dcd722ed3540158`

# AXON DIGITAL NFTs V6.8.6 Locked Notes

V6.8.6 is the active build for admin wallet/password login.

- Old private admin-key login has been removed from the frontend flow.
- Admin access uses official wallet `0x7bbc456C2C34972723cF03b9D44323d2539514dE` plus the generated admin password configured in Supabase.
- Admin pages include inline login when no session exists on the current domain.
- `js/config.js` remains public-only configuration. Do not add service-role keys or plaintext admin passwords to frontend code.
- Build hash: `92d5599080a5676fe7a3bd5e6e4b12a23625686c62551e7c91cfadc448f951d0`

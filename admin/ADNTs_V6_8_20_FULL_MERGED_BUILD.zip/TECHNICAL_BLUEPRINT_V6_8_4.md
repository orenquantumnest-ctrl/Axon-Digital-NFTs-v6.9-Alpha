# AXON DIGITAL NFTs V6.8.4 Technical Blueprint

Build hash: `50b8f778ff645e48aca7deebc2f5fc935b2ccc6fff17f3f67df96ebc0f8ac963`

## Added Frontend Files
- `css/v684-plan-catalog.css`
- `js/v684-plan-catalog.js`
- `js/v684-admin-plan-manager.js`

## Added Supabase Patch
- `supabase_v6_8_4_plan_catalog_patch.sql`

## User Experience
- Dashboard now includes a compact Available Plans marketplace preview.
- Plans page now includes both active plans and a full plan catalog.
- Subscribe actions route users into the preserved payment proof flow.

## Admin Experience
- Admin dashboard includes a plan catalog governance summary.
- Admin plans page includes add/edit/hide/feature controls.
- Live writes require admin session token and V6.8.4 SQL RPCs.

## Security Position
- No admin private key is embedded in HTML, CSS, or JavaScript.
- Admin plan writes require `axon_admin_assert_session`.
- Plan catalog public read exposes only user-facing plan data.

# AXON DIGITAL NFTs V6.7 Deployment Checklist

## 1. Database

1. Open Supabase SQL Editor.
2. Run `supabase_v6_7_full.sql` once.
3. Set the private admin key from Supabase SQL Editor:

```sql
select public.axon_admin_set_key('REPLACE_WITH_A_LONG_PRIVATE_ADMIN_KEY');
```

Use a private key with at least 12 characters. Do not commit the admin key into frontend code.

## 2. Hosting

1. Upload all V6.7 files to the public site root.
2. Confirm these paths load:
   - `/index.html`
   - `/signup.html`
   - `/login.html`
   - `/dashboard.html`
   - `/payment.html`
   - `/admin.html`
3. Hard refresh or test from a private browser tab.

## 3. Required manual test flow

1. Create a new account using a valid BEP20 wallet format.
2. Login and verify dashboard stats load.
3. Claim FREE NFT daily claim if available.
4. Select Lite `$20` plan and submit a payment proof.
5. Open `/admin.html`, login with the admin key, approve the payment.
6. Return to dashboard and confirm the paid plan appears under Active Plans.
7. Create a withdrawal request after available claim balance reaches the minimum.
8. Use `/admin.html` to mark withdrawal as processing/completed/rejected.

## 4. Launch safety

- Keep the Supabase service-role key out of all frontend files.
- Use the publishable anon key only in `js/supabase-config.js`.
- Review local financial, crypto, consumer-protection, tax, and age-eligibility requirements before accepting public payments.
- Keep marketing copy aligned with platform records and claim schedules. Do not present the platform as guaranteed financial advice.

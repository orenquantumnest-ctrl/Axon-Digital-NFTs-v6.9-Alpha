# AXON DIGITAL NFTs V6.7 Technical Blueprint

## Build identity

Version: `ADNTs_V6_7`

Base preserved:
- V6.5 corrected Supabase baseline.
- V6.6 `$20 Lite` plan and user-side withdrawal flow.
- Existing brand assets, landing page, onboarding, signup, login, dashboard, payment, and withdrawal screens.

## Additive upgrades

### Admin operations console

Added:
- `admin.html`
- `js/admin.js`
- admin RPC login
- live stats
- payment proof review
- plan activation on approval/completion
- withdrawal status management
- admin audit log

The admin console does not expose the Supabase service-role key. It uses a private admin key hashed inside Supabase and guarded by RPC session tokens.

### AetherRa.IXV failure intercept

Added:
- `js/axon-system.js`
- `window.useFailureIntercept()`
- frozen UI overlay for critical failure states
- haptic feedback through `navigator.vibrate()` where supported
- local critical-event logging for diagnostics

### Security hardening

Added:
- admin tables with RLS enabled
- direct table grants revoked for admin/session/audit tables
- direct public execution revoked for internal helper RPCs:
  - `axon_issue_session(text)`
  - `axon_assert_session(text, text)`
  - `axon_init_free_miner_account(text)`
  - `axon_init_plan_claim_account(text, uuid, text, numeric)`
- only guarded public RPCs are exposed for browser workflows

### SQL package

Added:
- `supabase_v6_7_admin_patch.sql`
- `supabase_v6_7_full.sql`

Use `supabase_v6_7_full.sql` for deployment because it includes V6.5 + V6.6 + V6.7 in one file.

## Public routes

- `/index.html` — landing page
- `/signup.html` — account creation
- `/login.html` — login
- `/onboarding.html` — onboarding flow
- `/dashboard.html` — user dashboard, plans, claims, withdrawals, referrals
- `/payment.html` — paid-plan proof submission
- `/admin.html` — private operations console

## Admin setup command

```sql
select public.axon_admin_set_key('REPLACE_WITH_A_LONG_PRIVATE_ADMIN_KEY');
```

## Operational model

1. User signs up or logs in.
2. User claims FREE NFT daily claim or submits paid-plan proof.
3. Admin reviews payment proof in `/admin.html`.
4. Approval activates the user plan and creates the paid plan claim account.
5. User requests withdrawal after available balance meets the minimum.
6. Admin processes withdrawal manually and marks the request status.

## Compliance note

The V6.7 interface includes disclosure copy to avoid representing claim schedules as guaranteed investment advice. The operator should still obtain proper legal, finance, tax, and consumer-protection review before public launch.

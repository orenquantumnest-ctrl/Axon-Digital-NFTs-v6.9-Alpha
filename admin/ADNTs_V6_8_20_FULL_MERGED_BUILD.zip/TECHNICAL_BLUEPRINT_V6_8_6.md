# AXON DIGITAL NFTs V6.8.6 Technical Blueprint

V6.8.6 replaces the earlier private-admin-key browser flow with a wallet/password admin login.

## Browser security posture
- Browser config uses only the Supabase publishable/anon key.
- Service-role/secret keys are not placed in frontend files.
- Admin password is not placed in frontend files.
- Supabase stores a bcrypt hash via `extensions.crypt()`.
- Login RPC returns a temporary admin session token stored in localStorage/sessionStorage/cookie for browser continuity.

## Admin identity
Official admin wallet: `0x7bbc456C2C34972723cF03b9D44323d2539514dE`

## Main RPCs
- `axon_admin_set_wallet_account(wallet, password, display_name)`
- `axon_admin_wallet_login(wallet, password)`
- `axon_admin_wallet_auth_health()`
- Existing `axon_admin_get_console(session_token)` remains the live-data console source.

## Frontend files changed
- `admin.html`
- `js/admin.js`
- `js/v68-admin-pages.js`
- `js/config.js`
- `js/supabase-config.js`
- `payment.html` wallet display corrected to match the active official wallet.

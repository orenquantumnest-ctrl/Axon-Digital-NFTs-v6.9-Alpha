# AXON DIGITAL NFTs V6.8.8 Technical Blueprint

V6.8.8 is a hybrid admin-interface correction release. It preserves the current user-facing frontend and backend wiring from V6.8.7, while replacing only the admin interface layer with a V6.7-style operations console.

## Admin Runtime
- `js/v688-admin-classic.js` loads all admin data through `axon_admin_get_console`.
- Uses `p_admin_session_token`.
- Session token is stored using localStorage + sessionStorage + SameSite cookie.
- Falls back from Supabase JS RPC to direct REST RPC where needed.

## Admin Pages
- `admin.html`: wallet/password login.
- `admin-dashboard.html`: V6.7-style live control center.
- `admin-users.html`: derived live wallet/user intelligence.
- `admin-deposits.html`: payment proof review.
- `admin-withdrawals.html`: payout processing.
- `admin-plans.html`: plan catalog editor + user plan accounts.

## User Side
No user page redesign was applied in this release.

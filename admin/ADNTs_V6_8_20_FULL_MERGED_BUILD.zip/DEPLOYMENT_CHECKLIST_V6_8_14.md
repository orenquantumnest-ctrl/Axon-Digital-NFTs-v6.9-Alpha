# AXON DIGITAL NFTs V6.8.14 Deployment Checklist

1. Upload contents of build_v6814/ to axondigitalnfts.com and axonprime-vault.netlify.app roots.
2. Run supabase_v6_8_14_payment_approval_activation_patch.sql in Supabase SQL Editor.
3. Login to admin.
4. Open admin-deposits.html?fresh=6814.
5. Approve a pending payment.
6. Confirm the user transaction changes from pending to approved/completed.
7. Confirm user_plans and plan_claim_accounts are active.
8. Test mobile layout on transactions.html and admin-deposits.html.

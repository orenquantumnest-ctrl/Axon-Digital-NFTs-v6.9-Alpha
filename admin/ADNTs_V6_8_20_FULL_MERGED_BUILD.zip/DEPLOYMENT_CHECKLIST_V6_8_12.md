# AXON DIGITAL NFTs V6.8.12 Deployment Checklist

1. Upload the contents of `build_v6812/` to both production roots.
2. Confirm JS files sit inside `/js/` on both domains.
3. Run `supabase_v6_8_12_admin_credentials_patch_DO_NOT_UPLOAD.sql` in Supabase SQL Editor only.
4. Open `/admin.html?fresh=6812`.
5. Login with mode `super`, wallet `0x7bbc456c2c34972723cf03b9d44323d2539514de`, and the issued password.
6. Open `/admin-dashboard.html?fresh=6812`.
7. Check the live data probe in console/details if metrics remain zero.

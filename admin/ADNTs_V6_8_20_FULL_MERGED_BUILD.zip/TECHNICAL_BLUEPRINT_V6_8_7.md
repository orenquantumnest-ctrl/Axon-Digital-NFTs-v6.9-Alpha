# AXON DIGITAL NFTs V6.8.7 Technical Blueprint

## Root Cause
The admin dashboard was loading its UI shell, but the data cards were not reliably bound to the real production schema. The schema contains real tables such as `users`, `payment_submissions`, `withdrawal_requests`, `transactions`, `user_plans`, `plan_claim_accounts`, and duplicate admin systems (`admin_sessions` and `axon_admin_sessions`). Earlier admin RPCs could validate against only one session family or return data in shapes not fully aligned to the supplied schema.

## Resolution
V6.8.7 introduces a schema-aligned bridge:

- `axon_admin_assert_session(text)` validates both current and legacy admin session tables.
- `axon_admin_user_index()` derives wallets from every wallet-bearing table.
- `axon_backfill_users_from_live_activity()` safely fills missing `users` rows.
- `axon_admin_live_data_probe()` reports exact table counts.
- `axon_admin_get_console(text)` returns normalized data for all admin pages.
- `axon_admin_schema_bridge_health()` confirms the live bridge state.

## Security
Frontend uses Supabase URL and anon/publishable key only. The service role key is never embedded in browser files. Admin access remains gated by wallet/password login and Supabase-side hashed password storage.

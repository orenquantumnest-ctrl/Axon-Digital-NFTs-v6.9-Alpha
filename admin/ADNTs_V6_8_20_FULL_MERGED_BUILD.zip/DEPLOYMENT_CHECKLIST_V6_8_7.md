# AXON DIGITAL NFTs V6.8.7 Deployment Checklist

## Purpose
V6.8.7 aligns the admin console RPC with the real production schema supplied by the project owner. It keeps wallet/password admin login and removes dependency on the old private admin key flow.

## Upload
Upload the extracted V6.8.7 website contents to both:

- axondigitalnfts.com
- axonprime-vault.netlify.app

Files must sit at the hosting root, not inside an extra folder.

## Supabase SQL
Run after V6.8.6 SQL:

1. `supabase_v6_8_7_schema_aligned_admin_console_patch.sql`

## Verify in Supabase
Run:

```sql
select public.axon_admin_schema_bridge_health();
select public.axon_admin_live_data_probe();
```

The probe should show non-zero `public_users` or `derived_live_wallets` when records exist.

## Verify in browser
Open:

- `/admin.html?fresh=687`
- `/admin-dashboard.html?fresh=687`
- `/admin-users.html?fresh=687`
- `/admin-deposits.html?fresh=687`
- `/admin-withdrawals.html?fresh=687`

Login with the admin wallet and password. The admin cards should display live counts.

# V6.8.11 Technical Blueprint

V6.8.11 introduces new versioned RPC endpoints:

- `axon_admin_login_v6811`
- `axon_admin_get_console_v6811`
- `axon_admin_schema_bridge_health_v6811`
- `axon_admin_live_data_probe_v6811`

Compatibility wrappers are also created for older frontend calls:

- `axon_admin_login_v689`
- `axon_admin_wallet_login`
- `axon_admin_get_console`

The admin console reads from the supplied live schema tables and returns a normalized JSON payload for `js/admin-dashboard.js`.

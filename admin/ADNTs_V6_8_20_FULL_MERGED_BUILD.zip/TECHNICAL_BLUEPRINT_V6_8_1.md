# AXON DIGITAL NFTs V6.8.1 Technical Blueprint

V6.8.1 is a non-destructive responsive UI patch over V6.8. It preserves the standalone page model and Supabase RPC assumptions.

## Added
- `js/v681-responsive-nav.js`
- V6.8.1 responsive navigation rules in `css/v68-liquid-glass.css`
- Mobile glass drawer menu for user/admin standalone pages
- Desktop horizontal-safe navigation behavior
- Smaller brand footprint on phones
- Stronger translucent glass optics and specular card highlights
- Safer mobile cards, lists, buttons, and metric stacking

## Security note
Admin private keys are intentionally not embedded into `admin.html`. Browser HTML is public and can be viewed by any visitor. `admin.html` includes a non-secret build hash marker instead. The actual admin key must remain configured through Supabase using the server-side admin-key function.

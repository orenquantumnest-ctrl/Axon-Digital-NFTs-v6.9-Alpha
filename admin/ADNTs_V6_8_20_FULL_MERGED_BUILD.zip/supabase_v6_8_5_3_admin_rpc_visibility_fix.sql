-- AXON DIGITAL NFTs V6.8.5.3 ADMIN RPC VISIBILITY FIX
-- Purpose:
--   Complements the frontend Safari-safe RPC patch by ensuring the browser anon role
--   can execute the guarded admin RPC functions. Does not expose service-role keys.
--   Does not delete or reset data.

create extension if not exists pgcrypto with schema extensions;

grant usage on schema public to anon, authenticated;

do $$
begin
  if to_regprocedure('public.axon_admin_login(text)') is not null then
    execute 'grant execute on function public.axon_admin_login(text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_get_console(text)') is not null then
    execute 'grant execute on function public.axon_admin_get_console(text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_live_data_probe()') is not null then
    execute 'grant execute on function public.axon_admin_live_data_probe() to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_backfill_users_from_live_activity()') is not null then
    execute 'grant execute on function public.axon_backfill_users_from_live_activity() to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_get_plan_catalog(text)') is not null then
    execute 'grant execute on function public.axon_admin_get_plan_catalog(text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text)') is not null then
    execute 'grant execute on function public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_set_plan_catalog_visibility(text,text,boolean)') is not null then
    execute 'grant execute on function public.axon_admin_set_plan_catalog_visibility(text,text,boolean) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_set_plan_catalog_status(text,text,text)') is not null then
    execute 'grant execute on function public.axon_admin_set_plan_catalog_status(text,text,text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_delete_plan_catalog(text,text)') is not null then
    execute 'grant execute on function public.axon_admin_delete_plan_catalog(text,text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_update_payment_status(text,uuid,text,text)') is not null then
    execute 'grant execute on function public.axon_admin_update_payment_status(text,uuid,text,text) to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_update_withdrawal_status(text,uuid,text,text)') is not null then
    execute 'grant execute on function public.axon_admin_update_withdrawal_status(text,uuid,text,text) to anon, authenticated';
  end if;
end $$;

create or replace function public.axon_admin_browser_rpc_health()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_probe jsonb := '{}'::jsonb;
begin
  if to_regprocedure('public.axon_admin_live_data_probe()') is not null then
    v_probe := public.axon_admin_live_data_probe();
  end if;

  return jsonb_build_object(
    'ok', true,
    'build', 'V6.8.5.3',
    'message', 'Admin browser RPC visibility checked. If frontend still shows zero, confirm both domains use this same Supabase project and valid admin session token.',
    'functions', jsonb_build_object(
      'axon_admin_login', to_regprocedure('public.axon_admin_login(text)') is not null,
      'axon_admin_get_console', to_regprocedure('public.axon_admin_get_console(text)') is not null,
      'axon_admin_live_data_probe', to_regprocedure('public.axon_admin_live_data_probe()') is not null,
      'axon_admin_get_plan_catalog', to_regprocedure('public.axon_admin_get_plan_catalog(text)') is not null
    ),
    'probe', v_probe,
    'generated_at', now()
  );
end;
$$;

revoke all on function public.axon_admin_browser_rpc_health() from public;
grant execute on function public.axon_admin_browser_rpc_health() to anon, authenticated;

select public.axon_admin_browser_rpc_health() as axon_v6853_admin_rpc_health;

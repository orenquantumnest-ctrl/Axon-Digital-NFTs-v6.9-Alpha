# AXON DIGITAL NFTs V6.8.6 Deployment Checklist

## What changed
- Admin login no longer uses the old private admin key input.
- Admin login now uses the official deposit wallet address plus a Supabase-hashed admin password.
- Admin pages include inline wallet/password login when the page has no session.
- Both `axondigitalnfts.com` and `axonprime-vault.netlify.app` must use the same `js/config.js` Supabase URL and publishable/anon key.

## Admin wallet
`0x7bbc456C2C34972723cF03b9D44323d2539514dE`

## Deployment
1. Upload the extracted V6.8.6 frontend files to both domains.
2. Run `supabase_v6_8_5_admin_console_live_data_patch.sql` if not already run.
3. Run `supabase_v6_8_5_1_admin_live_data_backfill_patch.sql` if not already run.
4. Run `supabase_v6_8_5_3_admin_rpc_visibility_fix.sql` if not already run.
5. Run `supabase_v6_8_6_admin_wallet_login_patch.sql`.
6. Run the separate one-time setup SQL named `supabase_v6_8_6_ADMIN_WALLET_SETUP_DO_NOT_UPLOAD.sql`. Do not upload that file to public hosting.
7. Open `/admin.html?fresh=686`, enter wallet and password, then open `/admin-dashboard.html?fresh=686`.
8. Check `/admin-users.html?fresh=686`, `/admin-deposits.html?fresh=686`, `/admin-withdrawals.html?fresh=686`, `/admin-plans.html?fresh=686`.

## Build
V6.8.6 · Hash `92d5599080a5676fe7a3bd5e6e4b12a23625686c62551e7c91cfadc448f951d0`

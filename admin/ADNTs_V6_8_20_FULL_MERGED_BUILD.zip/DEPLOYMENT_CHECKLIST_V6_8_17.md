# AXON DIGITAL NFTs V6.8.17 Deployment Checklist

## Upload
Upload the contents of `build_v6817/` directly to the website root on both domains:

- `axondigitalnfts.com`
- `axonprime-vault.netlify.app`

Do not upload the folder itself.

## Required files added/changed

- `js/v68-admin-pages.js`
- `css/v6817-admin-interactions.css`
- all `admin*.html` pages updated to load the V6.8.17 cache-busted CSS/JS chain

## SQL
No new SQL is required for V6.8.17. Keep V6.8.16 admin action/list SQL installed.

## Test

Open with cache bypass:

- `/admin-dashboard.html?fresh=6817`
- `/admin-deposits.html?fresh=6817`
- `/admin-withdrawals.html?fresh=6817`
- `/admin-users.html?fresh=6817`
- `/admin-transactions.html?fresh=6817`

## Expected behavior

- List pages show a live search bar.
- Typing in search shows suggestions before submit.
- Deposit/withdrawal records show status pill + Change button.
- Change opens a modal with single-select status options.
- Continue updates Supabase through the existing RPC.
- Success modal appears; OK reloads the page.

Build hash: `5539cc5b0c6be64c1d91c60a702a07929b5266c0694091893dcd722ed3540158`

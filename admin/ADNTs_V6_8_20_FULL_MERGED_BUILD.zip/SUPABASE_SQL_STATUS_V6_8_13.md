# Supabase SQL Status for V6.8.13

V6.8.13 is an admin UI/page-shell build. It does not require a new destructive migration.

Keep these already-fixed patches available for the current admin wallet/password system:

1. `supabase_v6_8_12_role_safe_admin_login_console_patch.sql`
2. `supabase_v6_8_12_pgcrypto_crypt_login_fix_DO_NOT_UPLOAD.sql`

Run them only if the target Supabase project has not already received them.

The health result already confirmed:

- `axon_admin_get_console_exists = true`
- `axon_admin_login_v6811_exists = true`
- live data probe includes users, transactions, withdrawals, payments, referrals, miners, and plans.

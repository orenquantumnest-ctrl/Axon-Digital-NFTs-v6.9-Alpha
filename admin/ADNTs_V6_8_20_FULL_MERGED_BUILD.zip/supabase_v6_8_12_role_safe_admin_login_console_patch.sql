-- AXON DIGITAL NFTs V6.8.12 ROLE-SAFE ADMIN LOGIN + CONSOLE PATCH
-- Purpose:
-- 1) Fix admin_accounts_role_check failure by avoiding unsafe writes into admin_accounts.role.
-- 2) Restore exact browser-called RPC: public.axon_admin_login_v6811(p_mode, p_pin, p_username, p_wallet_address).
-- 3) Seed the requested super-admin wallet/password in axon_admin_wallet_accounts only.
-- 4) Create a schema-aligned public.axon_admin_get_console(p_admin_session_token) RPC that reads live production tables.
-- Run ONLY inside Supabase SQL Editor. Do NOT upload this SQL file to Netlify/cPanel/public hosting.

create extension if not exists pgcrypto;

create table if not exists public.axon_admin_wallet_accounts (
  id uuid primary key default gen_random_uuid(),
  wallet_address text unique not null,
  password_hash text not null,
  display_name text not null default 'AXON Super Admin',
  role text not null default 'super',
  status text not null default 'active',
  last_login_at timestamptz null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.axon_admin_sessions (
  id uuid primary key default gen_random_uuid(),
  admin_session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_sessions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null,
  session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid null,
  action_name text not null,
  entity_type text null,
  entity_id text null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Seed/update super-admin wallet credentials in the role-safe wallet-admin table.
-- This intentionally avoids writing role='super' into public.admin_accounts because your live table has admin_accounts_role_check.
do $$
declare
  v_wallet constant text := '0x7bbc456c2c34972723cf03b9d44323d2539514de';
  v_password constant text := 'Cx4!nX9pQ2mL7r';
begin
  insert into public.axon_admin_wallet_accounts (
    wallet_address,
    password_hash,
    display_name,
    role,
    status,
    created_at,
    updated_at
  ) values (
    lower(v_wallet),
    crypt(v_password, gen_salt('bf')),
    'AXON Super Admin',
    'super',
    'active',
    now(),
    now()
  )
  on conflict (wallet_address) do update
  set
    password_hash = excluded.password_hash,
    display_name = excluded.display_name,
    role = excluded.role,
    status = 'active',
    updated_at = now();
end $$;

-- Drop stale versions with the exact browser signature, then recreate.
drop function if exists public.axon_admin_login_v6811(text, text, text, text);
drop function if exists public.axon_admin_login_v689(text, text, text, text);
drop function if exists public.axon_admin_wallet_login(text, text);
drop function if exists public.axon_admin_assert_session_v6811(text);
drop function if exists public.axon_admin_get_console(text);
drop function if exists public.axon_admin_get_console_v6811(text);
drop function if exists public.axon_admin_live_data_probe_v6812();
drop function if exists public.axon_admin_login_v6812_health();

create or replace function public.axon_admin_login_v6811(
  p_mode text,
  p_pin text,
  p_username text,
  p_wallet_address text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_mode text := lower(coalesce(p_mode, 'super'));
  v_wallet text := lower(trim(coalesce(p_wallet_address, '')));
  v_username text := lower(trim(coalesce(p_username, '')));
  v_password text := coalesce(p_pin, '');
  v_wallet_admin public.axon_admin_wallet_accounts%rowtype;
  v_admin_id uuid;
  v_admin_role text := 'super';
  v_display_name text := 'AXON Super Admin';
  v_permission_bundle jsonb := jsonb_build_object(
    'users', true,
    'payments', true,
    'withdrawals', true,
    'plans', true,
    'admins', true,
    'audit', true,
    'settings', true,
    'super', true
  );
  v_token text;
  v_expires_at timestamptz := now() + interval '12 hours';
  v_sub_admin record;
begin
  if v_password = '' then
    return jsonb_build_object('ok', false, 'message', 'Admin password/PIN is required.');
  end if;

  if v_mode = 'sub' then
    if v_username = '' then
      return jsonb_build_object('ok', false, 'message', 'Sub-admin username is required.');
    end if;

    select id, role, username, wallet_address, pin_hash, display_name, permission_bundle
    into v_sub_admin
    from public.admin_accounts
    where is_active = true
      and lower(coalesce(username, '')) = v_username
    order by updated_at desc nulls last, created_at desc nulls last
    limit 1;

    if v_sub_admin.id is null then
      return jsonb_build_object('ok', false, 'message', 'Sub-admin account not found.');
    end if;

    if v_sub_admin.pin_hash is null or v_sub_admin.pin_hash <> crypt(v_password, v_sub_admin.pin_hash) then
      return jsonb_build_object('ok', false, 'message', 'Invalid sub-admin credentials.');
    end if;

    v_admin_id := v_sub_admin.id;
    v_admin_role := coalesce(v_sub_admin.role, 'sub');
    v_display_name := coalesce(v_sub_admin.display_name, v_sub_admin.username, 'AXON Sub Admin');
    v_permission_bundle := coalesce(v_sub_admin.permission_bundle, '{}'::jsonb);

    update public.admin_accounts
    set last_login_at = now(), updated_at = now()
    where id = v_admin_id;
  else
    if v_wallet = '' then
      return jsonb_build_object('ok', false, 'message', 'Super-admin wallet address is required.');
    end if;

    select * into v_wallet_admin
    from public.axon_admin_wallet_accounts
    where lower(wallet_address) = v_wallet
      and lower(status) = 'active'
    limit 1;

    if v_wallet_admin.id is null then
      return jsonb_build_object('ok', false, 'message', 'Admin wallet is not configured. Run the role-safe V6.8.12 patch.');
    end if;

    if v_wallet_admin.password_hash is null or v_wallet_admin.password_hash <> crypt(v_password, v_wallet_admin.password_hash) then
      return jsonb_build_object('ok', false, 'message', 'Invalid admin credentials.');
    end if;

    v_admin_id := v_wallet_admin.id;
    v_admin_role := coalesce(v_wallet_admin.role, 'super');
    v_display_name := coalesce(v_wallet_admin.display_name, 'AXON Super Admin');

    update public.axon_admin_wallet_accounts
    set last_login_at = now(), updated_at = now()
    where id = v_wallet_admin.id;
  end if;

  v_token := 'axadm_' || replace(gen_random_uuid()::text, '-', '') || '_' || encode(gen_random_bytes(18), 'hex');

  insert into public.axon_admin_sessions (admin_session_token, expires_at, created_at)
  values (v_token, v_expires_at, now());

  -- Insert into legacy admin_sessions too. There is usually no FK on admin_id in this schema.
  -- If a future project adds a strict FK, axon_admin_sessions still remains the authoritative session source.
  begin
    insert into public.admin_sessions (admin_id, session_token, expires_at, created_at)
    values (v_admin_id, v_token, v_expires_at, now());
  exception when others then
    null;
  end;

  begin
    insert into public.admin_audit_logs (admin_id, action_name, entity_type, entity_id, details, created_at)
    values (
      v_admin_id,
      'admin_login_v6811_role_safe',
      'admin_session',
      v_admin_id::text,
      jsonb_build_object('mode', v_mode, 'wallet_address', v_wallet, 'username', v_username),
      now()
    );
  exception when others then
    null;
  end;

  return jsonb_build_object(
    'ok', true,
    'message', 'Admin login successful.',
    'admin_session_token', v_token,
    'session_token', v_token,
    'expires_at', v_expires_at,
    'admin_id', v_admin_id,
    'role', v_admin_role,
    'display_name', v_display_name,
    'wallet_address', nullif(v_wallet, ''),
    'username', nullif(v_username, ''),
    'permission_bundle', v_permission_bundle
  );
end;
$$;

create or replace function public.axon_admin_login_v689(
  p_mode text,
  p_pin text,
  p_username text,
  p_wallet_address text
)
returns jsonb
language sql
security definer
set search_path = public, pg_temp
as $$
  select public.axon_admin_login_v6811(p_mode, p_pin, p_username, p_wallet_address);
$$;

create or replace function public.axon_admin_wallet_login(
  p_wallet_address text,
  p_password text
)
returns jsonb
language sql
security definer
set search_path = public, pg_temp
as $$
  select public.axon_admin_login_v6811('super', p_password, null, p_wallet_address);
$$;

create or replace function public.axon_admin_assert_session_v6811(
  p_admin_session_token text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_expires timestamptz;
  v_admin_id uuid;
begin
  if coalesce(p_admin_session_token, '') = '' then
    return jsonb_build_object('ok', false, 'valid', false, 'message', 'Missing admin session token.');
  end if;

  select expires_at into v_expires
  from public.axon_admin_sessions
  where admin_session_token = p_admin_session_token
    and revoked_at is null
    and expires_at > now()
  limit 1;

  if v_expires is not null then
    return jsonb_build_object('ok', true, 'valid', true, 'session_expires_at', v_expires);
  end if;

  select admin_id, expires_at into v_admin_id, v_expires
  from public.admin_sessions
  where session_token = p_admin_session_token
    and revoked_at is null
    and expires_at > now()
  limit 1;

  if v_expires is not null then
    return jsonb_build_object('ok', true, 'valid', true, 'admin_id', v_admin_id, 'session_expires_at', v_expires);
  end if;

  return jsonb_build_object('ok', false, 'valid', false, 'message', 'Admin session is invalid or expired.');
end;
$$;

create or replace function public.axon_admin_live_data_probe_v6812()
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_public_users int := 0;
  v_user_sessions int := 0;
  v_payment_total int := 0;
  v_payment_pending int := 0;
  v_withdrawal_total int := 0;
  v_withdrawal_pending int := 0;
  v_transactions int := 0;
  v_user_plans int := 0;
  v_user_plans_active int := 0;
  v_plan_claim_accounts int := 0;
  v_plan_claim_accounts_active int := 0;
  v_plan_claim_history int := 0;
  v_free_miner_accounts int := 0;
  v_free_miner_claims int := 0;
  v_referrals int := 0;
  v_referral_visits int := 0;
  v_axon_plan_catalog int := 0;
  v_legacy_plan_catalog int := 0;
  v_derived_live_wallets int := 0;
begin
  select count(*) into v_public_users from public.users;
  select count(*) into v_user_sessions from public.user_sessions;
  select count(*) into v_payment_total from public.payment_submissions;
  select count(*) into v_payment_pending from public.payment_submissions where lower(coalesce(status, '')) in ('pending', 'processing', 'submitted');
  select count(*) into v_withdrawal_total from public.withdrawal_requests;
  select count(*) into v_withdrawal_pending from public.withdrawal_requests where lower(coalesce(status, '')) in ('pending', 'processing');
  select count(*) into v_transactions from public.transactions;
  select count(*) into v_user_plans from public.user_plans;
  select count(*) into v_user_plans_active from public.user_plans where lower(coalesce(status, '')) = 'active';
  select count(*) into v_plan_claim_accounts from public.plan_claim_accounts;
  select count(*) into v_plan_claim_accounts_active from public.plan_claim_accounts where lower(coalesce(status, '')) = 'active';
  select count(*) into v_plan_claim_history from public.plan_claim_history;
  select count(*) into v_free_miner_accounts from public.free_miner_accounts;
  select count(*) into v_free_miner_claims from public.free_miner_claims;
  select count(*) into v_referrals from public.referrals;
  select count(*) into v_referral_visits from public.referral_visits;
  select count(*) into v_axon_plan_catalog from public.axon_plan_catalog where deleted_at is null;
  select count(*) into v_legacy_plan_catalog from public.plan_catalog;

  select count(distinct wallet_address) into v_derived_live_wallets
  from (
    select wallet_address from public.users where wallet_address is not null
    union all select wallet_address from public.user_sessions where wallet_address is not null
    union all select wallet_address from public.payment_submissions where wallet_address is not null
    union all select wallet_address from public.withdrawal_requests where wallet_address is not null
    union all select wallet_address from public.transactions where wallet_address is not null
    union all select wallet_address from public.user_plans where wallet_address is not null
    union all select wallet_address from public.plan_claim_accounts where wallet_address is not null
    union all select wallet_address from public.plan_claim_history where wallet_address is not null
    union all select wallet_address from public.free_miner_accounts where wallet_address is not null
    union all select wallet_address from public.free_miner_claims where wallet_address is not null
    union all select referrer_wallet as wallet_address from public.referrals where referrer_wallet is not null
    union all select referred_wallet as wallet_address from public.referrals where referred_wallet is not null
    union all select referrer_wallet as wallet_address from public.referral_visits where referrer_wallet is not null
  ) live_wallets;

  return jsonb_build_object(
    'public_users', v_public_users,
    'derived_live_wallets', v_derived_live_wallets,
    'user_sessions', v_user_sessions,
    'payment_submissions', v_payment_total,
    'payment_pending', v_payment_pending,
    'withdrawal_requests', v_withdrawal_total,
    'withdrawal_pending', v_withdrawal_pending,
    'transactions', v_transactions,
    'user_plans', v_user_plans,
    'user_plans_active', v_user_plans_active,
    'plan_claim_accounts', v_plan_claim_accounts,
    'plan_claim_accounts_active', v_plan_claim_accounts_active,
    'plan_claim_history', v_plan_claim_history,
    'free_miner_accounts', v_free_miner_accounts,
    'free_miner_claims', v_free_miner_claims,
    'referrals', v_referrals,
    'referral_visits', v_referral_visits,
    'axon_plan_catalog', v_axon_plan_catalog,
    'legacy_plan_catalog', v_legacy_plan_catalog
  );
end;
$$;

create or replace function public.axon_admin_get_console(
  p_admin_session_token text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_session jsonb;
  v_probe jsonb;
  v_users jsonb := '[]'::jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_plan_accounts jsonb := '[]'::jsonb;
  v_free_miner_accounts jsonb := '[]'::jsonb;
  v_plan_catalog jsonb := '[]'::jsonb;
  v_audit_logs jsonb := '[]'::jsonb;
  v_system_events jsonb := '[]'::jsonb;
  v_session_expires_at text;
begin
  v_session := public.axon_admin_assert_session_v6811(p_admin_session_token);
  if coalesce((v_session ->> 'valid')::boolean, false) is not true then
    return jsonb_build_object('ok', false, 'message', coalesce(v_session ->> 'message', 'Admin session invalid.'), 'data_probe', public.axon_admin_live_data_probe_v6812());
  end if;

  v_session_expires_at := v_session ->> 'session_expires_at';
  v_probe := public.axon_admin_live_data_probe_v6812();

  select coalesce(jsonb_agg(to_jsonb(u) order by u.created_at desc), '[]'::jsonb) into v_users
  from (select id, wallet_address, referral_code, referred_by, created_at, password_hash from public.users order by created_at desc limit 100) u;

  select coalesce(jsonb_agg(to_jsonb(p) order by p.created_at desc), '[]'::jsonb) into v_payments
  from (select * from public.payment_submissions order by created_at desc limit 100) p;

  select coalesce(jsonb_agg(to_jsonb(w) order by w.created_at desc), '[]'::jsonb) into v_withdrawals
  from (select * from public.withdrawal_requests order by created_at desc limit 100) w;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb) into v_transactions
  from (select * from public.transactions order by created_at desc limit 100) t;

  select coalesce(jsonb_agg(to_jsonb(pa) order by pa.created_at desc), '[]'::jsonb) into v_plan_accounts
  from (select * from public.plan_claim_accounts order by created_at desc limit 100) pa;

  select coalesce(jsonb_agg(to_jsonb(fm) order by fm.created_at desc), '[]'::jsonb) into v_free_miner_accounts
  from (select * from public.free_miner_accounts order by created_at desc limit 100) fm;

  select coalesce(jsonb_agg(to_jsonb(pc) order by pc.sort_order asc, pc.created_at desc), '[]'::jsonb) into v_plan_catalog
  from (select * from public.axon_plan_catalog where deleted_at is null order by sort_order asc, created_at desc limit 100) pc;

  select coalesce(jsonb_agg(to_jsonb(al) order by al.created_at desc), '[]'::jsonb) into v_audit_logs
  from (
    select id, admin_id::text as admin_id, action_name as action, entity_type as target_table, entity_id as target_id, details, created_at from public.admin_audit_logs
    union all
    select id, admin_session_id::text as admin_id, action, target_table, target_id::text as target_id, jsonb_build_object('status', status, 'note', note) as details, created_at from public.axon_admin_audit_log
    order by created_at desc
    limit 100
  ) al;

  select coalesce(jsonb_agg(to_jsonb(se) order by se.created_at desc), '[]'::jsonb) into v_system_events
  from (select * from public.axon_system_events order by created_at desc limit 100) se;

  return jsonb_build_object(
    'ok', true,
    'session_expires_at', v_session_expires_at,
    'data_probe', v_probe,
    'stats', jsonb_build_object(
      'users_count', coalesce((v_probe ->> 'public_users')::int, 0),
      'total_users', coalesce((v_probe ->> 'derived_live_wallets')::int, 0),
      'active_plans_count', coalesce((v_probe ->> 'user_plans_active')::int, 0),
      'pending_payments_count', coalesce((v_probe ->> 'payment_pending')::int, 0),
      'pending_deposits', coalesce((v_probe ->> 'payment_pending')::int, 0),
      'pending_withdrawals_count', coalesce((v_probe ->> 'withdrawal_pending')::int, 0),
      'pending_withdrawals', coalesce((v_probe ->> 'withdrawal_pending')::int, 0),
      'transactions_count', coalesce((v_probe ->> 'transactions')::int, 0),
      'transactions', coalesce((v_probe ->> 'transactions')::int, 0),
      'catalog_count', coalesce((v_probe ->> 'axon_plan_catalog')::int, 0),
      'catalog_plans', coalesce((v_probe ->> 'axon_plan_catalog')::int, 0),
      'claim_accounts_count', coalesce((v_probe ->> 'plan_claim_accounts_active')::int, 0),
      'free_miner_count', coalesce((v_probe ->> 'free_miner_accounts')::int, 0),
      'total_claim_earnings', 0,
      'reserved_withdrawals', 0
    ),
    'users', v_users,
    'payments', v_payments,
    'deposits', v_payments,
    'payment_submissions', v_payments,
    'withdrawals', v_withdrawals,
    'withdrawal_requests', v_withdrawals,
    'transactions_list', v_transactions,
    'recent_transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'active_plans', v_plan_accounts,
    'free_miner_accounts', v_free_miner_accounts,
    'audit_logs', v_audit_logs,
    'logs', v_audit_logs,
    'system_events', v_system_events,
    'events', v_system_events,
    'plan_catalog', v_plan_catalog,
    'catalog', v_plan_catalog
  );
end;
$$;

create or replace function public.axon_admin_get_console_v6811(
  p_admin_session_token text
)
returns jsonb
language sql
security definer
set search_path = public, pg_temp
as $$
  select public.axon_admin_get_console(p_admin_session_token);
$$;

create or replace function public.axon_admin_login_v6812_health()
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_wallet text := '0x7bbc456c2c34972723cf03b9d44323d2539514de';
  v_login_exists boolean;
  v_console_exists boolean;
  v_wallet_accounts int;
  v_role_constraint text;
begin
  select exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.proname = 'axon_admin_login_v6811'
  ) into v_login_exists;

  select exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.proname = 'axon_admin_get_console'
  ) into v_console_exists;

  select count(*) into v_wallet_accounts
  from public.axon_admin_wallet_accounts
  where lower(wallet_address) = lower(v_wallet);

  select pg_get_constraintdef(c.oid) into v_role_constraint
  from pg_constraint c
  join pg_class t on t.oid = c.conrelid
  join pg_namespace n on n.oid = t.relnamespace
  where n.nspname = 'public'
    and t.relname = 'admin_accounts'
    and c.conname = 'admin_accounts_role_check'
  limit 1;

  return jsonb_build_object(
    'ok', true,
    'axon_admin_login_v6811_exists', v_login_exists,
    'axon_admin_get_console_exists', v_console_exists,
    'axon_admin_wallet_accounts_for_wallet', v_wallet_accounts,
    'admin_accounts_role_check', coalesce(v_role_constraint, 'not_found'),
    'data_probe', public.axon_admin_live_data_probe_v6812()
  );
end;
$$;

grant execute on function public.axon_admin_login_v6811(text, text, text, text) to anon, authenticated;
grant execute on function public.axon_admin_login_v689(text, text, text, text) to anon, authenticated;
grant execute on function public.axon_admin_wallet_login(text, text) to anon, authenticated;
grant execute on function public.axon_admin_assert_session_v6811(text) to anon, authenticated;
grant execute on function public.axon_admin_live_data_probe_v6812() to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;
grant execute on function public.axon_admin_get_console_v6811(text) to anon, authenticated;
grant execute on function public.axon_admin_login_v6812_health() to anon, authenticated;

select pg_notify('pgrst', 'reload schema');

select public.axon_admin_login_v6812_health();

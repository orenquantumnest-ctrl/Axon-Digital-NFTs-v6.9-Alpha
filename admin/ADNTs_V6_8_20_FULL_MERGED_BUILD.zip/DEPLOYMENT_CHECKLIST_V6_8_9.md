# AXON DIGITAL NFTs V6.8.9 Deployment Checklist

1. Upload this package to both `axondigitalnfts.com` and `axonprime-vault.netlify.app`.
2. Keep the files at the web root, not inside an extra folder.
3. In Supabase SQL Editor, run `supabase_v6_8_9_admin_uploaded_pages_bridge.sql` after the V6.8.6 and V6.8.7 patches.
4. Open `/admin.html?fresh=689`.
5. Login as super-admin using the official admin wallet plus the configured admin PIN/password.
6. Open `/admin-dashboard.html?fresh=689`.
7. Confirm users, deposits, withdrawals, plans, transactions, and audit logs load.

No private admin key is used by this build.

-- AXON DIGITAL NFTs V6.8.4 Admin Health Check
-- Run in Supabase SQL Editor.
-- This does not expose your private key.

select
  'admin_key_row' as check_name,
  exists(
    select 1 from public.axon_admin_config where key = 'primary_admin_key'
  ) as ok;

select
  'admin_rpc_functions' as check_name,
  p.proname as function_name,
  n.nspname as schema_name
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in (
    'axon_admin_set_key',
    'axon_admin_login',
    'axon_admin_get_console',
    'axon_admin_update_payment_status',
    'axon_admin_update_withdrawal_status',
    'axon_admin_get_plan_catalog',
    'axon_admin_upsert_plan_catalog'
  )
order by p.proname;

select
  'admin_sessions_table' as check_name,
  to_regclass('public.axon_admin_sessions') is not null as ok;

select
  'admin_config_hash_prefix' as check_name,
  key,
  updated_at,
  left(value_hash, 7) as hash_prefix
from public.axon_admin_config
where key = 'primary_admin_key';

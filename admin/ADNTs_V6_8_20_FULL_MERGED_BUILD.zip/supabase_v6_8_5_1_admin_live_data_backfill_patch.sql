-- AXON DIGITAL NFTs V6.8.5.1 ADMIN LIVE DATA BACKFILL + USER INDEX PATCH
-- Purpose:
--   Fix admin pages showing 0 when public.users is empty but live activity exists in
--   payment_submissions, user_plans, transactions, withdrawals, sessions, free miner,
--   paid claim accounts/history, or referrals.
--
-- Safe/idempotent:
--   - Does not delete user data.
--   - Backfills public.users from existing wallet-bearing activity tables.
--   - Rebuilds axon_admin_get_console to read from a derived live user index.
--   - Keeps admin key/session architecture unchanged.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- 1) Live user index helper
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_user_index()
returns table(wallet_address text, created_at timestamptz)
language sql
security definer
set search_path = public, extensions
as $$
  with raw_wallets as (
    select wallet_address::text as wallet_address, created_at::timestamptz as created_at from public.users
    union all select wallet_address::text, created_at::timestamptz from public.user_sessions
    union all select wallet_address::text, created_at::timestamptz from public.payment_submissions
    union all select wallet_address::text, created_at::timestamptz from public.user_plans
    union all select wallet_address::text, created_at::timestamptz from public.transactions
    union all select wallet_address::text, created_at::timestamptz from public.withdrawal_requests
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_accounts
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_claims
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_accounts
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_history
    union all select referrer_wallet::text, created_at::timestamptz from public.referrals
    union all select referred_wallet::text, created_at::timestamptz from public.referrals
  ), cleaned as (
    select public.axon_normalize_wallet(wallet_address) as wallet_address,
           coalesce(created_at, now()) as created_at
    from raw_wallets
    where nullif(trim(coalesce(wallet_address,'')), '') is not null
  )
  select cleaned.wallet_address, min(cleaned.created_at) as created_at
  from cleaned
  where cleaned.wallet_address <> ''
  group by cleaned.wallet_address
  order by min(cleaned.created_at) desc;
$$;

-- -----------------------------------------------------------------------------
-- 2) Backfill public.users from activity tables
-- -----------------------------------------------------------------------------
create or replace function public.axon_backfill_users_from_live_activity()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_before integer := 0;
  v_after integer := 0;
  v_inserted integer := 0;
begin
  select count(*) into v_before from public.users;

  insert into public.users (wallet_address, referral_code, created_at)
  select idx.wallet_address,
         'AX' || upper(substr(md5(idx.wallet_address), 1, 10)) as referral_code,
         coalesce(idx.created_at, now()) as created_at
  from public.axon_admin_user_index() idx
  where idx.wallet_address <> ''
  on conflict (wallet_address) do nothing;

  -- Optional Supabase Auth metadata bridge: only imports wallets stored as wallet metadata.
  -- This block is dynamic so it remains safe if auth.users is unavailable in a given environment.
  if to_regclass('auth.users') is not null then
    execute $authsql$
      insert into public.users (wallet_address, referral_code, created_at)
      select wallet_address,
             'AX' || upper(substr(md5(wallet_address), 1, 10)) as referral_code,
             min(created_at) as created_at
      from (
        select lower(trim(coalesce(raw_user_meta_data->>'wallet_address', raw_user_meta_data->>'wallet', raw_user_meta_data->>'walletAddress', ''))) as wallet_address,
               coalesce(created_at, now()) as created_at
        from auth.users
      ) au
      where wallet_address <> ''
      group by wallet_address
      on conflict (wallet_address) do nothing
    $authsql$;
  end if;

  select count(*) into v_after from public.users;
  v_inserted := greatest(0, v_after - v_before);

  return jsonb_build_object(
    'ok', true,
    'message', 'User index backfill completed.',
    'users_before', v_before,
    'users_after', v_after,
    'inserted', v_inserted,
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index())
  );
end;
$$;

-- Run the safe backfill immediately when this patch is executed.
select public.axon_backfill_users_from_live_activity() as axon_v6851_backfill_result;

-- -----------------------------------------------------------------------------
-- 3) Admin data probe helper
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_live_data_probe()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'public_users', (select count(*) from public.users),
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index()),
    'user_sessions', (select count(*) from public.user_sessions),
    'payment_submissions', (select count(*) from public.payment_submissions),
    'user_plans', (select count(*) from public.user_plans),
    'plan_claim_accounts', (select count(*) from public.plan_claim_accounts),
    'plan_claim_history', (select count(*) from public.plan_claim_history),
    'free_miner_accounts', (select count(*) from public.free_miner_accounts),
    'free_miner_claims', (select count(*) from public.free_miner_claims),
    'transactions', (select count(*) from public.transactions),
    'withdrawal_requests', (select count(*) from public.withdrawal_requests),
    'referrals', (select count(*) from public.referrals),
    'plan_catalog', (select count(*) from public.axon_plan_catalog),
    'admin_config_rows', (select count(*) from public.axon_admin_config),
    'admin_sessions', (select count(*) from public.axon_admin_sessions)
  );
$$;

-- -----------------------------------------------------------------------------
-- 4) Upgrade admin console RPC to read from live user index instead of users only
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_plan_accounts jsonb := '[]'::jsonb;
  v_free_miner_accounts jsonb := '[]'::jsonb;
  v_audit_logs jsonb := '[]'::jsonb;
  v_system_events jsonb := '[]'::jsonb;
  v_plan_catalog jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
  v_active_plans integer := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires
  from public.axon_admin_sessions
  where id = v_session_id;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing');

  select coalesce(count(*),0) into v_active_plans
  from (
    select id::text as key from public.plan_claim_accounts where lower(trim(coalesce(status,''))) = 'active'
    union
    select id::text as key from public.user_plans where lower(trim(coalesce(status,''))) = 'active'
  ) ap;

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.axon_admin_user_index()),
    'public_users_count', (select count(*) from public.users),
    'derived_live_wallets_count', (select count(*) from public.axon_admin_user_index()),
    'active_plans_count', v_active_plans,
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'transactions_count', (select count(*) from public.transactions),
    'catalog_count', (select count(*) from public.axon_plan_catalog where coalesce(status,'active') <> 'deleted'),
    'claim_accounts_count', (select count(*) from public.plan_claim_accounts),
    'free_miner_count', (select count(*) from public.free_miner_accounts),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select idx.wallet_address,
           coalesce(u.id, extensions.gen_random_uuid()) as id,
           coalesce(u.referral_code, 'AX' || upper(substr(md5(idx.wallet_address), 1, 10))) as referral_code,
           u.referred_by,
           coalesce(u.created_at, idx.created_at) as created_at,
           (select count(*) from public.plan_claim_accounts pca where lower(trim(pca.wallet_address)) = idx.wallet_address and lower(trim(coalesce(pca.status,'')))='active')
           +
           (select count(*) from public.user_plans up where lower(trim(up.wallet_address)) = idx.wallet_address and lower(trim(coalesce(up.status,'')))='active') as active_plans_count,
           (select coalesce(sum(amount),0) from public.transactions tx where lower(trim(tx.wallet_address)) = idx.wallet_address and lower(trim(coalesce(tx.status,'completed'))) in ('completed','approved','active')) as available_balance,
           (select count(*) from public.payment_submissions ps where lower(trim(ps.wallet_address)) = idx.wallet_address) as payment_count,
           (select count(*) from public.withdrawal_requests wr where lower(trim(wr.wallet_address)) = idx.wallet_address) as withdrawal_count,
           (select count(*) from public.plan_claim_history pch where lower(trim(pch.wallet_address)) = idx.wallet_address) as paid_claims_count,
           (select count(*) from public.free_miner_claims fmc where lower(trim(fmc.wallet_address)) = idx.wallet_address) as free_claims_count
    from public.axon_admin_user_index() idx
    left join public.users u on lower(trim(u.wallet_address)) = idx.wallet_address
    order by coalesce(u.created_at, idx.created_at) desc
    limit 150
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_transactions
  from (
    select id, wallet_address, type, plan_name, amount, status, source, reference_id, notes, created_at
    from public.transactions
    order by created_at desc
    limit 150
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_accounts
  from (
    select pca.id, pca.wallet_address, pca.user_plan_id, pca.plan_name, pca.plan_price, pca.daily_rate, pca.daily_claim_amount, pca.max_claims, pca.claims_completed, pca.total_claimed, pca.last_claim_at, pca.next_claim_at, pca.status, pca.created_at, pca.updated_at
    from public.plan_claim_accounts pca
    order by case when lower(trim(coalesce(pca.status,'')))='active' then 0 else 1 end, pca.created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_free_miner_accounts
  from (
    select id, wallet_address, status, claims_completed, claimed_amount, last_claim_at, next_claim_at, activated_at, created_at, updated_at
    from public.free_miner_accounts
    order by created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_audit_logs
  from (
    select id, admin_session_id, action, target_table, target_id, status, note, created_at
    from public.axon_admin_audit_log
    order by created_at desc
    limit 120
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_system_events
  from (
    select id, wallet_address, event_type as action, severity as status, payload::text as note, created_at
    from public.axon_system_events
    order by created_at desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_catalog
  from (
    select id, plan_code, payment_key, plan_name, plan_price, daily_rate, daily_claim_amount, max_claims, max_unlocks, sort_order, badge, category, description, is_visible, is_featured, status, created_at, updated_at, deleted_at
    from public.axon_plan_catalog
    order by sort_order asc, plan_price asc
  ) t;

  return jsonb_build_object(
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'free_miner_accounts', v_free_miner_accounts,
    'audit_logs', v_audit_logs,
    'system_events', v_system_events,
    'plan_catalog', v_plan_catalog,
    'session_expires_at', v_expires,
    'data_probe', public.axon_admin_live_data_probe()
  );
end;
$$;

revoke all on function public.axon_admin_user_index() from public;
revoke all on function public.axon_backfill_users_from_live_activity() from public;
revoke all on function public.axon_admin_live_data_probe() from public;
revoke all on function public.axon_admin_get_console(text) from public;

grant execute on function public.axon_admin_user_index() to anon, authenticated;
grant execute on function public.axon_backfill_users_from_live_activity() to anon, authenticated;
grant execute on function public.axon_admin_live_data_probe() to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;

-- Final visible proof after running this patch.
select public.axon_admin_live_data_probe() as axon_v6851_live_data_probe;

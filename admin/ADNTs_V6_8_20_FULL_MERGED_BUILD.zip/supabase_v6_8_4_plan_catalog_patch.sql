
-- AXON DIGITAL NFTs V6.8.4 PLAN CATALOG PATCH
-- Additive/idempotent. Requires the V6.7 admin session functions for admin upsert controls.
-- Run after supabase_v6_7_full.sql.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.axon_plan_catalog (
  id uuid primary key default extensions.gen_random_uuid(),
  plan_code text unique not null,
  payment_key text,
  plan_name text not null,
  plan_price numeric(12,2) not null default 0,
  daily_rate numeric(8,4) not null default 0,
  daily_claim_amount numeric(12,2) not null default 0,
  max_claims integer not null default 40,
  max_unlocks integer not null default 1,
  sort_order integer not null default 0,
  badge text,
  category text not null default 'starter',
  description text,
  is_visible boolean not null default true,
  is_featured boolean not null default false,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint axon_plan_catalog_price_nonnegative check (plan_price >= 0),
  constraint axon_plan_catalog_claims_positive check (max_claims > 0),
  constraint axon_plan_catalog_unlocks_positive check (max_unlocks > 0)
);

alter table public.axon_plan_catalog enable row level security;
revoke all on table public.axon_plan_catalog from public, anon, authenticated;
create index if not exists axon_plan_catalog_visible_idx on public.axon_plan_catalog (is_visible, status, sort_order);

insert into public.axon_plan_catalog (plan_code,payment_key,plan_name,plan_price,daily_rate,daily_claim_amount,max_claims,max_unlocks,sort_order,badge,category,description,is_visible,is_featured,status)
values
('free-nft','FREE NFT','FREE NFT',40,2.5,1,40,1,0,'Referral Gate','free','Free miner entry route. Claim $1 daily for 40 days after activation rules are satisfied.',true,false,'active'),
('lite-20','Lite','Lite',20,3,.60,40,10,1,'Entry','starter','Low-entry paid plan for users starting their first paid AXON daily claim cycle.',true,true,'active'),
('starter-50','Starter','Starter',50,3,1.50,40,7,2,'Popular','starter','Balanced starter plan with a 40-day claim cycle and dashboard countdown support.',true,true,'active'),
('bronze-100','Bronze','Bronze',100,3,3,40,5,3,'Growth','growth','Expanded paid plan cycle for users increasing their claim base.',true,false,'active'),
('silver-200','Silver','Silver',200,3,6,40,3,4,'Advanced','growth','Higher-tier paid cycle with clear daily claim progress and plan completion tracking.',true,true,'active'),
('gold-500','Gold','Gold',500,3.5,17.50,40,2,5,'Premium','premium','Premium cycle for experienced users who want the highest listed plan tier.',true,true,'active')
on conflict (plan_code) do update set
  payment_key = excluded.payment_key,
  plan_name = excluded.plan_name,
  plan_price = excluded.plan_price,
  daily_rate = excluded.daily_rate,
  daily_claim_amount = excluded.daily_claim_amount,
  max_claims = excluded.max_claims,
  max_unlocks = excluded.max_unlocks,
  sort_order = excluded.sort_order,
  badge = excluded.badge,
  category = excluded.category,
  description = excluded.description,
  updated_at = now();

create or replace function public.axon_get_plan_catalog()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select coalesce(jsonb_agg(to_jsonb(p) order by p.sort_order, p.plan_price), '[]'::jsonb)
  from public.axon_plan_catalog p
  where p.is_visible = true
    and coalesce(p.status,'active') = 'active';
$$;

create or replace function public.axon_admin_get_plan_catalog(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plans jsonb;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  select coalesce(jsonb_agg(to_jsonb(p) order by p.sort_order, p.plan_price), '[]'::jsonb)
  into v_plans
  from public.axon_plan_catalog p;
  return v_plans;
end;
$$;

create or replace function public.axon_admin_upsert_plan_catalog(
  p_admin_session_token text,
  p_plan_code text,
  p_payment_key text,
  p_plan_name text,
  p_plan_price numeric,
  p_daily_rate numeric,
  p_daily_claim_amount numeric,
  p_max_claims integer,
  p_max_unlocks integer,
  p_sort_order integer,
  p_badge text,
  p_category text,
  p_description text,
  p_is_visible boolean,
  p_is_featured boolean,
  p_status text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plan public.axon_plan_catalog%rowtype;
  v_code text := lower(regexp_replace(trim(coalesce(p_plan_code,'')), '[^a-zA-Z0-9]+', '-', 'g'));
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  v_code := regexp_replace(v_code, '(^-+|-+$)', '', 'g');
  if v_code = '' then
    raise exception 'Plan code is required.';
  end if;
  if coalesce(trim(p_plan_name),'') = '' then
    raise exception 'Plan name is required.';
  end if;
  if coalesce(p_plan_price,0) < 0 then
    raise exception 'Plan price cannot be negative.';
  end if;

  insert into public.axon_plan_catalog (
    plan_code,payment_key,plan_name,plan_price,daily_rate,daily_claim_amount,max_claims,max_unlocks,sort_order,badge,category,description,is_visible,is_featured,status,updated_at
  ) values (
    v_code, nullif(trim(coalesce(p_payment_key,'')),''), trim(p_plan_name), coalesce(p_plan_price,0), coalesce(p_daily_rate,0),
    coalesce(p_daily_claim_amount, round(coalesce(p_plan_price,0) * coalesce(p_daily_rate,0) / 100, 2)), greatest(coalesce(p_max_claims,40),1), greatest(coalesce(p_max_unlocks,1),1), coalesce(p_sort_order,0),
    nullif(trim(coalesce(p_badge,'')),''), coalesce(nullif(trim(p_category),''),'starter'), nullif(trim(coalesce(p_description,'')),''), coalesce(p_is_visible,true), coalesce(p_is_featured,false), coalesce(nullif(trim(p_status),''),'active'), now()
  )
  on conflict (plan_code) do update set
    payment_key = excluded.payment_key,
    plan_name = excluded.plan_name,
    plan_price = excluded.plan_price,
    daily_rate = excluded.daily_rate,
    daily_claim_amount = excluded.daily_claim_amount,
    max_claims = excluded.max_claims,
    max_unlocks = excluded.max_unlocks,
    sort_order = excluded.sort_order,
    badge = excluded.badge,
    category = excluded.category,
    description = excluded.description,
    is_visible = excluded.is_visible,
    is_featured = excluded.is_featured,
    status = excluded.status,
    updated_at = now()
  returning * into v_plan;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'upsert_plan_catalog', 'axon_plan_catalog', v_plan.id, 'completed', 'Plan catalog item saved: ' || v_plan.plan_code);

  return to_jsonb(v_plan);
end;
$$;

create or replace function public.axon_admin_set_plan_catalog_visibility(
  p_admin_session_token text,
  p_plan_code text,
  p_is_visible boolean
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_plan public.axon_plan_catalog%rowtype;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  update public.axon_plan_catalog
  set is_visible = coalesce(p_is_visible,false), updated_at = now()
  where plan_code = p_plan_code
  returning * into v_plan;
  if v_plan.id is null then
    raise exception 'Plan not found.';
  end if;
  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'set_plan_visibility', 'axon_plan_catalog', v_plan.id, 'completed', 'Visibility updated for: ' || v_plan.plan_code);
  return to_jsonb(v_plan);
end;
$$;

revoke all on function public.axon_get_plan_catalog() from public;
revoke all on function public.axon_admin_get_plan_catalog(text) from public;
revoke all on function public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text) from public;
revoke all on function public.axon_admin_set_plan_catalog_visibility(text,text,boolean) from public;

grant execute on function public.axon_get_plan_catalog() to anon, authenticated;
grant execute on function public.axon_admin_get_plan_catalog(text) to anon, authenticated;
grant execute on function public.axon_admin_upsert_plan_catalog(text,text,text,text,numeric,numeric,numeric,integer,integer,integer,text,text,text,boolean,boolean,text) to anon, authenticated;
grant execute on function public.axon_admin_set_plan_catalog_visibility(text,text,boolean) to anon, authenticated;

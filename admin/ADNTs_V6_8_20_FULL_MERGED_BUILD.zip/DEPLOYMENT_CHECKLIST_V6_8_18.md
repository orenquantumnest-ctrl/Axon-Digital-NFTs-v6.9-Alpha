# AXON DIGITAL NFTs V6.8.18 Referral Restoration

1. Upload contents of build_v6818/ to both axondigitalnfts.com and axonprime-vault.netlify.app.
2. Run supabase_v6_8_18_referral_system_patch.sql in Supabase SQL Editor.
3. Verify: select public.axon_referral_system_health_v6818();
4. Test /signup.html?ref=<wallet>, /referrals.html?fresh=6818, /admin-referrals.html?fresh=6818.

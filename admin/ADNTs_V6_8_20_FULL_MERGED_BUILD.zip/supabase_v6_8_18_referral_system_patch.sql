
-- AXON DIGITAL NFTs V6.8.18 Referral Restoration Patch
-- Run in Supabase SQL Editor. It is additive and does not delete live records.

create extension if not exists pgcrypto with schema extensions;

create or replace function public.axon_gen_uuid_v6818()
returns uuid
language plpgsql
volatile
set search_path=public,extensions
as $$
begin
  return extensions.gen_random_uuid();
exception when undefined_function then
  return gen_random_uuid();
end;
$$;

create table if not exists public.referrals (
  id uuid primary key default public.axon_gen_uuid_v6818(),
  referrer_wallet text not null,
  referred_wallet text not null,
  created_at timestamptz not null default now(),
  constraint referrals_no_self_ref check (lower(trim(referrer_wallet)) <> lower(trim(referred_wallet)))
);

create table if not exists public.referral_visits (
  id uuid primary key default public.axon_gen_uuid_v6818(),
  referrer_wallet text not null,
  visitor_key text null,
  landing_path text null,
  created_at timestamptz not null default now()
);

create table if not exists public.referral_commissions (
  id uuid primary key default public.axon_gen_uuid_v6818(),
  referrer_wallet text not null,
  referred_wallet text not null,
  level int not null default 1,
  source_table text not null default 'payment_submissions',
  source_id uuid null,
  source_amount numeric not null default 0,
  commission_rate numeric not null default 0,
  commission_amount numeric not null default 0,
  status text not null default 'earned',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists referrals_referred_wallet_unique on public.referrals (lower(referred_wallet));
create index if not exists referrals_referrer_wallet_idx on public.referrals (lower(referrer_wallet), created_at desc);
create index if not exists referral_visits_referrer_idx on public.referral_visits (lower(referrer_wallet), created_at desc);
create unique index if not exists referral_commissions_source_unique on public.referral_commissions (source_table, source_id, lower(referrer_wallet), level) where source_id is not null;
create index if not exists referral_commissions_referrer_idx on public.referral_commissions (lower(referrer_wallet), created_at desc);

alter table public.users add column if not exists referred_by text;
alter table public.users add column if not exists referral_code text;

create or replace function public.axon_ref_normalize_wallet_v6818(p_wallet text)
returns text
language sql
immutable
as $$
  select lower(trim(coalesce(p_wallet,'')))
$$;

create or replace function public.axon_ref_wallet_is_valid_v6818(p_wallet text)
returns boolean
language sql
immutable
as $$
  select public.axon_ref_normalize_wallet_v6818(p_wallet) ~ '^0x[a-f0-9]{40}$'
$$;

create or replace function public.axon_resolve_referrer_wallet_v6818(p_ref text)
returns text
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ref text := lower(trim(coalesce(p_ref,'')));
  v_wallet text;
begin
  if v_ref = '' then return null; end if;
  if public.axon_ref_wallet_is_valid_v6818(v_ref) then return v_ref; end if;
  select lower(wallet_address) into v_wallet
  from public.users
  where lower(coalesce(referral_code,'')) = v_ref
  limit 1;
  return v_wallet;
end;
$$;

create or replace function public.axon_track_referral_visit(
  p_referrer_wallet text,
  p_visitor_key text default null,
  p_landing_path text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_wallet text := public.axon_resolve_referrer_wallet_v6818(p_referrer_wallet);
  v_total int := 0;
begin
  if v_wallet is null or not public.axon_ref_wallet_is_valid_v6818(v_wallet) then
    raise exception 'Invalid referral wallet.';
  end if;

  insert into public.referral_visits(referrer_wallet, visitor_key, landing_path, created_at)
  values (v_wallet, nullif(trim(coalesce(p_visitor_key,'')),''), nullif(trim(coalesce(p_landing_path,'')),''), now());

  select count(*) into v_total from public.referral_visits where lower(referrer_wallet)=v_wallet;
  return jsonb_build_object('ok', true, 'referrer_wallet', v_wallet, 'referral_visits_count', v_total);
end;
$$;

create or replace function public.axon_link_referral_v6818(p_referrer_wallet text, p_referred_wallet text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_referrer text := public.axon_resolve_referrer_wallet_v6818(p_referrer_wallet);
  v_referred text := public.axon_ref_normalize_wallet_v6818(p_referred_wallet);
begin
  if v_referrer is null or not public.axon_ref_wallet_is_valid_v6818(v_referrer) then
    return jsonb_build_object('ok', false, 'linked', false, 'reason', 'invalid_referrer');
  end if;
  if not public.axon_ref_wallet_is_valid_v6818(v_referred) then
    return jsonb_build_object('ok', false, 'linked', false, 'reason', 'invalid_referred');
  end if;
  if v_referrer = v_referred then
    return jsonb_build_object('ok', false, 'linked', false, 'reason', 'self_referral_blocked');
  end if;

  if not exists (select 1 from public.referrals where lower(referred_wallet)=v_referred) then
    insert into public.referrals(referrer_wallet, referred_wallet, created_at)
    values (v_referrer, v_referred, now());
  end if;

  update public.users
  set referred_by = coalesce(nullif(referred_by,''), v_referrer),
      referral_code = coalesce(nullif(referral_code,''), wallet_address)
  where lower(wallet_address)=v_referred;

  return jsonb_build_object('ok', true, 'linked', true, 'referrer_wallet', v_referrer, 'referred_wallet', v_referred);
end;
$$;

create or replace function public.axon_get_referral_summary(p_wallet text, p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_wallet text := public.axon_ref_normalize_wallet_v6818(p_wallet);
  v_direct_count int := 0;
  v_visits int := 0;
  v_direct jsonb := '[]'::jsonb;
  v_level2 jsonb := '[]'::jsonb;
  v_direct_earn numeric := 0;
  v_level2_earn numeric := 0;
  v_referred_by text := '';
begin
  perform public.axon_assert_session(v_wallet, p_session_token);

  select count(*) into v_direct_count from public.referrals where lower(referrer_wallet)=v_wallet;
  select count(*) into v_visits from public.referral_visits where lower(referrer_wallet)=v_wallet;
  select coalesce(referred_by,'') into v_referred_by from public.users where lower(wallet_address)=v_wallet limit 1;

  with direct as (
    select lower(r.referred_wallet) as referred_wallet, r.created_at
    from public.referrals r
    where lower(r.referrer_wallet)=v_wallet
  ), payments as (
    select lower(wallet_address) wallet_address, coalesce(amount_sent, plan_price, 0)::numeric amount
    from public.payment_submissions
    where lower(status) in ('approved','completed','active')
  ), rows as (
    select d.referred_wallet, d.created_at,
           coalesce(u.created_at, d.created_at) as registered_at,
           coalesce(sum(p.amount),0)::numeric as approved_deposit_total,
           (coalesce(sum(p.amount),0)::numeric * 0.08)::numeric as referral_earnings,
           count(up.id)::int as active_plans_count
    from direct d
    left join public.users u on lower(u.wallet_address)=d.referred_wallet
    left join payments p on p.wallet_address=d.referred_wallet
    left join public.user_plans up on lower(up.wallet_address)=d.referred_wallet and lower(up.status)='active'
    group by d.referred_wallet,d.created_at,u.created_at
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'level', 1,
    'referred_wallet', referred_wallet,
    'created_at', created_at,
    'registered_at', registered_at,
    'approved_deposit_total', approved_deposit_total,
    'referral_earnings', referral_earnings,
    'active_plans_count', active_plans_count,
    'status', 'registered'
  ) order by created_at desc),'[]'::jsonb), coalesce(sum(referral_earnings),0)::numeric
  into v_direct, v_direct_earn
  from rows;

  with direct as (
    select lower(referred_wallet) as wallet_address from public.referrals where lower(referrer_wallet)=v_wallet
  ), second as (
    select lower(r.referred_wallet) as referred_wallet, lower(r.referrer_wallet) as parent_wallet, r.created_at
    from public.referrals r join direct d on lower(r.referrer_wallet)=d.wallet_address
  ), payments as (
    select lower(wallet_address) wallet_address, coalesce(amount_sent, plan_price, 0)::numeric amount
    from public.payment_submissions where lower(status) in ('approved','completed','active')
  ), rows as (
    select s.parent_wallet, s.referred_wallet, s.created_at, coalesce(sum(p.amount),0)::numeric approved_deposit_total,
           (coalesce(sum(p.amount),0)::numeric * 0.05)::numeric referral_earnings
    from second s left join payments p on p.wallet_address=s.referred_wallet
    group by s.parent_wallet,s.referred_wallet,s.created_at
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'level', 2,
    'parent_wallet', parent_wallet,
    'referred_wallet', referred_wallet,
    'created_at', created_at,
    'approved_deposit_total', approved_deposit_total,
    'referral_earnings', referral_earnings,
    'status', 'registered'
  ) order by created_at desc),'[]'::jsonb), coalesce(sum(referral_earnings),0)::numeric
  into v_level2, v_level2_earn
  from rows;

  return jsonb_build_object(
    'ok', true,
    'wallet_address', v_wallet,
    'referral_link', '/signup.html?ref=' || v_wallet,
    'referred_by', coalesce(v_referred_by,''),
    'summary', jsonb_build_object(
      'direct_referrals', v_direct_count,
      'referral_visits', v_visits,
      'level1_earnings', v_direct_earn,
      'level2_earnings', v_level2_earn,
      'total_referral_earnings', v_direct_earn + v_level2_earn
    ),
    'direct_referrals', v_direct,
    'level2_referrals', v_level2,
    'referrals_count', v_direct_count,
    'referral_visits_count', v_visits,
    'total_referral_earnings', v_direct_earn + v_level2_earn,
    'level1_earnings', v_direct_earn,
    'level2_earnings', v_level2_earn,
    'recent_referrals', v_direct
  );
end;
$$;

create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_session jsonb;
  v_stats jsonb;
  v_users jsonb;
  v_payments jsonb;
  v_withdrawals jsonb;
  v_transactions jsonb;
  v_plan_accounts jsonb;
  v_plan_catalog jsonb;
  v_free_miners jsonb;
  v_audit jsonb;
  v_events jsonb;
  v_referrals jsonb;
  v_referral_leaders jsonb;
  v_referral_earnings numeric := 0;
begin
  v_session := public.axon_admin_assert_session_v6811(p_admin_session_token);
  if coalesce((v_session->>'valid')::boolean,false) is not true then
    raise exception 'Invalid or expired admin session.';
  end if;

  with direct_payments as (
    select lower(r.referrer_wallet) referrer_wallet, lower(r.referred_wallet) referred_wallet,
           coalesce(sum(coalesce(ps.amount_sent, ps.plan_price, 0)),0)::numeric deposits
    from public.referrals r
    left join public.payment_submissions ps on lower(ps.wallet_address)=lower(r.referred_wallet) and lower(ps.status) in ('approved','completed','active')
    group by lower(r.referrer_wallet), lower(r.referred_wallet)
  ), edges as (
    select r.id, lower(r.referrer_wallet) referrer_wallet, lower(r.referred_wallet) referred_wallet, r.created_at,
           coalesce(dp.deposits,0)::numeric approved_deposit_total,
           (coalesce(dp.deposits,0)::numeric * 0.08)::numeric referral_earnings,
           1 as level
    from public.referrals r
    left join direct_payments dp on dp.referrer_wallet=lower(r.referrer_wallet) and dp.referred_wallet=lower(r.referred_wallet)
  )
  select coalesce(jsonb_agg(to_jsonb(e) order by e.created_at desc),'[]'::jsonb), coalesce(sum(referral_earnings),0)::numeric
  into v_referrals, v_referral_earnings
  from edges e;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.referrals_count desc),'[]'::jsonb)
  into v_referral_leaders
  from (
    select lower(r.referrer_wallet) referrer_wallet,
           count(*)::int referrals_count,
           count(rv.id)::int referral_visits_count,
           coalesce(sum(coalesce(ps.amount_sent, ps.plan_price, 0)),0)::numeric approved_deposit_total,
           (coalesce(sum(coalesce(ps.amount_sent, ps.plan_price, 0)),0)::numeric * 0.08)::numeric referral_earnings
    from public.referrals r
    left join public.referral_visits rv on lower(rv.referrer_wallet)=lower(r.referrer_wallet)
    left join public.payment_submissions ps on lower(ps.wallet_address)=lower(r.referred_wallet) and lower(ps.status) in ('approved','completed','active')
    group by lower(r.referrer_wallet)
    order by referrals_count desc
    limit 100
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_payments from (select * from public.payment_submissions order by created_at desc limit 120) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_withdrawals from (select * from public.withdrawal_requests order by created_at desc limit 120) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_transactions from (select * from public.transactions order by created_at desc limit 160) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_plan_accounts from (select * from public.plan_claim_accounts order by created_at desc limit 120) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.sort_order asc),'[]'::jsonb) into v_plan_catalog from (select * from public.axon_plan_catalog order by sort_order asc limit 120) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_free_miners from (select * from public.free_miner_accounts order by created_at desc limit 120) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_users from (
    select u.*, 
      (select count(*) from public.referrals r where lower(r.referrer_wallet)=lower(u.wallet_address))::int as referrals_count,
      (select count(*) from public.user_plans up where lower(up.wallet_address)=lower(u.wallet_address) and lower(up.status)='active')::int as active_plans_count,
      (select coalesce(sum(amount),0) from public.transactions tr where lower(tr.wallet_address)=lower(u.wallet_address) and lower(tr.status) in ('approved','completed','active'))::numeric as available_balance
    from public.users u
    order by u.created_at desc
    limit 160
  ) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_audit from (select * from public.axon_admin_audit_log order by created_at desc limit 100) t;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) into v_events from (select * from public.axon_system_events order by created_at desc limit 100) t;

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.users),
    'active_plans_count', (select count(*) from public.user_plans where lower(status)='active'),
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(status) in ('pending','submitted','processing')),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(status) in ('pending','processing')),
    'transactions_count', (select count(*) from public.transactions),
    'catalog_count', (select count(*) from public.axon_plan_catalog),
    'claim_accounts_count', (select count(*) from public.plan_claim_accounts),
    'free_miner_count', (select count(*) from public.free_miner_accounts),
    'referrals_count', (select count(*) from public.referrals),
    'referral_visits_count', (select count(*) from public.referral_visits),
    'referral_earnings_total', v_referral_earnings,
    'total_claim_earnings', (select coalesce(sum(claim_amount),0) from public.plan_claim_history) + (select coalesce(sum(claim_amount),0) from public.free_miner_claims),
    'reserved_withdrawals', (select coalesce(sum(requested_amount),0) from public.withdrawal_requests where lower(status) in ('pending','processing'))
  );

  return jsonb_build_object(
    'ok', true,
    'stats', v_stats,
    'data_probe', jsonb_build_object(
      'public_users', (select count(*) from public.users),
      'referrals', (select count(*) from public.referrals),
      'referral_visits', (select count(*) from public.referral_visits),
      'transactions', (select count(*) from public.transactions),
      'payment_pending', (select count(*) from public.payment_submissions where lower(status) in ('pending','submitted','processing')),
      'withdrawal_pending', (select count(*) from public.withdrawal_requests where lower(status) in ('pending','processing')),
      'free_miner_accounts', (select count(*) from public.free_miner_accounts),
      'plan_claim_accounts_active', (select count(*) from public.plan_claim_accounts where lower(status)='active'),
      'user_plans_active', (select count(*) from public.user_plans where lower(status)='active'),
      'axon_plan_catalog', (select count(*) from public.axon_plan_catalog),
      'referral_earnings_total', v_referral_earnings
    ),
    'users', v_users,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'free_miner_accounts', v_free_miners,
    'plan_catalog', v_plan_catalog,
    'audit_logs', v_audit,
    'system_events', v_events,
    'referrals', v_referrals,
    'referral_leaders', v_referral_leaders,
    'session_expires_at', v_session->>'expires_at'
  );
end;
$$;

grant execute on function public.axon_track_referral_visit(text,text,text) to anon, authenticated;
grant execute on function public.axon_link_referral_v6818(text,text) to anon, authenticated;
grant execute on function public.axon_get_referral_summary(text,text) to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;

create or replace function public.axon_referral_system_health_v6818()
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
begin
  return jsonb_build_object(
    'ok', true,
    'users', (select count(*) from public.users),
    'referrals', (select count(*) from public.referrals),
    'referral_visits', (select count(*) from public.referral_visits),
    'approved_payment_submissions', (select count(*) from public.payment_submissions where lower(status) in ('approved','completed','active')),
    'admin_console_has_referrals', true,
    'user_referral_summary_rpc_exists', true
  );
end;
$$;

grant execute on function public.axon_referral_system_health_v6818() to anon, authenticated;
notify pgrst, 'reload schema';

select public.axon_referral_system_health_v6818();

-- AXON DIGITAL NFTs V6.8.14
-- Admin payment approval + user ledger activation patch.
-- Run in Supabase SQL Editor only. Does not delete user data.

create extension if not exists pgcrypto with schema extensions;

create or replace function public.axon_admin_update_payment_status(
  p_admin_session_token text,
  p_payment_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_payment public.payment_submissions%rowtype;
  v_wallet text;
  v_user_plan_id uuid;
  v_tx_count int := 0;
  v_claim_account_id uuid;
  v_plan_status text;
  v_plan_price numeric := 0;
  v_amount numeric := 0;
  v_daily_rate numeric := null;
  v_daily_claim_amount numeric := null;
  v_max_claims int := 40;
  v_note text := nullif(trim(coalesce(p_admin_note, '')), '');
begin
  v_session_id := public.axon_admin_assert_session_v6811(p_admin_session_token);

  if v_status not in ('pending', 'processing', 'approved', 'completed', 'rejected') then
    raise exception 'Invalid payment status: %', v_status;
  end if;

  select * into v_payment
  from public.payment_submissions
  where id = p_payment_id
  for update;

  if not found then
    raise exception 'Payment submission not found.';
  end if;

  v_wallet := lower(trim(v_payment.wallet_address));
  v_plan_price := coalesce(v_payment.plan_price, v_payment.amount_sent, 0);
  v_amount := coalesce(v_payment.amount_sent, v_payment.plan_price, 0);

  insert into public.users (id, wallet_address, referral_code, created_at)
  values (gen_random_uuid(), v_wallet, substr(replace(gen_random_uuid()::text, '-', ''), 1, 10), now())
  on conflict (wallet_address) do nothing;

  select
    coalesce(apc.plan_price, v_plan_price),
    coalesce(apc.daily_rate, null),
    coalesce(apc.daily_claim_amount, null),
    coalesce(apc.max_claims, 40)
  into v_plan_price, v_daily_rate, v_daily_claim_amount, v_max_claims
  from public.axon_plan_catalog apc
  where lower(trim(apc.plan_name)) = lower(trim(coalesce(v_payment.plan_name, '')))
     or coalesce(apc.plan_price, -1) = coalesce(v_payment.plan_price, -2)
  order by apc.sort_order asc nulls last
  limit 1;

  if v_daily_rate is null then
    select
      coalesce(pc.plan_price, v_plan_price),
      coalesce(pc.daily_rate, null),
      coalesce(pc.max_claims, 40)
    into v_plan_price, v_daily_rate, v_max_claims
    from public.plan_catalog pc
    where lower(trim(pc.plan_name)) = lower(trim(coalesce(v_payment.plan_name, '')))
       or coalesce(pc.plan_price, -1) = coalesce(v_payment.plan_price, -2)
    order by pc.sort_order asc nulls last
    limit 1;
  end if;

  if v_daily_rate is null then
    v_daily_rate := case when v_plan_price >= 500 then 3.5 else 3 end;
  end if;

  if v_daily_claim_amount is null or v_daily_claim_amount <= 0 then
    v_daily_claim_amount := round(
      case when v_daily_rate > 1 then v_plan_price * v_daily_rate / 100 else v_plan_price * v_daily_rate end,
      2
    );
  end if;

  if v_max_claims is null or v_max_claims <= 0 then
    v_max_claims := 40;
  end if;

  update public.payment_submissions
  set status = v_status,
      admin_note = v_note,
      reviewed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else reviewed_at end,
      processed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_payment_id
  returning * into v_payment;

  update public.transactions
  set status = v_status,
      amount = coalesce(amount, v_amount),
      plan_name = coalesce(plan_name, v_payment.plan_name),
      source = coalesce(source, 'payment_submission'),
      notes = concat_ws(' • ', nullif(notes, ''), case when v_note is not null then 'Admin: ' || v_note else null end)
  where reference_id = p_payment_id;
  get diagnostics v_tx_count = row_count;

  if v_tx_count = 0 and v_payment.tx_hash is not null then
    update public.transactions
    set status = v_status,
        reference_id = p_payment_id,
        amount = coalesce(amount, v_amount),
        plan_name = coalesce(plan_name, v_payment.plan_name),
        source = coalesce(source, 'payment_submission'),
        notes = concat_ws(' • ', nullif(notes, ''), case when v_note is not null then 'Admin: ' || v_note else null end)
    where lower(trim(wallet_address)) = v_wallet
      and lower(coalesce(notes, '')) like '%' || lower(v_payment.tx_hash) || '%';
    get diagnostics v_tx_count = row_count;
  end if;

  if v_tx_count = 0 then
    insert into public.transactions (id, wallet_address, type, amount, status, created_at, plan_name, source, reference_id, notes)
    values (
      gen_random_uuid(),
      v_wallet,
      'payment_submission',
      v_amount,
      v_status,
      coalesce(v_payment.created_at, now()),
      v_payment.plan_name,
      'payment_submission',
      p_payment_id,
      concat_ws(' • ', nullif(v_payment.payment_notes, ''), case when v_payment.tx_hash is not null then 'TX ' || v_payment.tx_hash else null end, case when v_note is not null then 'Admin: ' || v_note else null end)
    );
  end if;

  if v_status in ('approved', 'completed') then
    v_plan_status := 'active';
  elsif v_status = 'rejected' then
    v_plan_status := 'rejected';
  else
    v_plan_status := 'pending';
  end if;

  select id into v_user_plan_id
  from public.user_plans
  where lower(trim(wallet_address)) = v_wallet
    and payment_submission_id = p_payment_id
  order by created_at desc
  limit 1;

  if v_user_plan_id is null then
    select id into v_user_plan_id
    from public.user_plans
    where lower(trim(wallet_address)) = v_wallet
      and lower(trim(coalesce(plan_name, ''))) = lower(trim(coalesce(v_payment.plan_name, '')))
    order by created_at desc
    limit 1;
  end if;

  if v_user_plan_id is null then
    insert into public.user_plans (id, wallet_address, plan_name, plan_price, status, activated_at, created_at, payment_submission_id)
    values (gen_random_uuid(), v_wallet, v_payment.plan_name, v_plan_price, v_plan_status, case when v_plan_status = 'active' then now() else null end, now(), p_payment_id)
    returning id into v_user_plan_id;
  else
    update public.user_plans
    set plan_name = coalesce(v_payment.plan_name, plan_name),
        plan_price = coalesce(v_plan_price, plan_price),
        status = v_plan_status,
        activated_at = case when v_plan_status = 'active' then coalesce(activated_at, now()) else activated_at end,
        payment_submission_id = coalesce(payment_submission_id, p_payment_id)
    where id = v_user_plan_id;
  end if;

  if v_plan_status = 'active' then
    insert into public.plan_claim_accounts (
      id, wallet_address, user_plan_id, plan_name, plan_price, daily_rate, daily_claim_amount,
      max_claims, claims_completed, total_claimed, status, next_claim_at, created_at, updated_at, last_claim_at
    ) values (
      gen_random_uuid(), v_wallet, v_user_plan_id, v_payment.plan_name, v_plan_price, v_daily_rate, v_daily_claim_amount,
      v_max_claims, 0, 0, 'active', null, now(), now(), null
    )
    on conflict (user_plan_id) do update
    set status = 'active',
        plan_name = excluded.plan_name,
        plan_price = excluded.plan_price,
        daily_rate = excluded.daily_rate,
        daily_claim_amount = excluded.daily_claim_amount,
        max_claims = excluded.max_claims,
        updated_at = now()
    returning id into v_claim_account_id;
  elsif v_plan_status = 'rejected' then
    update public.plan_claim_accounts
    set status = 'rejected', updated_at = now()
    where user_plan_id = v_user_plan_id
    returning id into v_claim_account_id;
  end if;

  insert into public.user_notifications (id, wallet_address, title, message, notification_type, is_read, created_at)
  values (
    gen_random_uuid(),
    v_wallet,
    case when v_status in ('approved','completed') then 'Payment Approved' when v_status = 'rejected' then 'Payment Rejected' else 'Payment Updated' end,
    case when v_status in ('approved','completed') then 'Your payment has been approved and your plan is now active.' when v_status = 'rejected' then 'Your payment was rejected. Please review the admin note or contact support.' else 'Your payment status is now ' || v_status || '.' end,
    'payment',
    false,
    now()
  );

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note, created_at)
  values (gen_random_uuid(), v_session_id, 'payment_status_update_v6814', 'payment_submissions', p_payment_id, v_status, v_note, now());

  perform pg_notify('pgrst', 'reload schema');

  return jsonb_build_object(
    'ok', true,
    'payment_id', p_payment_id,
    'status', v_status,
    'wallet_address', v_wallet,
    'user_plan_id', v_user_plan_id,
    'claim_account_id', v_claim_account_id,
    'daily_claim_amount', v_daily_claim_amount,
    'transaction_synced', true
  );
end;
$$;

grant execute on function public.axon_admin_update_payment_status(text, uuid, text, text) to anon, authenticated;

create or replace function public.axon_admin_payment_approval_health()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  return jsonb_build_object(
    'ok', true,
    'update_payment_rpc_exists', to_regprocedure('public.axon_admin_update_payment_status(text,uuid,text,text)') is not null,
    'pending_payments', (select count(*) from public.payment_submissions where lower(status)='pending'),
    'payment_submissions', (select count(*) from public.payment_submissions),
    'transactions', (select count(*) from public.transactions),
    'user_plans', (select count(*) from public.user_plans),
    'plan_claim_accounts', (select count(*) from public.plan_claim_accounts)
  );
end;
$$;

grant execute on function public.axon_admin_payment_approval_health() to anon, authenticated;

select public.axon_admin_payment_approval_health();

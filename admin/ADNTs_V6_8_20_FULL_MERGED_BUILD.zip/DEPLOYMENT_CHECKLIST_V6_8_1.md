# AXON DIGITAL NFTs V6.8.1 Deployment Checklist

1. Back up the current public_html folder.
2. Upload the V6.8.1 files directly into public_html.
3. Do not place files inside an extra nested folder unless intentionally deploying to a subpath.
4. Keep the existing V6.7/V6.8 Supabase backend. No destructive SQL reset is required.
5. Test dashboard.html on 390px, 430px, tablet, and desktop widths.
6. Test admin-dashboard.html and admin standalone pages on mobile and desktop.
7. Confirm the menu opens as a compact glass drawer on mobile and stays horizontal-scroll safe on desktop/tablet.
8. Confirm deposit, withdrawal, transaction, and admin approval flows still work.

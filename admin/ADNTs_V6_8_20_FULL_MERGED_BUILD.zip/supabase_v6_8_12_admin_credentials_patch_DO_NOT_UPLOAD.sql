-- AXON DIGITAL NFTs V6.8.12
-- Admin credentials + live-probe normalizer support patch.
-- Run inside Supabase SQL Editor after the V6.8.11 admin RPC/session/data patch.
-- Do NOT upload this SQL file to public hosting.

create extension if not exists pgcrypto with schema extensions;

-- Official admin credentials requested for V6.8.12:
-- mode: super
-- wallet/login username: 0x7bbc456c2c34972723cf03b9d44323d2539514de
-- password: configured below as a bcrypt hash in Supabase only.

-- 1) Update any existing admin account using the official wallet.
update public.admin_accounts
set role = 'super_admin',
    wallet_address = '0x7bbc456c2c34972723cf03b9d44323d2539514de',
    username = '0x7bbc456c2c34972723cf03b9d44323d2539514de',
    pin_hash = extensions.crypt('Cx4!nX9pQ2mL7r', extensions.gen_salt('bf')),
    department = 'Executive Control',
    permission_bundle = jsonb_build_object(
      'users', true,
      'payments', true,
      'withdrawals', true,
      'plans', true,
      'admins', true,
      'audit', true,
      'settings', true
    ),
    is_active = true,
    display_name = 'MasterAdmin',
    wallet_modal_label = 'Official AXON Deposit Wallet',
    admin_tag = 'AXON_SUPER_ADMIN_V6812',
    updated_at = now()
where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
   or lower(trim(coalesce(username, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
   or lower(trim(coalesce(username, ''))) = 'masteradmin';

-- 2) Insert the admin account if it does not already exist.
insert into public.admin_accounts (
  id,
  role,
  wallet_address,
  username,
  pin_hash,
  department,
  permission_bundle,
  is_active,
  display_name,
  wallet_modal_label,
  admin_tag,
  created_at,
  updated_at
)
select
  extensions.gen_random_uuid(),
  'super_admin',
  '0x7bbc456c2c34972723cf03b9d44323d2539514de',
  '0x7bbc456c2c34972723cf03b9d44323d2539514de',
  extensions.crypt('Cx4!nX9pQ2mL7r', extensions.gen_salt('bf')),
  'Executive Control',
  jsonb_build_object(
    'users', true,
    'payments', true,
    'withdrawals', true,
    'plans', true,
    'admins', true,
    'audit', true,
    'settings', true
  ),
  true,
  'MasterAdmin',
  'Official AXON Deposit Wallet',
  'AXON_SUPER_ADMIN_V6812',
  now(),
  now()
where not exists (
  select 1 from public.admin_accounts
  where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
     or lower(trim(coalesce(username, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
);

-- 3) Keep the wallet-login compatibility table aligned.
update public.axon_admin_wallet_accounts
set wallet_address = '0x7bbc456c2c34972723cf03b9d44323d2539514de',
    password_hash = extensions.crypt('Cx4!nX9pQ2mL7r', extensions.gen_salt('bf')),
    display_name = 'MasterAdmin',
    role = 'super_admin',
    status = 'active',
    updated_at = now()
where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de';

insert into public.axon_admin_wallet_accounts (
  id,
  wallet_address,
  password_hash,
  display_name,
  role,
  status,
  created_at,
  updated_at
)
select
  extensions.gen_random_uuid(),
  '0x7bbc456c2c34972723cf03b9d44323d2539514de',
  extensions.crypt('Cx4!nX9pQ2mL7r', extensions.gen_salt('bf')),
  'MasterAdmin',
  'super_admin',
  'active',
  now(),
  now()
where not exists (
  select 1 from public.axon_admin_wallet_accounts
  where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
);

-- 4) Keep RPC execution exposed to browser anon/authenticated roles.
grant execute on function public.axon_admin_login_v689(text,text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_wallet_login(text,text) to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;

do $$
begin
  if to_regprocedure('public.axon_admin_live_data_probe_v6811()') is not null then
    execute 'grant execute on function public.axon_admin_live_data_probe_v6811() to anon, authenticated';
  end if;
  if to_regprocedure('public.axon_admin_live_data_probe()') is not null then
    execute 'grant execute on function public.axon_admin_live_data_probe() to anon, authenticated';
  end if;
end $$;

-- 5) Verification output.
select jsonb_build_object(
  'ok', true,
  'version', '6.8.12',
  'admin_mode', 'super',
  'wallet_address', '0x7bbc456c2c34972723cf03b9d44323d2539514de',
  'admin_accounts_matching', (
    select count(*) from public.admin_accounts
    where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
       or lower(trim(coalesce(username, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
  ),
  'wallet_accounts_matching', (
    select count(*) from public.axon_admin_wallet_accounts
    where lower(trim(coalesce(wallet_address, ''))) = '0x7bbc456c2c34972723cf03b9d44323d2539514de'
  )
) as axon_v6812_admin_credentials_status;

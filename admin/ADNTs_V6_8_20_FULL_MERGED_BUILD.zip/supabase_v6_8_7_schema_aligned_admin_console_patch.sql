-- AXON DIGITAL NFTs V6.8.7 — Schema-Aligned Admin Console Bridge
-- Purpose:
--   Fix admin dashboard counts/records showing 0 by aligning the admin RPC with the real
--   public schema supplied for AXON production tables.
--   This patch is additive/idempotent and does not delete user data.
-- Run after the V6.8.6 wallet-login SQL files.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- 1) Shared wallet normalizer used by admin/user index helpers
-- -----------------------------------------------------------------------------
create or replace function public.axon_normalize_wallet(p_value text)
returns text
language sql
immutable
set search_path = public
as $$
  select lower(trim(coalesce(p_value, '')));
$$;

-- -----------------------------------------------------------------------------
-- 2) Admin session bridge
-- Supports the current axon_admin_sessions token table and the older admin_sessions
-- table so existing sessions and newer wallet sessions can validate consistently.
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_assert_session(p_admin_session_token text)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_token text := trim(coalesce(p_admin_session_token, ''));
  v_session_id uuid;
begin
  if v_token = '' then
    raise exception 'Admin session token is required.';
  end if;

  select id into v_session_id
  from public.axon_admin_sessions
  where admin_session_token = v_token
    and revoked_at is null
    and expires_at > now()
  order by created_at desc
  limit 1;

  if v_session_id is null then
    select id into v_session_id
    from public.admin_sessions
    where session_token = v_token
      and revoked_at is null
      and expires_at > now()
    order by created_at desc
    limit 1;
  end if;

  if v_session_id is null then
    raise exception 'Admin session is invalid or expired. Login again with the admin wallet/password.';
  end if;

  return v_session_id;
end;
$$;

-- -----------------------------------------------------------------------------
-- 3) Live wallet index from every real wallet-bearing production table
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_user_index()
returns table(wallet_address text, created_at timestamptz)
language sql
security definer
set search_path = public, extensions
as $$
  with raw_wallets as (
    select wallet_address::text, created_at::timestamptz from public.users
    union all select wallet_address::text, created_at::timestamptz from public.user_sessions
    union all select wallet_address::text, created_at::timestamptz from public.payment_submissions
    union all select wallet_address::text, created_at::timestamptz from public.user_plans
    union all select wallet_address::text, created_at::timestamptz from public.transactions
    union all select wallet_address::text, created_at::timestamptz from public.withdrawal_requests
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_accounts
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_claims
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_accounts
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_history
    union all select referrer_wallet::text as wallet_address, created_at::timestamptz from public.referrals
    union all select referred_wallet::text as wallet_address, created_at::timestamptz from public.referrals
    union all select referrer_wallet::text as wallet_address, created_at::timestamptz from public.referral_visits
    union all select wallet_address::text, created_at::timestamptz from public.axon_system_events where wallet_address is not null
  ), cleaned as (
    select public.axon_normalize_wallet(wallet_address) as wallet_address,
           coalesce(created_at, now()) as created_at
    from raw_wallets
    where nullif(trim(coalesce(wallet_address,'')), '') is not null
  )
  select cleaned.wallet_address, min(cleaned.created_at) as created_at
  from cleaned
  where cleaned.wallet_address <> ''
  group by cleaned.wallet_address
  order by min(cleaned.created_at) desc;
$$;

-- -----------------------------------------------------------------------------
-- 4) Probe counts from the exact schema supplied
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_live_data_probe()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'public_users', (select count(*) from public.users),
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index()),
    'user_sessions', (select count(*) from public.user_sessions),
    'payment_submissions', (select count(*) from public.payment_submissions),
    'payment_pending', (select count(*) from public.payment_submissions where lower(trim(coalesce(status,'pending'))) = 'pending'),
    'user_plans', (select count(*) from public.user_plans),
    'user_plans_active', (select count(*) from public.user_plans where lower(trim(coalesce(status,''))) = 'active'),
    'plan_claim_accounts', (select count(*) from public.plan_claim_accounts),
    'plan_claim_accounts_active', (select count(*) from public.plan_claim_accounts where lower(trim(coalesce(status,''))) = 'active'),
    'plan_claim_history', (select count(*) from public.plan_claim_history),
    'free_miner_accounts', (select count(*) from public.free_miner_accounts),
    'free_miner_claims', (select count(*) from public.free_miner_claims),
    'transactions', (select count(*) from public.transactions),
    'withdrawal_requests', (select count(*) from public.withdrawal_requests),
    'withdrawal_pending', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status,'pending'))) in ('pending','processing')),
    'referrals', (select count(*) from public.referrals),
    'referral_visits', (select count(*) from public.referral_visits),
    'axon_plan_catalog', (select count(*) from public.axon_plan_catalog where deleted_at is null),
    'legacy_plan_catalog', (select count(*) from public.plan_catalog),
    'admin_wallet_accounts', (select count(*) from public.axon_admin_wallet_accounts),
    'admin_sessions_v686', (select count(*) from public.axon_admin_sessions where revoked_at is null and expires_at > now()),
    'admin_sessions_legacy', (select count(*) from public.admin_sessions where revoked_at is null and expires_at > now())
  );
$$;

-- -----------------------------------------------------------------------------
-- 5) Safe backfill users table from all wallet activity if users table is incomplete
-- -----------------------------------------------------------------------------
create or replace function public.axon_backfill_users_from_live_activity()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_before integer := 0;
  v_after integer := 0;
begin
  select count(*) into v_before from public.users;

  insert into public.users (wallet_address, referral_code, created_at)
  select idx.wallet_address,
         'AX' || upper(substr(md5(idx.wallet_address), 1, 10)) as referral_code,
         coalesce(idx.created_at, now())
  from public.axon_admin_user_index() idx
  where idx.wallet_address <> ''
  on conflict (wallet_address) do nothing;

  select count(*) into v_after from public.users;

  return jsonb_build_object(
    'ok', true,
    'users_before', v_before,
    'users_after', v_after,
    'inserted', greatest(0, v_after - v_before),
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index())
  );
end;
$$;

select public.axon_backfill_users_from_live_activity() as axon_v687_user_backfill;

-- -----------------------------------------------------------------------------
-- 6) Schema-aligned admin console RPC used by all admin pages
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_plan_accounts jsonb := '[]'::jsonb;
  v_free_miner_accounts jsonb := '[]'::jsonb;
  v_audit_logs jsonb := '[]'::jsonb;
  v_system_events jsonb := '[]'::jsonb;
  v_plan_catalog jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
  v_active_plans integer := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires
  from public.axon_admin_sessions
  where id = v_session_id
  limit 1;

  if v_expires is null then
    select expires_at into v_expires
    from public.admin_sessions
    where id = v_session_id
    limit 1;
  end if;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing');

  select coalesce(count(*),0) into v_active_plans
  from (
    select id::text as row_id from public.plan_claim_accounts where lower(trim(coalesce(status,''))) = 'active'
    union
    select id::text as row_id from public.user_plans where lower(trim(coalesce(status,''))) = 'active'
  ) active_rows;

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.axon_admin_user_index()),
    'public_users_count', (select count(*) from public.users),
    'derived_live_wallets_count', (select count(*) from public.axon_admin_user_index()),
    'active_plans_count', v_active_plans,
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'transactions_count', (select count(*) from public.transactions),
    'catalog_count', (select count(*) from public.axon_plan_catalog where coalesce(status,'active') <> 'deleted' and deleted_at is null),
    'claim_accounts_count', (select count(*) from public.plan_claim_accounts),
    'free_miner_count', (select count(*) from public.free_miner_accounts),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, reviewed_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select
      idx.wallet_address,
      u.id,
      coalesce(u.referral_code, 'AX' || upper(substr(md5(idx.wallet_address), 1, 10))) as referral_code,
      u.referred_by,
      coalesce(u.created_at, idx.created_at) as created_at,
      coalesce((select count(*) from public.user_plans up where public.axon_normalize_wallet(up.wallet_address) = idx.wallet_address and lower(trim(coalesce(up.status,''))) = 'active'),0)
      + coalesce((select count(*) from public.plan_claim_accounts pca where public.axon_normalize_wallet(pca.wallet_address) = idx.wallet_address and lower(trim(coalesce(pca.status,''))) = 'active'),0) as active_plans_count,
      coalesce((select sum(amount) from public.transactions tx where public.axon_normalize_wallet(tx.wallet_address) = idx.wallet_address and lower(trim(coalesce(tx.status,'completed'))) in ('completed','approved','active')),0) as available_balance,
      coalesce((select count(*) from public.payment_submissions ps where public.axon_normalize_wallet(ps.wallet_address) = idx.wallet_address),0) as payment_count,
      coalesce((select count(*) from public.withdrawal_requests wr where public.axon_normalize_wallet(wr.wallet_address) = idx.wallet_address),0) as withdrawal_count,
      coalesce((select count(*) from public.plan_claim_history pch where public.axon_normalize_wallet(pch.wallet_address) = idx.wallet_address),0) as paid_claims_count,
      coalesce((select count(*) from public.free_miner_claims fmc where public.axon_normalize_wallet(fmc.wallet_address) = idx.wallet_address),0) as free_claims_count
    from public.axon_admin_user_index() idx
    left join public.users u on public.axon_normalize_wallet(u.wallet_address) = idx.wallet_address
    order by coalesce(u.created_at, idx.created_at) desc
    limit 300
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_transactions
  from (
    select id, wallet_address, type, plan_name, amount, status, source, reference_id, notes, created_at
    from public.transactions
    order by created_at desc
    limit 250
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_accounts
  from (
    select pca.id, pca.wallet_address, pca.user_plan_id, pca.plan_name, pca.plan_price, pca.daily_rate, pca.daily_claim_amount, pca.max_claims, pca.claims_completed, pca.total_claimed, pca.last_claim_at, pca.next_claim_at, pca.status, pca.created_at, pca.updated_at
    from public.plan_claim_accounts pca
    order by case when lower(trim(coalesce(pca.status,'')))='active' then 0 else 1 end, pca.created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_free_miner_accounts
  from (
    select id, wallet_address, status, claims_completed, claimed_amount, last_claim_at, next_claim_at, activated_at, created_at, updated_at
    from public.free_miner_accounts
    order by created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_audit_logs
  from (
    select id, admin_session_id::text as admin_id, action as action_name, target_table as entity_type, target_id::text as entity_id, jsonb_build_object('note',note,'status',status) as details, created_at
    from public.axon_admin_audit_log
    union all
    select id, admin_id::text, action_name, entity_type, entity_id, details, created_at
    from public.admin_audit_logs
    order by created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_system_events
  from (
    select id, wallet_address, event_type as action, severity as status, payload::text as note, created_at
    from public.axon_system_events
    order by created_at desc
    limit 150
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_catalog
  from (
    select id, plan_code, payment_key, plan_name, plan_price, daily_rate, daily_claim_amount, max_claims, max_unlocks, sort_order, badge, category, description, is_visible, is_featured, status, created_at, updated_at, deleted_at
    from public.axon_plan_catalog
    where deleted_at is null
    order by sort_order asc, plan_price asc
  ) t;

  return jsonb_build_object(
    'ok', true,
    'version', '6.8.7',
    'schema_bridge', 'real_supplied_public_schema',
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'free_miner_accounts', v_free_miner_accounts,
    'audit_logs', v_audit_logs,
    'system_events', v_system_events,
    'plan_catalog', v_plan_catalog,
    'session_expires_at', v_expires,
    'data_probe', public.axon_admin_live_data_probe()
  );
end;
$$;

-- -----------------------------------------------------------------------------
-- 7) Health check callable from SQL editor and browser RPC
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_schema_bridge_health()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'ok', true,
    'version', '6.8.7',
    'users_table', to_regclass('public.users') is not null,
    'payment_submissions_table', to_regclass('public.payment_submissions') is not null,
    'withdrawal_requests_table', to_regclass('public.withdrawal_requests') is not null,
    'transactions_table', to_regclass('public.transactions') is not null,
    'axon_admin_get_console_rpc', to_regprocedure('public.axon_admin_get_console(text)') is not null,
    'wallet_login_rpc', to_regprocedure('public.axon_admin_wallet_login(text,text)') is not null,
    'live_data_probe', public.axon_admin_live_data_probe()
  );
$$;

revoke all on function public.axon_normalize_wallet(text) from public;
revoke all on function public.axon_admin_assert_session(text) from public;
revoke all on function public.axon_admin_user_index() from public;
revoke all on function public.axon_admin_live_data_probe() from public;
revoke all on function public.axon_backfill_users_from_live_activity() from public;
revoke all on function public.axon_admin_get_console(text) from public;
revoke all on function public.axon_admin_schema_bridge_health() from public;

grant execute on function public.axon_admin_wallet_login(text,text) to anon, authenticated;
grant execute on function public.axon_admin_assert_session(text) to anon, authenticated;
grant execute on function public.axon_admin_user_index() to anon, authenticated;
grant execute on function public.axon_admin_live_data_probe() to anon, authenticated;
grant execute on function public.axon_backfill_users_from_live_activity() to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;
grant execute on function public.axon_admin_schema_bridge_health() to anon, authenticated;

select public.axon_admin_schema_bridge_health() as axon_v687_schema_bridge_health;

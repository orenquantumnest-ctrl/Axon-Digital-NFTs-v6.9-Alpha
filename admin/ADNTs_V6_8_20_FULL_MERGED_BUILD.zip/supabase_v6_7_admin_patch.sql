-- AXON DIGITAL NFTs V6.7 additive admin/security patch
-- Run after the V6.5 baseline and V6.6 withdrawals patch, or run the consolidated supabase_v6_7_full.sql.
-- This patch is idempotent and preserves existing data.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- Operational metadata / audit tables
-- -----------------------------------------------------------------------------
alter table if exists public.payment_submissions add column if not exists admin_note text;
alter table if exists public.payment_submissions add column if not exists processed_at timestamptz;
alter table if exists public.payment_submissions add column if not exists updated_at timestamptz not null default now();

create table if not exists public.axon_admin_config (
  key text primary key,
  value_hash text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.axon_admin_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.axon_admin_audit_log (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_id uuid,
  action text not null,
  target_table text,
  target_id uuid,
  status text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.axon_system_events (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text,
  event_type text not null,
  severity text not null default 'info',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists axon_admin_sessions_token_idx on public.axon_admin_sessions (admin_session_token, expires_at desc);
create index if not exists axon_admin_audit_log_created_idx on public.axon_admin_audit_log (created_at desc);
create index if not exists axon_system_events_created_idx on public.axon_system_events (created_at desc);
create index if not exists payment_submissions_status_idx on public.payment_submissions (status, created_at desc);
create index if not exists user_plans_wallet_status_idx on public.user_plans (wallet_address, status, created_at desc);

alter table public.axon_admin_config enable row level security;
alter table public.axon_admin_sessions enable row level security;
alter table public.axon_admin_audit_log enable row level security;
alter table public.axon_system_events enable row level security;
revoke all on table public.axon_admin_config from public, anon, authenticated;
revoke all on table public.axon_admin_sessions from public, anon, authenticated;
revoke all on table public.axon_admin_audit_log from public, anon, authenticated;
revoke all on table public.axon_system_events from public, anon, authenticated;

-- Keep payment review timestamps current.
drop trigger if exists trg_payment_submissions_touch on public.payment_submissions;
create trigger trg_payment_submissions_touch
before update on public.payment_submissions
for each row execute function public.axon_touch_updated_at();

-- -----------------------------------------------------------------------------
-- Admin key setup. Run from Supabase SQL editor only:
-- select public.axon_admin_set_key('REPLACE_WITH_A_LONG_PRIVATE_ADMIN_KEY');
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_set_key(p_admin_key text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if char_length(coalesce(p_admin_key, '')) < 12 then
    raise exception 'Admin key must be at least 12 characters.';
  end if;

  insert into public.axon_admin_config (key, value_hash, updated_at)
  values ('primary_admin_key', extensions.crypt(p_admin_key, extensions.gen_salt('bf')), now())
  on conflict (key) do update
    set value_hash = excluded.value_hash,
        updated_at = now();

  insert into public.axon_admin_audit_log (action, target_table, status, note)
  values ('admin_key_rotated', 'axon_admin_config', 'completed', 'Primary admin key was updated from Supabase SQL editor.');

  return jsonb_build_object('ok', true, 'message', 'Admin key configured.');
end;
$$;

create or replace function public.axon_admin_login(p_admin_key text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_hash text;
  v_token text;
  v_expires timestamptz := now() + interval '8 hours';
  v_session_id uuid;
begin
  select value_hash into v_hash
  from public.axon_admin_config
  where key = 'primary_admin_key'
  limit 1;

  if v_hash is null then
    raise exception 'Admin key is not configured. Run select public.axon_admin_set_key(''YOUR_STRONG_ADMIN_KEY'') in the Supabase SQL editor.';
  end if;

  if extensions.crypt(coalesce(p_admin_key, ''), v_hash) <> v_hash then
    raise exception 'Invalid admin key.';
  end if;

  delete from public.axon_admin_sessions where expires_at < now() - interval '1 day';

  v_token := encode(extensions.gen_random_bytes(32), 'hex');

  insert into public.axon_admin_sessions (admin_session_token, expires_at)
  values (v_token, v_expires)
  returning id into v_session_id;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, status, note)
  values (v_session_id, 'admin_login', 'axon_admin_sessions', 'completed', 'Admin console session opened.');

  return jsonb_build_object(
    'admin_session_token', v_token,
    'expires_at', v_expires
  );
end;
$$;

create or replace function public.axon_admin_assert_session(p_admin_session_token text)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
begin
  select id into v_session_id
  from public.axon_admin_sessions
  where admin_session_token = coalesce(p_admin_session_token, '')
    and revoked_at is null
    and expires_at > now()
  limit 1;

  if v_session_id is null then
    raise exception 'Admin session expired or invalid.';
  end if;

  return v_session_id;
end;
$$;

create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires
  from public.axon_admin_sessions
  where id = v_session_id;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing', 'completed');

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.users),
    'active_plans_count', (select count(*) from public.user_plans where status = 'active'),
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 30
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 30
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select wallet_address, referred_by, created_at
    from public.users
    order by created_at desc
    limit 30
  ) t;

  return jsonb_build_object(
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'session_expires_at', v_expires
  );
end;
$$;

create or replace function public.axon_admin_update_payment_status(
  p_admin_session_token text,
  p_payment_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_payment public.payment_submissions%rowtype;
  v_plan_id uuid;
  v_plan_status text;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  if v_status not in ('pending', 'processing', 'approved', 'completed', 'rejected') then
    raise exception 'Invalid payment status.';
  end if;

  select * into v_payment
  from public.payment_submissions
  where id = p_payment_id
  for update;

  if not found then
    raise exception 'Payment submission not found.';
  end if;

  update public.payment_submissions
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else processed_at end
  where id = p_payment_id
  returning * into v_payment;

  update public.transactions
  set status = v_status,
      notes = concat_ws(' • ', nullif(notes, ''), case when nullif(trim(coalesce(p_admin_note, '')), '') is not null then 'Admin: ' || trim(p_admin_note) else null end)
  where source = 'payment_submission'
    and reference_id = p_payment_id;

  if v_status in ('approved', 'completed') then
    v_plan_status := 'active';
  elsif v_status = 'rejected' then
    v_plan_status := 'rejected';
  else
    v_plan_status := 'pending';
  end if;

  select id into v_plan_id
  from public.user_plans
  where lower(trim(wallet_address)) = public.axon_normalize_wallet(v_payment.wallet_address)
    and lower(trim(coalesce(plan_name, ''))) = lower(trim(coalesce(v_payment.plan_name, '')))
  order by created_at desc
  limit 1;

  if v_plan_id is null then
    insert into public.user_plans (wallet_address, plan_name, plan_price, status, activated_at, created_at)
    values (
      public.axon_normalize_wallet(v_payment.wallet_address),
      v_payment.plan_name,
      coalesce(v_payment.plan_price, 0),
      v_plan_status,
      case when v_plan_status = 'active' then now() else null end,
      now()
    ) returning id into v_plan_id;
  else
    update public.user_plans
    set status = v_plan_status,
        plan_price = coalesce(v_payment.plan_price, plan_price),
        activated_at = case when v_plan_status = 'active' then coalesce(activated_at, now()) else activated_at end
    where id = v_plan_id;
  end if;

  if v_plan_status = 'active' then
    perform public.axon_init_plan_claim_account(v_payment.wallet_address, v_plan_id, v_payment.plan_name, v_payment.plan_price);
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'payment_status_update', 'payment_submissions', p_payment_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'payment_id', p_payment_id, 'status', v_status, 'user_plan_id', v_plan_id);
end;
$$;

create or replace function public.axon_admin_update_withdrawal_status(
  p_admin_session_token text,
  p_withdrawal_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  if v_status not in ('pending', 'processing', 'completed', 'rejected') then
    raise exception 'Invalid withdrawal status.';
  end if;

  update public.withdrawal_requests
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_withdrawal_id;

  if not found then
    raise exception 'Withdrawal request not found.';
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'withdrawal_status_update', 'withdrawal_requests', p_withdrawal_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'withdrawal_id', p_withdrawal_id, 'status', v_status);
end;
$$;

-- Keep direct table access closed; expose only guarded RPC functions.
revoke all on function public.axon_admin_set_key(text) from public, anon, authenticated;
revoke all on function public.axon_admin_assert_session(text) from public, anon, authenticated;
revoke all on function public.axon_admin_login(text) from public, anon, authenticated;
revoke all on function public.axon_admin_get_console(text) from public, anon, authenticated;
revoke all on function public.axon_admin_update_payment_status(text, uuid, text, text) from public, anon, authenticated;
revoke all on function public.axon_admin_update_withdrawal_status(text, uuid, text, text) from public, anon, authenticated;

grant execute on function public.axon_admin_login(text) to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;
grant execute on function public.axon_admin_update_payment_status(text, uuid, text, text) to anon, authenticated;
grant execute on function public.axon_admin_update_withdrawal_status(text, uuid, text, text) to anon, authenticated;

-- V6.7 hardening: helper functions used internally by SECURITY DEFINER RPCs should not be callable directly from browsers.
revoke all on function public.axon_issue_session(text) from public, anon, authenticated;
revoke all on function public.axon_assert_session(text, text) from public, anon, authenticated;
revoke all on function public.axon_init_free_miner_account(text) from public, anon, authenticated;
revoke all on function public.axon_init_plan_claim_account(text, uuid, text, numeric) from public, anon, authenticated;

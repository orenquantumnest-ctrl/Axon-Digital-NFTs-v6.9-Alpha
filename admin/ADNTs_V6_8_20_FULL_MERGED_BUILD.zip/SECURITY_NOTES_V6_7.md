# AXON DIGITAL NFTs V6.7 Security Notes

## What was hardened

- Admin session system added through Supabase RPC.
- Admin key is hashed with `pgcrypto` and never stored as plaintext.
- Service-role key is not included in frontend code.
- Internal helper RPCs are revoked from direct browser execution.
- Payment and withdrawal admin actions are logged to `axon_admin_audit_log`.
- Payment proof storage remains private insert-only storage.

## Important production recommendations

- Rotate the admin key before launch.
- Restrict Supabase exposed schemas/functions to the minimum required by the app.
- Enable abuse monitoring and rate limits outside the static frontend where possible.
- Keep a manual reconciliation ledger for payment hashes and withdrawal payouts.
- Use a server-side function or backend if transaction verification is automated later.
- Never add the Supabase service-role key to `js/supabase-config.js`.

## Known limits

This is a static frontend + Supabase RPC architecture. It can run publicly, but server-only checks are stronger for payment verification, automated chain indexing, KYC/AML, audit reporting, and regulated financial workflows.

# AXON DIGITAL NFTs V6.8.15 Deployment Checklist

## Purpose
Fixes the V6.8.14 admin UI rendering failure caused by `admin*.html` referencing `css/v6814-admin-swiftui.css` while the package only contained `css/v6813-admin-swiftui.css`.

## Upload
Upload the contents of `build_v6815/` to the site root on both domains.

Required files to confirm after upload:

- `/css/v6814-admin-swiftui.css`
- `/css/v6815-admin-hardening.css`
- `/css/v6814-approval-ui-fix.css`
- `/admin-dashboard.html`
- `/admin-deposits.html`
- `/admin-withdrawals.html`

## Test URLs

- `/admin.html?fresh=6815`
- `/admin-dashboard.html?fresh=6815`
- `/admin-deposits.html?fresh=6815`
- `/admin-withdrawals.html?fresh=6815`

## SQL
No new SQL is required for V6.8.15. Keep V6.8.14 payment approval SQL already installed.

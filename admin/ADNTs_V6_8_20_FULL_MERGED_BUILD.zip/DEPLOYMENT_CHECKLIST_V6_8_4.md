# AXON DIGITAL NFTs V6.8.4 Deployment Checklist

Build hash: `50b8f778ff645e48aca7deebc2f5fc935b2ccc6fff17f3f67df96ebc0f8ac963`

## Purpose
V6.8.4 preserves V6.8.3 and adds the missing plan marketplace and admin plan catalog governance.

## Deployment Order
1. Back up the current live `public_html`.
2. Upload the extracted `ADNTs_V6_8_4/` contents directly into `public_html`.
3. In Supabase SQL Editor, run `supabase_v6_8_4_plan_catalog_patch.sql` after the V6.7 foundation SQL.
4. Login at `/admin.html` with the private Supabase-configured admin key.
5. Open `/admin-plans.html` and confirm the plan catalog loads.
6. Open `/plans.html` as a user and confirm all visible plans appear.
7. Open `/dashboard.html` and confirm the Available Plans preview appears below the active paid plan area.
8. Test `Subscribe` on a paid plan and confirm it routes to `payment.html?plan=<key>&price=<amount>`.

## Rollback
Keep the V6.8.3 ZIP as rollback protection until V6.8.4 is stable on production.

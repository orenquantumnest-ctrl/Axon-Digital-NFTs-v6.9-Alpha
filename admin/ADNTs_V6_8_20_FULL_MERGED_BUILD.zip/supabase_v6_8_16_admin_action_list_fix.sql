-- AXON DIGITAL NFTs V6.8.16
-- Admin action/list fix: prevents invalid uuid errors caused by legacy session assert payloads
-- and provides safe approval/rejection functions that sync payment, transactions, user plans,
-- claim accounts, notifications, and audit logs.
-- Run in Supabase SQL Editor only.

create extension if not exists pgcrypto with schema extensions;

create or replace function public.axon_admin_session_valid_v6816(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_token text := nullif(trim(coalesce(p_admin_session_token, '')), '');
  v_session_id uuid := null;
  v_source text := null;
begin
  if v_token is null then
    return jsonb_build_object('ok', false, 'valid', false, 'reason', 'missing_session_token');
  end if;

  select id, 'axon_admin_sessions'
  into v_session_id, v_source
  from public.axon_admin_sessions
  where admin_session_token = v_token
    and revoked_at is null
    and expires_at > now()
  order by created_at desc
  limit 1;

  if v_session_id is null then
    select id, 'admin_sessions'
    into v_session_id, v_source
    from public.admin_sessions
    where session_token = v_token
      and revoked_at is null
      and expires_at > now()
    order by created_at desc
    limit 1;
  end if;

  if v_session_id is null then
    return jsonb_build_object('ok', false, 'valid', false, 'reason', 'invalid_or_expired_session');
  end if;

  return jsonb_build_object('ok', true, 'valid', true, 'admin_session_id', v_session_id, 'source', v_source);
end;
$$;

grant execute on function public.axon_admin_session_valid_v6816(text) to anon, authenticated;

create or replace function public.axon_admin_update_payment_status(
  p_admin_session_token text,
  p_payment_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session jsonb;
  v_admin_session_id uuid := null;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_payment public.payment_submissions%rowtype;
  v_wallet text;
  v_user_plan_id uuid;
  v_claim_account_id uuid;
  v_plan_status text;
  v_plan_price numeric := 0;
  v_amount numeric := 0;
  v_daily_rate numeric := null;
  v_daily_claim_amount numeric := null;
  v_max_claims int := 40;
  v_note text := nullif(trim(coalesce(p_admin_note, '')), '');
  v_tx_count int := 0;
begin
  v_session := public.axon_admin_session_valid_v6816(p_admin_session_token);
  if coalesce((v_session->>'valid')::boolean, false) is not true then
    raise exception 'Admin session invalid or expired. Login again.';
  end if;

  begin
    v_admin_session_id := nullif(v_session->>'admin_session_id', '')::uuid;
  exception when others then
    v_admin_session_id := null;
  end;

  if p_payment_id is null then
    raise exception 'Missing payment id.';
  end if;

  if v_status not in ('pending', 'processing', 'approved', 'completed', 'rejected') then
    raise exception 'Invalid payment status: %', v_status;
  end if;

  select * into v_payment
  from public.payment_submissions
  where id = p_payment_id
  for update;

  if not found then
    raise exception 'Payment submission not found: %', p_payment_id;
  end if;

  v_wallet := lower(trim(v_payment.wallet_address));
  v_plan_price := coalesce(v_payment.plan_price, v_payment.amount_sent, 0);
  v_amount := coalesce(v_payment.amount_sent, v_payment.plan_price, v_plan_price, 0);

  insert into public.users (id, wallet_address, referral_code, created_at)
  values (gen_random_uuid(), v_wallet, substr(replace(gen_random_uuid()::text, '-', ''), 1, 10), now())
  on conflict (wallet_address) do nothing;

  select
    coalesce(apc.plan_price, v_plan_price),
    coalesce(apc.daily_rate, null),
    coalesce(apc.daily_claim_amount, null),
    coalesce(apc.max_claims, 40)
  into v_plan_price, v_daily_rate, v_daily_claim_amount, v_max_claims
  from public.axon_plan_catalog apc
  where lower(trim(apc.plan_name)) = lower(trim(coalesce(v_payment.plan_name, '')))
     or coalesce(apc.plan_price, -1) = coalesce(v_payment.plan_price, v_payment.amount_sent, -2)
  order by apc.sort_order asc nulls last
  limit 1;

  if v_daily_rate is null then
    select
      coalesce(pc.plan_price, v_plan_price),
      coalesce(pc.daily_rate, null),
      coalesce(pc.max_claims, 40)
    into v_plan_price, v_daily_rate, v_max_claims
    from public.plan_catalog pc
    where lower(trim(pc.plan_name)) = lower(trim(coalesce(v_payment.plan_name, '')))
       or coalesce(pc.plan_price, -1) = coalesce(v_payment.plan_price, v_payment.amount_sent, -2)
    order by pc.sort_order asc nulls last
    limit 1;
  end if;

  if v_daily_rate is null then
    v_daily_rate := case when v_plan_price >= 500 then 3.5 else 3 end;
  end if;

  if v_daily_claim_amount is null or v_daily_claim_amount <= 0 then
    v_daily_claim_amount := round(
      case when v_daily_rate > 1 then v_plan_price * v_daily_rate / 100 else v_plan_price * v_daily_rate end,
      2
    );
  end if;

  if v_max_claims is null or v_max_claims <= 0 then
    v_max_claims := 40;
  end if;

  update public.payment_submissions
  set status = v_status,
      admin_note = v_note,
      reviewed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else reviewed_at end,
      processed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_payment_id
  returning * into v_payment;

  update public.transactions
  set status = v_status,
      amount = coalesce(amount, v_amount),
      plan_name = coalesce(plan_name, v_payment.plan_name),
      source = coalesce(source, 'payment_submission'),
      notes = concat_ws(' • ', nullif(notes, ''), case when v_note is not null then 'Admin: ' || v_note else null end)
  where reference_id = p_payment_id;
  get diagnostics v_tx_count = row_count;

  if v_tx_count = 0 then
    insert into public.transactions (id, wallet_address, type, amount, status, created_at, plan_name, source, reference_id, notes)
    values (
      gen_random_uuid(),
      v_wallet,
      'payment_submission',
      v_amount,
      v_status,
      coalesce(v_payment.created_at, now()),
      v_payment.plan_name,
      'payment_submission',
      p_payment_id,
      concat_ws(' • ', nullif(v_payment.payment_notes, ''), case when v_payment.tx_hash is not null then 'TX ' || v_payment.tx_hash else null end, case when v_note is not null then 'Admin: ' || v_note else null end)
    );
  end if;

  if v_status in ('approved', 'completed') then
    v_plan_status := 'active';
  elsif v_status = 'rejected' then
    v_plan_status := 'rejected';
  else
    v_plan_status := 'pending';
  end if;

  select id into v_user_plan_id
  from public.user_plans
  where lower(trim(wallet_address)) = v_wallet
    and payment_submission_id = p_payment_id
  order by created_at desc
  limit 1;

  if v_user_plan_id is null then
    insert into public.user_plans (id, wallet_address, plan_name, plan_price, status, activated_at, created_at, payment_submission_id)
    values (gen_random_uuid(), v_wallet, v_payment.plan_name, v_plan_price, v_plan_status, case when v_plan_status = 'active' then now() else null end, now(), p_payment_id)
    returning id into v_user_plan_id;
  else
    update public.user_plans
    set plan_name = coalesce(v_payment.plan_name, plan_name),
        plan_price = coalesce(v_plan_price, plan_price),
        status = v_plan_status,
        activated_at = case when v_plan_status = 'active' then coalesce(activated_at, now()) else activated_at end,
        payment_submission_id = coalesce(payment_submission_id, p_payment_id)
    where id = v_user_plan_id;
  end if;

  if v_plan_status = 'active' then
    insert into public.plan_claim_accounts (
      id, wallet_address, user_plan_id, plan_name, plan_price, daily_rate, daily_claim_amount,
      max_claims, claims_completed, total_claimed, status, next_claim_at, created_at, updated_at, last_claim_at
    ) values (
      gen_random_uuid(), v_wallet, v_user_plan_id, v_payment.plan_name, v_plan_price, v_daily_rate, v_daily_claim_amount,
      v_max_claims, 0, 0, 'active', null, now(), now(), null
    )
    on conflict (user_plan_id) do update
    set status = 'active',
        plan_name = excluded.plan_name,
        plan_price = excluded.plan_price,
        daily_rate = excluded.daily_rate,
        daily_claim_amount = excluded.daily_claim_amount,
        max_claims = excluded.max_claims,
        updated_at = now()
    returning id into v_claim_account_id;
  elsif v_plan_status = 'rejected' then
    update public.plan_claim_accounts
    set status = 'rejected', updated_at = now()
    where user_plan_id = v_user_plan_id
    returning id into v_claim_account_id;
  end if;

  insert into public.user_notifications (id, wallet_address, title, message, notification_type, is_read, created_at)
  values (
    gen_random_uuid(),
    v_wallet,
    case when v_status in ('approved','completed') then 'Payment Approved' when v_status = 'rejected' then 'Payment Rejected' else 'Payment Updated' end,
    case when v_status in ('approved','completed') then 'Your payment has been approved and your plan is now active.' when v_status = 'rejected' then 'Your payment was rejected. Please review the admin note or contact support.' else 'Your payment status is now ' || v_status || '.' end,
    'payment',
    false,
    now()
  );

  begin
    insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note, created_at)
    values (v_admin_session_id, 'payment_status_update_v6816', 'payment_submissions', p_payment_id, v_status, v_note, now());
  exception when others then
    insert into public.axon_system_events (id, wallet_address, event_type, severity, payload, created_at)
    values (gen_random_uuid(), v_wallet, 'payment_status_update_v6816_audit_fallback', 'info', jsonb_build_object('payment_id', p_payment_id, 'status', v_status), now());
  end;

  perform pg_notify('pgrst', 'reload schema');

  return jsonb_build_object(
    'ok', true,
    'payment_id', p_payment_id,
    'status', v_status,
    'wallet_address', v_wallet,
    'user_plan_id', v_user_plan_id,
    'claim_account_id', v_claim_account_id,
    'daily_claim_amount', v_daily_claim_amount,
    'transaction_synced', true,
    'valid', true
  );
end;
$$;

grant execute on function public.axon_admin_update_payment_status(text, uuid, text, text) to anon, authenticated;

create or replace function public.axon_admin_update_withdrawal_status(
  p_admin_session_token text,
  p_withdrawal_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session jsonb;
  v_admin_session_id uuid := null;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_note text := nullif(trim(coalesce(p_admin_note, '')), '');
  v_wallet text;
begin
  v_session := public.axon_admin_session_valid_v6816(p_admin_session_token);
  if coalesce((v_session->>'valid')::boolean, false) is not true then
    raise exception 'Admin session invalid or expired. Login again.';
  end if;

  begin
    v_admin_session_id := nullif(v_session->>'admin_session_id', '')::uuid;
  exception when others then
    v_admin_session_id := null;
  end;

  if p_withdrawal_id is null then
    raise exception 'Missing withdrawal id.';
  end if;

  if v_status not in ('pending', 'processing', 'completed', 'rejected') then
    raise exception 'Invalid withdrawal status: %', v_status;
  end if;

  update public.withdrawal_requests
  set status = v_status,
      admin_note = v_note,
      processed_at = case when v_status in ('completed', 'rejected') then now() else processed_at end,
      updated_at = now(),
      reviewed_by_admin_id = coalesce(reviewed_by_admin_id, v_admin_session_id)
  where id = p_withdrawal_id
  returning lower(trim(wallet_address)) into v_wallet;

  if v_wallet is null then
    raise exception 'Withdrawal request not found: %', p_withdrawal_id;
  end if;

  insert into public.user_notifications (id, wallet_address, title, message, notification_type, is_read, created_at)
  values (
    gen_random_uuid(),
    v_wallet,
    'Withdrawal Updated',
    'Your withdrawal request is now ' || v_status || '.',
    'withdrawal',
    false,
    now()
  );

  begin
    insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note, created_at)
    values (v_admin_session_id, 'withdrawal_status_update_v6816', 'withdrawal_requests', p_withdrawal_id, v_status, v_note, now());
  exception when others then
    insert into public.axon_system_events (id, wallet_address, event_type, severity, payload, created_at)
    values (gen_random_uuid(), v_wallet, 'withdrawal_status_update_v6816_audit_fallback', 'info', jsonb_build_object('withdrawal_id', p_withdrawal_id, 'status', v_status), now());
  end;

  perform pg_notify('pgrst', 'reload schema');

  return jsonb_build_object('ok', true, 'valid', true, 'withdrawal_id', p_withdrawal_id, 'status', v_status, 'wallet_address', v_wallet);
end;
$$;

grant execute on function public.axon_admin_update_withdrawal_status(text, uuid, text, text) to anon, authenticated;

create or replace function public.axon_admin_action_health_v6816()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  return jsonb_build_object(
    'ok', true,
    'payment_update_rpc_exists', to_regprocedure('public.axon_admin_update_payment_status(text,uuid,text,text)') is not null,
    'withdrawal_update_rpc_exists', to_regprocedure('public.axon_admin_update_withdrawal_status(text,uuid,text,text)') is not null,
    'pending_payments', (select count(*) from public.payment_submissions where lower(status) = 'pending'),
    'pending_withdrawals', (select count(*) from public.withdrawal_requests where lower(status) in ('pending','processing')),
    'payment_submissions', (select count(*) from public.payment_submissions),
    'withdrawal_requests', (select count(*) from public.withdrawal_requests),
    'transactions', (select count(*) from public.transactions),
    'user_plans', (select count(*) from public.user_plans),
    'plan_claim_accounts', (select count(*) from public.plan_claim_accounts)
  );
end;
$$;

grant execute on function public.axon_admin_action_health_v6816() to anon, authenticated;

select public.axon_admin_action_health_v6816();

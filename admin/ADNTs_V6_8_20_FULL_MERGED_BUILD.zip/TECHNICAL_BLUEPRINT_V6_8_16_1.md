# V6.8.16.1 Technical Blueprint

This patch preserves the V6.8.16 Supabase/admin action logic while explicitly locking the admin visual system to the V6.8.13 Apple-style Liquid Glass interface.

## Preserved
- user dashboard, user pages, auth/session, deposits, withdrawals, transactions, claims
- V6.8.16 admin action/list JavaScript
- V6.8.16 Supabase RPC dependency

## UI lock
- `css/v6813-admin-swiftui.css` remains the base admin interface contract
- `css/v6816-admin-records-fix.css` remains an action/list hardening layer
- admin pages use V6.8.13 class system: `admin-a13-*`

# AXON DIGITAL NFTs V6.8 Deployment Checklist

1. Backup current live hosting files.
2. Confirm V6.7 SQL has already been run in Supabase.
3. Upload the V6.8 package contents to hosting root.
4. Hard refresh or test in a private browser.
5. Test user routes: dashboard, plans, free miner, deposit history, withdrawal history, transactions, referrals, notifications, profile, settings.
6. Test admin routes: admin.html login, admin-dashboard, admin-deposits, admin-withdrawals, admin-users.
7. Confirm payment approval still activates paid plans.
8. Confirm withdrawal request and admin status updates still work.

## Notes
V6.8 is additive at the UI layer and preserves V6.7 Supabase schema/RPC logic.

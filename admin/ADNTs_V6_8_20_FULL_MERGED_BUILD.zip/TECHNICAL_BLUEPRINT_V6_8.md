# AXON DIGITAL NFTs V6.8 Technical Blueprint

## Scope
V6.8 restructures the V6.7 baseline into standalone user and admin pages while preserving the Supabase V6.7 production logic.

## User standalone pages
- dashboard.html
- plans.html
- free-miner.html
- deposit.html
- deposit-history.html
- withdraw.html
- withdrawal-history.html
- transactions.html
- referrals.html
- notifications.html
- profile.html
- settings.html

## Admin standalone pages
- admin-dashboard.html
- admin-users.html
- admin-deposits.html
- admin-withdrawals.html
- admin-plans.html
- admin-transactions.html
- admin-notifications.html
- admin-audit-logs.html
- admin-roles.html
- admin-settings.html

## Design system
The new `css/v68-liquid-glass.css` introduces translucent card shells, sticky glass navigation, metric cards, status pills, responsive grid layouts, premium form containers, and mobile-safe spacing.

## Runtime logic
- `js/v68-user-pages.js` validates the AXON user session, reads dashboard RPC data, reads withdrawal summary RPC data, and renders each page based on `body[data-page]`.
- `js/v68-admin-pages.js` validates the existing admin session token, reads `axon_admin_get_console`, and renders admin pages based on `body[data-admin-page]`.

## Database
No destructive database migration is required beyond V6.7. V6.8 uses the existing V6.7 RPCs.

# AXON DIGITAL NFTs V6.8.12 Technical Blueprint

This release applies the uploaded admin/user JS files into the canonical `/js/` folder and patches `js/v68-admin-pages.js` so `normalizeConsole()` supports live-probe metric keys such as `public_users`, `user_plans_active`, `payment_pending`, `withdrawal_pending`, `transactions`, `axon_plan_catalog`, `plan_claim_accounts_active`, and `free_miner_accounts`.

The admin dashboard keeps the uploaded admin page shell while continuing to call `axon_admin_get_console`. If the normalized console payload totals zero, it attempts a direct live-data probe fallback before rendering metrics.

Admin login remains Supabase-side. The V6.8.12 SQL patch stores only bcrypt hashes inside Supabase. No admin password is embedded in frontend code.

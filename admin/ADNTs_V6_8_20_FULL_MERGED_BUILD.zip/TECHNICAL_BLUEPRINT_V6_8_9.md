# AXON DIGITAL NFTs V6.8.9 Technical Blueprint

V6.8.9 preserves the current user-side build and replaces the admin portal with the uploaded `admin-login.html` and `admin-dashboard.html` interface pattern.

Admin login modes:
- Super-admin: wallet address + PIN/password.
- Sub-admin: username + PIN.

Backend:
- Uses V6.8.7 schema-aligned `axon_admin_get_console` for live data.
- Adds V6.8.9 `axon_admin_login_v689` for admin_accounts and wallet-password compatibility.
- Adds V6.8.9 `axon_admin_create_sub_admin_v689` for sub-admin creation.

Frontend:
- `js/admin-auth.js`: session bridge, Supabase RPC, REST fallback.
- `js/admin-login.js`: uploaded admin login page handlers.
- `js/admin-dashboard.js`: uploaded admin dashboard data renderer and action handlers.

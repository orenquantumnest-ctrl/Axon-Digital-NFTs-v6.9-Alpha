-- AXON DIGITAL NFTs V6.8.12
-- pgcrypto / crypt() runtime login fix
-- Run ONLY in Supabase SQL Editor. DO NOT upload this file to Netlify/cPanel.

-- 1) Ensure pgcrypto exists. Supabase commonly installs extensions in the `extensions` schema.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- 2) Provide public wrappers for functions used by older admin RPC code.
--    This fixes: function crypt(text, text) does not exist
--    when SECURITY DEFINER functions run with search_path=public.
do $$
begin
  if to_regprocedure('public.crypt(text,text)') is null then
    if to_regprocedure('extensions.crypt(text,text)') is not null then
      execute 'create function public.crypt(text,text) returns text language sql immutable strict as $f$ select extensions.crypt($1,$2) $f$';
    end if;
  end if;

  if to_regprocedure('public.gen_salt(text)') is null then
    if to_regprocedure('extensions.gen_salt(text)') is not null then
      execute 'create function public.gen_salt(text) returns text language sql volatile strict as $f$ select extensions.gen_salt($1) $f$';
    end if;
  end if;

  if to_regprocedure('public.gen_salt(text,integer)') is null then
    if to_regprocedure('extensions.gen_salt(text,integer)') is not null then
      execute 'create function public.gen_salt(text,integer) returns text language sql volatile strict as $f$ select extensions.gen_salt($1,$2) $f$';
    end if;
  end if;

  if to_regprocedure('public.gen_random_uuid()') is null then
    if to_regprocedure('extensions.gen_random_uuid()') is not null then
      execute 'create function public.gen_random_uuid() returns uuid language sql volatile as $f$ select extensions.gen_random_uuid() $f$';
    end if;
  end if;

  if to_regprocedure('public.crypt(text,text)') is null then
    raise exception 'pgcrypto crypt(text,text) is still unavailable. Confirm pgcrypto extension is enabled.';
  end if;
end $$;

grant execute on function public.crypt(text,text) to anon, authenticated;
grant execute on function public.gen_salt(text) to anon, authenticated;
grant execute on function public.gen_salt(text,integer) to anon, authenticated;
grant execute on function public.gen_random_uuid() to anon, authenticated;

-- 3) Ensure the V6.8.12 admin wallet/password exists in the wallet admin table.
--    This avoids admin_accounts.role constraint problems. Your admin_accounts valid roles are super_admin/sub_admin.
create table if not exists public.axon_admin_wallet_accounts (
  id uuid primary key default public.gen_random_uuid(),
  wallet_address text unique not null,
  password_hash text not null,
  display_name text not null default 'AXON Super Admin',
  role text not null default 'super_admin',
  status text not null default 'active',
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.axon_admin_wallet_accounts (
  wallet_address,
  password_hash,
  display_name,
  role,
  status,
  updated_at
)
values (
  lower('0x7bbc456c2c34972723cf03b9d44323d2539514de'),
  public.crypt('Cx4!nX9pQ2mL7r', public.gen_salt('bf')),
  'AXON Super Admin',
  'super_admin',
  'active',
  now()
)
on conflict (wallet_address) do update
set
  password_hash = excluded.password_hash,
  display_name = excluded.display_name,
  role = 'super_admin',
  status = 'active',
  updated_at = now();

-- 4) Session table for the current admin wallet login bridge.
create table if not exists public.axon_admin_sessions (
  id uuid primary key default public.gen_random_uuid(),
  admin_session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

-- 5) Replace the exact login RPC the frontend is calling.
create or replace function public.axon_admin_login_v6811(
  p_mode text,
  p_pin text,
  p_username text,
  p_wallet_address text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_mode text := lower(coalesce(p_mode, ''));
  v_wallet text := lower(trim(coalesce(p_wallet_address, '')));
  v_username text := lower(trim(coalesce(p_username, '')));
  v_pin text := coalesce(p_pin, '');
  v_wallet_account record;
  v_admin_account record;
  v_token text;
  v_expires timestamptz := now() + interval '24 hours';
begin
  if length(v_pin) < 4 then
    raise exception 'Invalid admin credentials';
  end if;

  -- Super admin wallet + password/PIN path.
  if v_mode in ('super', 'super_admin', 'wallet') then
    select *
    into v_wallet_account
    from public.axon_admin_wallet_accounts
    where lower(wallet_address) = v_wallet
      and coalesce(status, 'active') = 'active'
    order by updated_at desc nulls last, created_at desc nulls last
    limit 1;

    if found and public.crypt(v_pin, v_wallet_account.password_hash) = v_wallet_account.password_hash then
      v_token := encode(extensions.digest(public.gen_random_uuid()::text || ':' || clock_timestamp()::text || ':' || random()::text, 'sha256'), 'hex');

      insert into public.axon_admin_sessions (admin_session_token, expires_at)
      values (v_token, v_expires);

      update public.axon_admin_wallet_accounts
      set last_login_at = now(), updated_at = now()
      where id = v_wallet_account.id;

      return jsonb_build_object(
        'ok', true,
        'admin_session_token', v_token,
        'session_token', v_token,
        'expires_at', v_expires,
        'admin', jsonb_build_object(
          'id', v_wallet_account.id,
          'wallet_address', v_wallet_account.wallet_address,
          'display_name', v_wallet_account.display_name,
          'role', v_wallet_account.role,
          'mode', 'super'
        )
      );
    end if;

    -- Compatibility path for older admin_accounts table if present with role super_admin.
    if to_regclass('public.admin_accounts') is not null then
      select *
      into v_admin_account
      from public.admin_accounts
      where lower(coalesce(wallet_address, '')) = v_wallet
        and coalesce(is_active, true) = true
        and role = 'super_admin'
      order by updated_at desc nulls last, created_at desc nulls last
      limit 1;

      if found and public.crypt(v_pin, v_admin_account.pin_hash) = v_admin_account.pin_hash then
        v_token := encode(extensions.digest(public.gen_random_uuid()::text || ':' || clock_timestamp()::text || ':' || random()::text, 'sha256'), 'hex');

        insert into public.axon_admin_sessions (admin_session_token, expires_at)
        values (v_token, v_expires);

        begin
          update public.admin_accounts set last_login_at = now(), updated_at = now() where id = v_admin_account.id;
        exception when others then
          null;
        end;

        return jsonb_build_object(
          'ok', true,
          'admin_session_token', v_token,
          'session_token', v_token,
          'expires_at', v_expires,
          'admin', jsonb_build_object(
            'id', v_admin_account.id,
            'wallet_address', v_admin_account.wallet_address,
            'display_name', coalesce(v_admin_account.display_name, 'AXON Super Admin'),
            'role', v_admin_account.role,
            'mode', 'super'
          )
        );
      end if;
    end if;
  end if;

  -- Sub-admin username + PIN path.
  if v_mode in ('sub', 'sub_admin') and to_regclass('public.admin_accounts') is not null then
    select *
    into v_admin_account
    from public.admin_accounts
    where lower(coalesce(username, '')) = v_username
      and coalesce(is_active, true) = true
      and role = 'sub_admin'
    order by updated_at desc nulls last, created_at desc nulls last
    limit 1;

    if found and public.crypt(v_pin, v_admin_account.pin_hash) = v_admin_account.pin_hash then
      v_token := encode(extensions.digest(public.gen_random_uuid()::text || ':' || clock_timestamp()::text || ':' || random()::text, 'sha256'), 'hex');

      insert into public.axon_admin_sessions (admin_session_token, expires_at)
      values (v_token, v_expires);

      begin
        update public.admin_accounts set last_login_at = now(), updated_at = now() where id = v_admin_account.id;
      exception when others then
        null;
      end;

      return jsonb_build_object(
        'ok', true,
        'admin_session_token', v_token,
        'session_token', v_token,
        'expires_at', v_expires,
        'admin', jsonb_build_object(
          'id', v_admin_account.id,
          'username', v_admin_account.username,
          'display_name', coalesce(v_admin_account.display_name, v_admin_account.username),
          'role', v_admin_account.role,
          'mode', 'sub'
        )
      );
    end if;
  end if;

  raise exception 'Invalid admin credentials';
end;
$$;

-- 6) Compatibility login wrappers.
create or replace function public.axon_admin_login_v689(
  p_mode text,
  p_pin text,
  p_username text,
  p_wallet_address text
)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select public.axon_admin_login_v6811($1, $2, $3, $4);
$$;

create or replace function public.axon_admin_wallet_login(
  p_wallet_address text,
  p_password text
)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select public.axon_admin_login_v6811('super', $2, null, $1);
$$;

create or replace function public.axon_admin_assert_session_v6811(
  p_admin_session_token text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_exists boolean;
begin
  select exists(
    select 1
    from public.axon_admin_sessions s
    where s.admin_session_token = p_admin_session_token
      and s.revoked_at is null
      and s.expires_at > now()
  ) into v_exists;

  return jsonb_build_object('ok', coalesce(v_exists, false), 'valid', coalesce(v_exists, false));
end;
$$;

grant execute on function public.axon_admin_login_v6811(text,text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_login_v689(text,text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_wallet_login(text,text) to anon, authenticated;
grant execute on function public.axon_admin_assert_session_v6811(text) to anon, authenticated;

-- 7) Health check for this fix.
create or replace function public.axon_admin_login_v6812_pgcrypto_health()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_hash text;
begin
  v_hash := public.crypt('health-test', public.gen_salt('bf'));

  return jsonb_build_object(
    'ok', public.crypt('health-test', v_hash) = v_hash,
    'public_crypt_exists', to_regprocedure('public.crypt(text,text)') is not null,
    'public_gen_salt_exists', to_regprocedure('public.gen_salt(text)') is not null,
    'login_rpc_exists', to_regprocedure('public.axon_admin_login_v6811(text,text,text,text)') is not null,
    'wallet_accounts_for_wallet', (
      select count(*)
      from public.axon_admin_wallet_accounts
      where lower(wallet_address) = lower('0x7bbc456c2c34972723cf03b9d44323d2539514de')
    )
  );
end;
$$;

grant execute on function public.axon_admin_login_v6812_pgcrypto_health() to anon, authenticated;

notify pgrst, 'reload schema';

select public.axon_admin_login_v6812_pgcrypto_health();

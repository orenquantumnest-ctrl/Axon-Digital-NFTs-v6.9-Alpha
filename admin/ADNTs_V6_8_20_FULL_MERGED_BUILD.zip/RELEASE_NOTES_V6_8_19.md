# AXON DIGITAL NFTs — V6.8.19

## Stability Lock Release

This release now includes the full admin auth merge required for `/admin.html` session creation and recovery. It preserves the V6.8.18 referral restoration architecture and adds the backend contract that returns a real admin session token after successful login.

### Included
- Referral restore persistence lock
- Full admin auth merge for session token issuance
- Admin login session recovery guard layer
- Dashboard hydration fallback improvements
- Admin approval queue stabilization
- Supabase realtime reconnect recovery
- Hardened withdrawal validation sequence
- Build integrity manifest refresh

### Deployment
1. Backup existing production database
2. Run `supabase_v6_8_19_stability_patch.sql`
3. Upload the entire V6.8.19 package
4. Clear CDN/cache and hard refresh
5. Verify admin login, referral rewards, withdrawals, and dashboard sync

### Admin login note
If the admin page still reports a missing session token after this patch, the active Supabase project is not yet using the same SQL schema as the package. Re-run the V6.8.19 patch in the live project and confirm the `axon_admin_login_v6811`, `axon_admin_wallet_login`, `axon_admin_assert_session_v6811`, and `axon_admin_get_console_v6811` functions exist.

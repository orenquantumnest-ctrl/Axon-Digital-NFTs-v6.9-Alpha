# AXON DIGITAL NFTs V6.8.4.2 — Admin Session Bridge Hotfix

## Upload these files first
- `admin.html`
- `js/admin.js`
- `js/v68-admin-pages.js`
- `js/v684-admin-plan-manager.js`

Upload them into the same paths in `public_html`.

## Why
V6.8.4.1 confirmed admin login, but some mobile/private browsers did not expose the stored admin session token to standalone admin pages. V6.8.4.2 writes the session token into localStorage, sessionStorage, and a SameSite cookie, then redirects directly to `admin-dashboard.html?admin_fresh=6842` after login. Admin pages now read all three storage locations and do not silently bounce back to admin.html.

## Test
1. Clear website data for axondigitalnfts.com.
2. Open `https://axondigitalnfts.com/admin.html?fresh=6842`.
3. Enter the configured private admin key.
4. Tap Open Console.
5. Confirm it moves to `admin-dashboard.html?admin_fresh=6842`.
6. Open `admin-plans.html` and verify the plan catalog manager.

-- AXON DIGITAL NFTs V6.8.4.2 admin session health check
select
  exists(select 1 from public.axon_admin_config where key = 'primary_admin_key') as admin_key_configured,
  exists(select 1 from pg_proc where proname = 'axon_admin_login') as login_rpc_exists,
  exists(select 1 from pg_proc where proname = 'axon_admin_get_console') as console_rpc_exists,
  exists(select 1 from information_schema.tables where table_schema = 'public' and table_name = 'axon_admin_sessions') as admin_sessions_table_exists,
  exists(select 1 from pg_proc where proname = 'axon_admin_get_plan_catalog') as plan_catalog_rpc_exists;

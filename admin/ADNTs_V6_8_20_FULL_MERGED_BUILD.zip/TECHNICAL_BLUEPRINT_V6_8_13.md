# AXON DIGITAL NFTs V6.8.13 — Admin SwiftUI/Liquid Glass Pages

V6.8.13 preserves the V6.8.12 user frontend and improves the admin experience with dedicated responsive admin pages.

## Admin pages
- admin.html
- admin-dashboard.html
- admin-users.html
- admin-deposits.html
- admin-withdrawals.html
- admin-plans.html
- admin-transactions.html
- admin-notifications.html
- admin-audit-logs.html
- admin-roles.html
- admin-settings.html

## Admin runtime
- `js/v68-admin-pages.js` remains the schema-normalized Supabase runtime.
- `js/v6813-admin-ui.js` controls drawer navigation, logout cleanup, and mobile shell behavior.
- `css/v6813-admin-swiftui.css` provides the new adaptive glass UI.

## Supabase compatibility
Uses the already-fixed wallet/password login RPC flow and existing schema-normalized console RPC.

Build hash: `91465d78925a794021c91214650922f790113dd472918bdd62259b6529f961cd`

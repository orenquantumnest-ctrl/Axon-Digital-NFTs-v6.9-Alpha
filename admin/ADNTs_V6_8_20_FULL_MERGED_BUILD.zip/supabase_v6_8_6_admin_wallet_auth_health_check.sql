-- AXON DIGITAL NFTs V6.8.6 — Admin Wallet Auth + Live Data Health Check
select public.axon_admin_wallet_auth_health() as wallet_auth_health;
select public.axon_admin_live_data_probe() as live_data_probe;

-- AXON DIGITAL NFTs V6.8.6 — Admin Wallet + Password Login Patch
-- Purpose: remove frontend dependency on the old private admin key login flow.
-- Admin logs in with the official deposit wallet address and a Supabase-hashed password.
-- Run this in Supabase SQL Editor. This file does NOT contain the plaintext admin password.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.axon_admin_wallet_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text unique not null,
  password_hash text not null,
  display_name text not null default 'AXON Admin',
  role text not null default 'owner',
  status text not null default 'active',
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.axon_admin_wallet_accounts enable row level security;
revoke all on table public.axon_admin_wallet_accounts from public, anon, authenticated;

create or replace function public.axon_normalize_admin_wallet(p_wallet_address text)
returns text
language sql
immutable
set search_path = public
as $$
  select lower(trim(coalesce(p_wallet_address, '')));
$$;

create or replace function public.axon_admin_set_wallet_account(
  p_wallet_address text,
  p_password text,
  p_display_name text default 'AXON Master Admin'
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_admin_wallet(p_wallet_address);
begin
  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid admin wallet address. Use a valid 0x BEP20/EVM address.';
  end if;

  if char_length(coalesce(p_password, '')) < 14 then
    raise exception 'Admin password must be at least 14 characters.';
  end if;

  insert into public.axon_admin_wallet_accounts (
    wallet_address,
    password_hash,
    display_name,
    role,
    status,
    updated_at
  )
  values (
    v_wallet,
    extensions.crypt(p_password, extensions.gen_salt('bf')),
    coalesce(nullif(trim(p_display_name), ''), 'AXON Master Admin'),
    'owner',
    'active',
    now()
  )
  on conflict (wallet_address) do update
    set password_hash = excluded.password_hash,
        display_name = excluded.display_name,
        role = 'owner',
        status = 'active',
        updated_at = now();

  insert into public.axon_admin_audit_log (action, target_table, status, note)
  values ('admin_wallet_password_rotated', 'axon_admin_wallet_accounts', 'completed', 'V6.8.6 admin wallet/password account configured.');

  return jsonb_build_object(
    'ok', true,
    'message', 'Admin wallet/password account configured.',
    'wallet_address', v_wallet
  );
end;
$$;

create or replace function public.axon_admin_wallet_login(
  p_wallet_address text,
  p_password text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_wallet text := public.axon_normalize_admin_wallet(p_wallet_address);
  v_account record;
  v_token text;
  v_expires timestamptz := now() + interval '8 hours';
  v_session_id uuid;
begin
  if v_wallet !~ '^0x[a-f0-9]{40}$' then
    raise exception 'Invalid admin wallet address.';
  end if;

  select id, wallet_address, password_hash, display_name, role, status
  into v_account
  from public.axon_admin_wallet_accounts
  where wallet_address = v_wallet
  limit 1;

  if v_account.id is null then
    raise exception 'Admin wallet account is not configured. Run select public.axon_admin_set_wallet_account(...) in Supabase SQL Editor.';
  end if;

  if lower(coalesce(v_account.status, 'suspended')) <> 'active' then
    raise exception 'Admin wallet account is not active.';
  end if;

  if extensions.crypt(coalesce(p_password, ''), v_account.password_hash) <> v_account.password_hash then
    raise exception 'Invalid admin wallet or password.';
  end if;

  delete from public.axon_admin_sessions where expires_at < now() - interval '1 day';

  v_token := encode(extensions.gen_random_bytes(32), 'hex');

  insert into public.axon_admin_sessions (admin_session_token, expires_at)
  values (v_token, v_expires)
  returning id into v_session_id;

  update public.axon_admin_wallet_accounts
  set last_login_at = now(), updated_at = now()
  where id = v_account.id;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, status, note)
  values (v_session_id, 'admin_wallet_login', 'axon_admin_wallet_accounts', 'completed', 'Admin wallet/password console session opened.');

  return jsonb_build_object(
    'ok', true,
    'admin_session_token', v_token,
    'expires_at', v_expires,
    'wallet_address', v_wallet,
    'display_name', v_account.display_name,
    'role', v_account.role
  );
end;
$$;

create or replace function public.axon_admin_wallet_auth_health()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'ok', true,
    'v686_wallet_auth_rpc', to_regprocedure('public.axon_admin_wallet_login(text,text)') is not null,
    'wallet_accounts_table', to_regclass('public.axon_admin_wallet_accounts') is not null,
    'configured_wallet_accounts', (select count(*) from public.axon_admin_wallet_accounts where status='active'),
    'admin_sessions', (select count(*) from public.axon_admin_sessions),
    'live_data_probe', public.axon_admin_live_data_probe()
  );
$$;

revoke all on function public.axon_normalize_admin_wallet(text) from public, anon, authenticated;
revoke all on function public.axon_admin_set_wallet_account(text,text,text) from public, anon, authenticated;
revoke all on function public.axon_admin_wallet_login(text,text) from public, anon, authenticated;
revoke all on function public.axon_admin_wallet_auth_health() from public, anon, authenticated;

grant execute on function public.axon_admin_wallet_login(text,text) to anon, authenticated;
grant execute on function public.axon_admin_wallet_auth_health() to anon, authenticated;
-- Keep setup function callable from Supabase SQL editor / database owner context.

grant execute on function public.axon_admin_set_wallet_account(text,text,text) to postgres;

select public.axon_admin_wallet_auth_health() as axon_v686_wallet_auth_health;

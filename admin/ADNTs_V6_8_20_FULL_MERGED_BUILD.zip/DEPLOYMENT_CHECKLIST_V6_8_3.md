# AXON DIGITAL NFTs V6.8.3 Deployment Checklist

Build hash: `88a1bdcbcd515c967a82817579a2bb8b143b258d8ff36c37fa5f4cee11ac7126`

## Purpose
V6.8.3 locks V6.8.2 and adds the final dashboard claim behavior requested for paid subscribed plans.

## Deploy
1. Back up current `public_html`.
2. Upload the extracted contents of `ADNTs_V6_8_3/` directly into `public_html`.
3. Hard refresh the browser or test in private mode.
4. Sign in with a user that has an admin-approved paid plan.
5. Open `/dashboard.html`.

## Verify
- Active paid plan preview appears on the dashboard.
- Each paid plan shows `Days Claimed`.
- Each paid plan shows `Days Remaining`.
- Each paid plan shows a live `24h Countdown`.
- The 24-hour bar moves as the claim window progresses.
- The claim button unlocks when the countdown reaches zero.
- The `Go to this plan` button routes to `plans.html` with the claim account identifier in the query string.
- FREE Miner remains separate and unchanged.

## Database
No destructive SQL migration is required. V6.8.3 uses the existing V6.7/V6.8.2 RPC foundation:

- `axon_get_dashboard`
- `axon_get_session_status`
- `axon_claim_plan_reward`


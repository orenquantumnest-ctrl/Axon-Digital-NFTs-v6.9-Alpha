# AXON DIGITAL NFTs V6.8.4.1 Admin Login Hotfix

This hotfix solves the admin login screen appearing frozen after tapping **Open Console**.

## What changed
- `js/admin.js` now shows immediate login status messages.
- Admin login RPC has a 20-second timeout instead of silently waiting.
- Console loading has a 25-second timeout.
- Missing Supabase SDK/config issues are shown directly on the page.
- Existing admin session loading is more visible.
- The admin build label now says V6.8.4.
- `admin.html` loads `js/admin.js?v=6841-hotfix` to bypass browser cache.

## Upload only these files for the hotfix
- `admin.html`
- `js/admin.js`

Or upload the full package contents to `public_html`.

## After upload
1. Open `https://axondigitalnfts.com/admin.html?fresh=6841`
2. Enter the private admin key.
3. Tap **Open Console**.
4. You should now see either:
   - `Verifying admin key with Supabase…`
   - `Admin session active. Loading console…`
   - or a clear error message explaining what is blocked.

## Supabase health check
Run `supabase_v6_8_4_admin_health_check.sql` in Supabase SQL Editor to confirm the admin RPCs exist.

# AXON DIGITAL NFTs V6.8.2 Deployment Checklist

## Purpose
V6.8.2 keeps the V6.8 standalone page architecture and the V6.8.1 responsive navigation, then upgrades the user dashboard with a paid daily claim progress center.

## Required Backend
This build expects the V6.7 Supabase SQL foundation to already be installed, including:

- `axon_get_dashboard`
- `axon_get_session_status`
- `axon_claim_plan_reward`
- `axon_get_plan_claim_statuses`
- `axon_get_withdrawal_summary`

No destructive database reset is required for V6.8.2.

## Upload Order
1. Back up the current live `public_html` folder.
2. Extract `ADNTs_V6_8_2_PAID_CLAIM_DASHBOARD_LOCKED.zip`.
3. Upload the extracted contents directly into `public_html`.
4. Confirm this structure exists:
   - `public_html/dashboard.html`
   - `public_html/css/v682-dashboard-claims.css`
   - `public_html/js/v682-dashboard-claims.js`
   - `public_html/VERSION.json`
5. Clear browser cache or test in private mode.

## Dashboard Test
1. Log in as a normal user with an approved paid plan.
2. Open `/dashboard.html`.
3. Confirm the new **Paid Plan Claim Progress** section appears.
4. Confirm each paid subscribed plan shows:
   - 24-hour claim window progress bar
   - plan completion progress bar
   - daily claim amount
   - claim count
   - next claim window
   - active/cooldown/completed status
5. Tap a plan card or the `Claim Daily Reward` button.
6. Confirm the claim either succeeds or shows a clear cooldown message.
7. Open `/transactions.html` and confirm the paid plan claim appears in the ledger.

## Rollback
If the live dashboard fails:
1. Restore the V6.8.1 ZIP backup.
2. Confirm Supabase V6.7 RPCs are still installed.
3. Check browser console for missing file paths.

## Security Note
The V6.8.2 build hash is non-secret. Admin private keys must remain Supabase-side and must not be embedded into HTML or frontend JavaScript.

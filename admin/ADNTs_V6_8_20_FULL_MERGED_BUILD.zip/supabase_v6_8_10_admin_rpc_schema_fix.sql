-- AXON DIGITAL NFTs V6.8.10 — Admin RPC Schema Fix
-- Purpose:
--   1) Fix the admin dashboard live-data RPC that could fail because of a malformed V6.8.7 withdrawal query.
--   2) Seed the uploaded admin-login.html flow into admin_accounts using the official admin wallet + PIN/password.
--   3) Preserve existing users, payments, withdrawals, transactions, plans, and sessions. No destructive reset.
-- Run after V6.8.6 wallet-login SQL and V6.8.7/V6.8.9 admin bridge SQL.

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- 0) Required admin tables and idempotent admin seed
-- -----------------------------------------------------------------------------
create table if not exists public.axon_admin_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  role text,
  wallet_address text,
  username text,
  pin_hash text not null,
  department text,
  permission_bundle jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  last_login_at timestamptz,
  created_by_admin_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  display_name text,
  wallet_modal_label text,
  account_number text,
  admin_tag text
);

create table if not exists public.admin_sessions (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_id uuid not null,
  session_token text unique not null,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_id uuid,
  action_name text not null,
  entity_type text,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.axon_admin_wallet_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  wallet_address text unique not null,
  password_hash text not null,
  display_name text not null default 'AXON Super Admin',
  role text not null default 'super_admin',
  status text not null default 'active',
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.axon_admin_audit_log (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_session_id uuid,
  action text not null,
  target_table text,
  target_id uuid,
  status text,
  note text,
  created_at timestamptz not null default now()
);

alter table public.admin_accounts enable row level security;
alter table public.admin_sessions enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.axon_admin_sessions enable row level security;
alter table public.axon_admin_wallet_accounts enable row level security;
alter table public.axon_admin_audit_log enable row level security;

-- Official admin credentials used by the frontend login form. This password exists only in this SQL setup.
-- Do not upload this SQL file publicly after running it in Supabase SQL Editor.
insert into public.admin_accounts (
  role,
  wallet_address,
  username,
  pin_hash,
  department,
  permission_bundle,
  is_active,
  display_name,
  wallet_modal_label,
  admin_tag,
  updated_at
)
select
  'super_admin',
  '0x7bbc456C2C34972723cF03b9D44323d2539514dE',
  'masteradmin',
  extensions.crypt('AV686-k65adUH6R5O38vI@lnIuVnATd93zKEOqKO', extensions.gen_salt('bf')),
  'Executive Control',
  jsonb_build_object('users',true,'payments',true,'withdrawals',true,'plans',true,'admins',true,'audit',true,'settings',true),
  true,
  'MasterAdmin',
  'Official AXON Deposit Wallet',
  'AXON_SUPER_ADMIN_V6810',
  now()
where not exists (
  select 1 from public.admin_accounts
  where lower(trim(coalesce(wallet_address,''))) = lower('0x7bbc456C2C34972723cF03b9D44323d2539514dE')
);

-- If a row already exists for the same wallet, force it active and refresh the PIN hash.
update public.admin_accounts
set role = coalesce(nullif(role,''),'super_admin'),
    username = coalesce(nullif(username,''),'masteradmin'),
    pin_hash = extensions.crypt('AV686-k65adUH6R5O38vI@lnIuVnATd93zKEOqKO', extensions.gen_salt('bf')),
    department = coalesce(nullif(department,''),'Executive Control'),
    permission_bundle = jsonb_build_object('users',true,'payments',true,'withdrawals',true,'plans',true,'admins',true,'audit',true,'settings',true),
    is_active = true,
    display_name = coalesce(nullif(display_name,''),'MasterAdmin'),
    wallet_modal_label = coalesce(nullif(wallet_modal_label,''),'Official AXON Deposit Wallet'),
    admin_tag = 'AXON_SUPER_ADMIN_V6810',
    updated_at = now()
where lower(trim(coalesce(wallet_address,''))) = lower('0x7bbc456C2C34972723cF03b9D44323d2539514dE');

insert into public.axon_admin_wallet_accounts (
  wallet_address,
  password_hash,
  display_name,
  role,
  status,
  updated_at
) values (
  '0x7bbc456C2C34972723cF03b9D44323d2539514dE',
  extensions.crypt('AV686-k65adUH6R5O38vI@lnIuVnATd93zKEOqKO', extensions.gen_salt('bf')),
  'MasterAdmin',
  'super_admin',
  'active',
  now()
)
on conflict (wallet_address) do update set
  password_hash = excluded.password_hash,
  display_name = excluded.display_name,
  role = excluded.role,
  status = 'active',
  updated_at = now();

-- -----------------------------------------------------------------------------
-- 1) Shared helpers
-- -----------------------------------------------------------------------------
create or replace function public.axon_normalize_wallet(p_value text)
returns text
language sql
immutable
set search_path = public
as $$
  select lower(trim(coalesce(p_value, '')));
$$;

create or replace function public.axon_admin_pin_matches(p_pin text, p_hash text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if coalesce(p_pin, '') = '' or coalesce(p_hash, '') = '' then
    return false;
  end if;

  begin
    if extensions.crypt(p_pin, p_hash) = p_hash then
      return true;
    end if;
  exception when others then
    null;
  end;

  return p_hash = p_pin;
end;
$$;

create or replace function public.axon_admin_assert_session(p_admin_session_token text)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_token text := trim(coalesce(p_admin_session_token, ''));
  v_session_id uuid;
begin
  if v_token = '' then
    raise exception 'Admin session token is required.';
  end if;

  select id into v_session_id
  from public.axon_admin_sessions
  where admin_session_token = v_token
    and revoked_at is null
    and expires_at > now()
  order by created_at desc
  limit 1;

  if v_session_id is null then
    select id into v_session_id
    from public.admin_sessions
    where session_token = v_token
      and revoked_at is null
      and expires_at > now()
    order by created_at desc
    limit 1;
  end if;

  if v_session_id is null then
    raise exception 'Admin session is invalid or expired. Login again.';
  end if;

  return v_session_id;
end;
$$;

-- -----------------------------------------------------------------------------
-- 2) Admin login used by uploaded admin-login.html/admin.html
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_login_v689(
  p_mode text,
  p_wallet_address text,
  p_username text,
  p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_mode text := lower(trim(coalesce(p_mode, 'super')));
  v_wallet text := public.axon_normalize_wallet(p_wallet_address);
  v_username text := lower(trim(coalesce(p_username, '')));
  v_pin text := coalesce(p_pin, '');
  v_account public.admin_accounts%rowtype;
  v_token text := encode(extensions.gen_random_bytes(32), 'hex');
  v_expires timestamptz := now() + interval '8 hours';
  v_admin_session_id uuid;
  v_axon_session_id uuid;
begin
  if v_pin = '' then
    raise exception 'Admin PIN/password is required.';
  end if;

  if v_mode = 'sub' then
    if v_username = '' then raise exception 'Sub-admin username is required.'; end if;
    select * into v_account
    from public.admin_accounts
    where lower(trim(coalesce(username,''))) = v_username
      and coalesce(is_active,false) = true
    order by created_at desc
    limit 1;
  else
    if v_wallet !~ '^0x[a-f0-9]{40}$' then raise exception 'Valid super-admin wallet address is required.'; end if;
    select * into v_account
    from public.admin_accounts
    where public.axon_normalize_wallet(wallet_address) = v_wallet
      and coalesce(is_active,false) = true
    order by created_at desc
    limit 1;
  end if;

  if v_account.id is null then
    raise exception 'Admin account not found. Run the V6.8.10 admin RPC schema fix SQL.';
  end if;

  if not public.axon_admin_pin_matches(v_pin, v_account.pin_hash) then
    raise exception 'Invalid admin credentials.';
  end if;

  insert into public.axon_admin_sessions (admin_session_token, expires_at)
  values (v_token, v_expires)
  returning id into v_axon_session_id;

  insert into public.admin_sessions (admin_id, session_token, expires_at)
  values (v_account.id, v_token, v_expires)
  returning id into v_admin_session_id;

  update public.admin_accounts
  set last_login_at = now(), updated_at = now()
  where id = v_account.id;

  insert into public.admin_audit_logs (admin_id, action_name, entity_type, entity_id, details)
  values (v_account.id, 'admin_login_v6810', 'admin_accounts', v_account.id::text, jsonb_build_object('mode', v_mode));

  return jsonb_build_object(
    'ok', true,
    'admin_session_token', v_token,
    'session_token', v_token,
    'expires_at', v_expires,
    'admin_id', v_account.id,
    'wallet_address', v_account.wallet_address,
    'username', v_account.username,
    'display_name', coalesce(v_account.display_name, v_account.username, 'AXON Admin'),
    'role', coalesce(v_account.role, 'admin'),
    'department', coalesce(v_account.department, 'Operations'),
    'permission_bundle', coalesce(v_account.permission_bundle, '{}'::jsonb)
  );
end;
$$;

-- -----------------------------------------------------------------------------
-- 3) Live wallet/user index and probe
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_user_index()
returns table(wallet_address text, created_at timestamptz)
language sql
security definer
set search_path = public, extensions
as $$
  with raw_wallets as (
    select wallet_address::text, created_at::timestamptz from public.users
    union all select wallet_address::text, created_at::timestamptz from public.user_sessions
    union all select wallet_address::text, created_at::timestamptz from public.payment_submissions
    union all select wallet_address::text, created_at::timestamptz from public.user_plans
    union all select wallet_address::text, created_at::timestamptz from public.transactions
    union all select wallet_address::text, created_at::timestamptz from public.withdrawal_requests
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_accounts
    union all select wallet_address::text, created_at::timestamptz from public.free_miner_claims
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_accounts
    union all select wallet_address::text, created_at::timestamptz from public.plan_claim_history
    union all select referrer_wallet::text as wallet_address, created_at::timestamptz from public.referrals
    union all select referred_wallet::text as wallet_address, created_at::timestamptz from public.referrals
    union all select referrer_wallet::text as wallet_address, created_at::timestamptz from public.referral_visits
    union all select wallet_address::text, created_at::timestamptz from public.axon_system_events where wallet_address is not null
  ), cleaned as (
    select public.axon_normalize_wallet(wallet_address) as wallet_address,
           coalesce(created_at, now()) as created_at
    from raw_wallets
    where nullif(trim(coalesce(wallet_address,'')), '') is not null
  )
  select cleaned.wallet_address, min(cleaned.created_at) as created_at
  from cleaned
  where cleaned.wallet_address <> ''
  group by cleaned.wallet_address
  order by min(cleaned.created_at) desc;
$$;

create or replace function public.axon_admin_live_data_probe()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'public_users', (select count(*) from public.users),
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index()),
    'user_sessions', (select count(*) from public.user_sessions),
    'payment_submissions', (select count(*) from public.payment_submissions),
    'payment_pending', (select count(*) from public.payment_submissions where lower(trim(coalesce(status,'pending'))) = 'pending'),
    'user_plans', (select count(*) from public.user_plans),
    'user_plans_active', (select count(*) from public.user_plans where lower(trim(coalesce(status,''))) = 'active'),
    'plan_claim_accounts', (select count(*) from public.plan_claim_accounts),
    'plan_claim_accounts_active', (select count(*) from public.plan_claim_accounts where lower(trim(coalesce(status,''))) = 'active'),
    'plan_claim_history', (select count(*) from public.plan_claim_history),
    'free_miner_accounts', (select count(*) from public.free_miner_accounts),
    'free_miner_claims', (select count(*) from public.free_miner_claims),
    'transactions', (select count(*) from public.transactions),
    'withdrawal_requests', (select count(*) from public.withdrawal_requests),
    'withdrawal_pending', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status,'pending'))) in ('pending','processing')),
    'referrals', (select count(*) from public.referrals),
    'referral_visits', (select count(*) from public.referral_visits),
    'axon_plan_catalog', (select count(*) from public.axon_plan_catalog where coalesce(status,'active') <> 'deleted' and deleted_at is null),
    'legacy_plan_catalog', (select count(*) from public.plan_catalog),
    'admin_accounts', (select count(*) from public.admin_accounts),
    'active_admin_accounts', (select count(*) from public.admin_accounts where coalesce(is_active,false) = true),
    'admin_sessions_live', (select count(*) from public.admin_sessions where revoked_at is null and expires_at > now()),
    'axon_admin_sessions_live', (select count(*) from public.axon_admin_sessions where revoked_at is null and expires_at > now())
  );
$$;

create or replace function public.axon_backfill_users_from_live_activity()
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_before integer := 0;
  v_after integer := 0;
begin
  select count(*) into v_before from public.users;

  insert into public.users (wallet_address, referral_code, created_at)
  select idx.wallet_address,
         'AX' || upper(substr(md5(idx.wallet_address), 1, 10)) as referral_code,
         coalesce(idx.created_at, now())
  from public.axon_admin_user_index() idx
  where idx.wallet_address <> ''
  on conflict (wallet_address) do nothing;

  select count(*) into v_after from public.users;

  return jsonb_build_object(
    'ok', true,
    'users_before', v_before,
    'users_after', v_after,
    'inserted', greatest(0, v_after - v_before),
    'derived_live_wallets', (select count(*) from public.axon_admin_user_index())
  );
end;
$$;

select public.axon_backfill_users_from_live_activity() as axon_v6810_user_backfill;

-- -----------------------------------------------------------------------------
-- 4) Corrected schema-aligned admin console RPC
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_get_console(p_admin_session_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_expires timestamptz;
  v_stats jsonb;
  v_payments jsonb := '[]'::jsonb;
  v_withdrawals jsonb := '[]'::jsonb;
  v_users jsonb := '[]'::jsonb;
  v_transactions jsonb := '[]'::jsonb;
  v_plan_accounts jsonb := '[]'::jsonb;
  v_free_miner_accounts jsonb := '[]'::jsonb;
  v_audit_logs jsonb := '[]'::jsonb;
  v_system_events jsonb := '[]'::jsonb;
  v_plan_catalog jsonb := '[]'::jsonb;
  v_admin_accounts jsonb := '[]'::jsonb;
  v_total_claim_earnings numeric := 0;
  v_reserved_withdrawals numeric := 0;
  v_active_plans integer := 0;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);

  select expires_at into v_expires from public.axon_admin_sessions where id = v_session_id limit 1;
  if v_expires is null then
    select expires_at into v_expires from public.admin_sessions where id = v_session_id limit 1;
  end if;

  select coalesce(sum(amount), 0) into v_total_claim_earnings
  from (
    select coalesce(claim_amount, 0)::numeric as amount from public.free_miner_claims
    union all
    select coalesce(claim_amount, 0)::numeric as amount from public.plan_claim_history
  ) q;

  select coalesce(sum(coalesce(requested_amount, 0)), 0) into v_reserved_withdrawals
  from public.withdrawal_requests
  where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing');

  select coalesce(count(*),0) into v_active_plans
  from (
    select id::text as row_id from public.plan_claim_accounts where lower(trim(coalesce(status,''))) = 'active'
    union
    select id::text as row_id from public.user_plans where lower(trim(coalesce(status,''))) = 'active'
  ) active_rows;

  v_stats := jsonb_build_object(
    'users_count', (select count(*) from public.axon_admin_user_index()),
    'public_users_count', (select count(*) from public.users),
    'derived_live_wallets_count', (select count(*) from public.axon_admin_user_index()),
    'active_plans_count', v_active_plans,
    'pending_payments_count', (select count(*) from public.payment_submissions where lower(trim(coalesce(status, 'pending'))) = 'pending'),
    'pending_withdrawals_count', (select count(*) from public.withdrawal_requests where lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing')),
    'transactions_count', (select count(*) from public.transactions),
    'catalog_count', (select count(*) from public.axon_plan_catalog where coalesce(status,'active') <> 'deleted' and deleted_at is null),
    'claim_accounts_count', (select count(*) from public.plan_claim_accounts),
    'free_miner_count', (select count(*) from public.free_miner_accounts),
    'audit_count', ((select count(*) from public.axon_admin_audit_log) + (select count(*) from public.admin_audit_logs)),
    'total_claim_earnings', v_total_claim_earnings,
    'reserved_withdrawals', v_reserved_withdrawals
  );

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_payments
  from (
    select id, wallet_address, plan_name, plan_price, amount_sent, tx_hash, proof_storage_path, payment_notes, admin_note, status, created_at, reviewed_at, processed_at, updated_at
    from public.payment_submissions
    order by case when lower(trim(coalesce(status, 'pending'))) = 'pending' then 0 else 1 end, created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_withdrawals
  from (
    select id, wallet_address, payout_wallet, requested_amount, status, user_note, admin_note, created_at, processed_at, updated_at
    from public.withdrawal_requests
    order by case when lower(trim(coalesce(status, 'pending'))) in ('pending', 'processing') then 0 else 1 end, created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_users
  from (
    select
      idx.wallet_address,
      u.id,
      coalesce(u.referral_code, 'AX' || upper(substr(md5(idx.wallet_address), 1, 10))) as referral_code,
      u.referred_by,
      coalesce(u.created_at, idx.created_at) as created_at,
      coalesce((select count(*) from public.user_plans up where public.axon_normalize_wallet(up.wallet_address) = idx.wallet_address and lower(trim(coalesce(up.status,''))) = 'active'),0)
      + coalesce((select count(*) from public.plan_claim_accounts pca where public.axon_normalize_wallet(pca.wallet_address) = idx.wallet_address and lower(trim(coalesce(pca.status,''))) = 'active'),0) as active_plans_count,
      coalesce((select sum(amount) from public.transactions tx where public.axon_normalize_wallet(tx.wallet_address) = idx.wallet_address and lower(trim(coalesce(tx.status,'completed'))) in ('completed','approved','active')),0) as available_balance,
      coalesce((select count(*) from public.payment_submissions ps where public.axon_normalize_wallet(ps.wallet_address) = idx.wallet_address),0) as payment_count,
      coalesce((select count(*) from public.withdrawal_requests wr where public.axon_normalize_wallet(wr.wallet_address) = idx.wallet_address),0) as withdrawal_count,
      coalesce((select count(*) from public.plan_claim_history pch where public.axon_normalize_wallet(pch.wallet_address) = idx.wallet_address),0) as paid_claims_count,
      coalesce((select count(*) from public.free_miner_claims fmc where public.axon_normalize_wallet(fmc.wallet_address) = idx.wallet_address),0) as free_claims_count
    from public.axon_admin_user_index() idx
    left join public.users u on public.axon_normalize_wallet(u.wallet_address) = idx.wallet_address
    order by coalesce(u.created_at, idx.created_at) desc
    limit 300
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_transactions
  from (
    select id, wallet_address, type, plan_name, amount, status, source, reference_id, notes, created_at
    from public.transactions
    order by created_at desc
    limit 250
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_accounts
  from (
    select id, wallet_address, user_plan_id, plan_name, plan_price, daily_rate, daily_claim_amount, max_claims, claims_completed, total_claimed, last_claim_at, next_claim_at, status, created_at, updated_at
    from public.plan_claim_accounts
    order by case when lower(trim(coalesce(status,'')))='active' then 0 else 1 end, created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_free_miner_accounts
  from (
    select id, wallet_address, status, claims_completed, claimed_amount, last_claim_at, next_claim_at, activated_at, created_at, updated_at
    from public.free_miner_accounts
    order by created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_audit_logs
  from (
    select id, admin_session_id::text as admin_id, action as action_name, target_table as entity_type, target_id::text as entity_id, jsonb_build_object('note',note,'status',status) as details, created_at
    from public.axon_admin_audit_log
    union all
    select id, admin_id::text, action_name, entity_type, entity_id, details, created_at
    from public.admin_audit_logs
    order by created_at desc
    limit 200
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_system_events
  from (
    select id, wallet_address, event_type as action, severity as status, payload::text as note, created_at
    from public.axon_system_events
    order by created_at desc
    limit 150
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_plan_catalog
  from (
    select id, plan_code, payment_key, plan_name, plan_price, daily_rate, daily_claim_amount, max_claims, max_unlocks, sort_order, badge, category, description, is_visible, is_featured, status, created_at, updated_at, deleted_at
    from public.axon_plan_catalog
    where deleted_at is null
    order by sort_order asc, plan_price asc
  ) t;

  select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) into v_admin_accounts
  from (
    select id, role, wallet_address, username, department, permission_bundle, is_active, last_login_at, created_at, updated_at, display_name, wallet_modal_label, account_number, admin_tag
    from public.admin_accounts
    order by case when coalesce(is_active,false) then 0 else 1 end, created_at desc
    limit 200
  ) t;

  return jsonb_build_object(
    'ok', true,
    'version', '6.8.10',
    'schema_bridge', 'real_supplied_public_schema_corrected',
    'stats', v_stats,
    'payments', v_payments,
    'withdrawals', v_withdrawals,
    'users', v_users,
    'transactions', v_transactions,
    'plan_accounts', v_plan_accounts,
    'free_miner_accounts', v_free_miner_accounts,
    'audit_logs', v_audit_logs,
    'system_events', v_system_events,
    'plan_catalog', v_plan_catalog,
    'admin_accounts', v_admin_accounts,
    'session_expires_at', v_expires,
    'data_probe', public.axon_admin_live_data_probe()
  );
end;
$$;

-- -----------------------------------------------------------------------------
-- 5) Admin payment/withdrawal controls aligned to same session RPC
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_update_payment_status(
  p_admin_session_token text,
  p_payment_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
  v_payment public.payment_submissions%rowtype;
  v_plan_id uuid;
  v_plan_status text;
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  if v_status not in ('pending', 'processing', 'approved', 'completed', 'rejected') then raise exception 'Invalid payment status.'; end if;

  select * into v_payment from public.payment_submissions where id = p_payment_id for update;
  if not found then raise exception 'Payment submission not found.'; end if;

  update public.payment_submissions
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('approved', 'completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_payment_id
  returning * into v_payment;

  update public.transactions
  set status = v_status,
      notes = concat_ws(' • ', nullif(notes, ''), case when nullif(trim(coalesce(p_admin_note, '')), '') is not null then 'Admin: ' || trim(p_admin_note) else null end)
  where source = 'payment_submission' and reference_id = p_payment_id;

  if v_status in ('approved', 'completed') then v_plan_status := 'active';
  elsif v_status = 'rejected' then v_plan_status := 'rejected';
  else v_plan_status := 'pending';
  end if;

  select id into v_plan_id
  from public.user_plans
  where public.axon_normalize_wallet(wallet_address) = public.axon_normalize_wallet(v_payment.wallet_address)
    and lower(trim(coalesce(plan_name, ''))) = lower(trim(coalesce(v_payment.plan_name, '')))
  order by created_at desc
  limit 1;

  if v_plan_id is null then
    insert into public.user_plans (wallet_address, plan_name, plan_price, status, activated_at, created_at, payment_submission_id)
    values (public.axon_normalize_wallet(v_payment.wallet_address), v_payment.plan_name, coalesce(v_payment.plan_price, 0), v_plan_status, case when v_plan_status = 'active' then now() else null end, now(), p_payment_id)
    returning id into v_plan_id;
  else
    update public.user_plans
    set status = v_plan_status,
        plan_price = coalesce(v_payment.plan_price, plan_price),
        activated_at = case when v_plan_status = 'active' then coalesce(activated_at, now()) else activated_at end
    where id = v_plan_id;
  end if;

  if v_plan_status = 'active' and to_regprocedure('public.axon_init_plan_claim_account(text,uuid,text,numeric)') is not null then
    perform public.axon_init_plan_claim_account(v_payment.wallet_address, v_plan_id, v_payment.plan_name, v_payment.plan_price);
  end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'payment_status_update', 'payment_submissions', p_payment_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'payment_id', p_payment_id, 'status', v_status, 'user_plan_id', v_plan_id);
end;
$$;

create or replace function public.axon_admin_update_withdrawal_status(
  p_admin_session_token text,
  p_withdrawal_id uuid,
  p_status text,
  p_admin_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_session_id uuid;
  v_status text := lower(trim(coalesce(p_status, '')));
begin
  v_session_id := public.axon_admin_assert_session(p_admin_session_token);
  if v_status not in ('pending', 'processing', 'completed', 'rejected') then raise exception 'Invalid withdrawal status.'; end if;

  update public.withdrawal_requests
  set status = v_status,
      admin_note = nullif(trim(coalesce(p_admin_note, '')), ''),
      processed_at = case when v_status in ('completed', 'rejected') then now() else processed_at end,
      updated_at = now()
  where id = p_withdrawal_id;
  if not found then raise exception 'Withdrawal request not found.'; end if;

  insert into public.axon_admin_audit_log (admin_session_id, action, target_table, target_id, status, note)
  values (v_session_id, 'withdrawal_status_update', 'withdrawal_requests', p_withdrawal_id, v_status, nullif(trim(coalesce(p_admin_note, '')), ''));

  return jsonb_build_object('ok', true, 'withdrawal_id', p_withdrawal_id, 'status', v_status);
end;
$$;

-- -----------------------------------------------------------------------------
-- 6) Health check and grants
-- -----------------------------------------------------------------------------
create or replace function public.axon_admin_schema_bridge_health()
returns jsonb
language sql
security definer
set search_path = public, extensions
as $$
  select jsonb_build_object(
    'ok', true,
    'version', '6.8.10',
    'admin_accounts', (select count(*) from public.admin_accounts),
    'active_admin_accounts', (select count(*) from public.admin_accounts where coalesce(is_active,false) = true),
    'users_table', to_regclass('public.users') is not null,
    'payment_submissions_table', to_regclass('public.payment_submissions') is not null,
    'withdrawal_requests_table', to_regclass('public.withdrawal_requests') is not null,
    'transactions_table', to_regclass('public.transactions') is not null,
    'axon_admin_get_console_rpc', to_regprocedure('public.axon_admin_get_console(text)') is not null,
    'admin_login_v689_rpc', to_regprocedure('public.axon_admin_login_v689(text,text,text,text)') is not null,
    'live_data_probe', public.axon_admin_live_data_probe()
  );
$$;

revoke all on function public.axon_admin_pin_matches(text,text) from public;
revoke all on function public.axon_normalize_wallet(text) from public;
revoke all on function public.axon_admin_assert_session(text) from public;
revoke all on function public.axon_admin_login_v689(text,text,text,text) from public;
revoke all on function public.axon_admin_user_index() from public;
revoke all on function public.axon_admin_live_data_probe() from public;
revoke all on function public.axon_backfill_users_from_live_activity() from public;
revoke all on function public.axon_admin_get_console(text) from public;
revoke all on function public.axon_admin_update_payment_status(text,uuid,text,text) from public;
revoke all on function public.axon_admin_update_withdrawal_status(text,uuid,text,text) from public;
revoke all on function public.axon_admin_schema_bridge_health() from public;

grant execute on function public.axon_admin_login_v689(text,text,text,text) to anon, authenticated;
grant execute on function public.axon_admin_assert_session(text) to anon, authenticated;
grant execute on function public.axon_admin_user_index() to anon, authenticated;
grant execute on function public.axon_admin_live_data_probe() to anon, authenticated;
grant execute on function public.axon_backfill_users_from_live_activity() to anon, authenticated;
grant execute on function public.axon_admin_get_console(text) to anon, authenticated;
grant execute on function public.axon_admin_update_payment_status(text,uuid,text,text) to anon, authenticated;
grant execute on function public.axon_admin_update_withdrawal_status(text,uuid,text,text) to anon, authenticated;
grant execute on function public.axon_admin_schema_bridge_health() to anon, authenticated;

select public.axon_admin_schema_bridge_health() as axon_v6810_admin_rpc_schema_fix_health;
